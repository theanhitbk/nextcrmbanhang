class Unit {
  int? id;
  String? name;
  int? multiplier;
  int? allowDecimal;
  String? price;
  bool? isBaseUnit;

  Unit(
      {this.id,
      this.name,
      this.multiplier,
      this.allowDecimal,
      this.price,
      this.isBaseUnit});

  Unit.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    multiplier = json['multiplier'];
    allowDecimal = json['allow_decimal'];
    price = json['price'];
    isBaseUnit = json['is_base_unit'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['multiplier'] = this.multiplier;
    data['allow_decimal'] = this.allowDecimal;
    data['price'] = this.price;
    data['is_base_unit'] = this.isBaseUnit;
    return data;
  }
}