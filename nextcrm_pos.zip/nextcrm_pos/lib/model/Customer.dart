import 'Meta.dart';

class CustomerResponse {
  CustomerResponse({
    required this.data,
    this.meta,
    this.recordsTotal = 0,
    this.recordsFiltered = 0,
    // required this.request,
  });
  late List<Customer> data = [];
  MetaData? meta;
  late int recordsTotal;
  late int recordsFiltered;
  // late Request request;

  CustomerResponse.fromJson(Map<String, dynamic> json) {
    data = List.from(json['data']).map((e) => Customer.fromJson(e)).toList();
    meta = json['meta'] == null ? null : MetaData.fromJson(json['meta']);
    recordsTotal = json['recordsTotal'];
    recordsFiltered = json['recordsFiltered'];
    // request = Request.fromJson(json['request']);
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['data'] = data.map((e) => e.toJson()).toList();
    _data['meta'] = this.meta == null ? null : this.meta?.toJson();
    _data['recordsTotal'] = recordsTotal;
    _data['recordsFiltered'] = recordsFiltered;
    // _data['request'] = request.toJson();
    return _data;
  }
}

class Customer {
  Customer({
    required this.id,
    this.text = '',
    this.name = '',
    this.mobile = '',
    this.landmark = '',
    this.city = '',
    this.state = '',
    this.payTermNumber = 0,
    this.payTermType = '',
    this.totalRp = 0,
    this.address = '',
    this.contactId = '',
    this.description = '',
  });
  late int id;
  late String text;
  late String name;
  late String mobile;
  late String landmark;
  late String city;
  late String state;
  late int payTermNumber;
  late String payTermType;
  late int totalRp;
  late String? address;
  late String contactId;
  late String? description;

  Customer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    text = json['text'] ?? '';
    name = json['name'] ?? '';
    mobile = json['mobile'] ?? '';
    landmark = json['landmark'] ?? '';
    city = json['city'] ?? '';
    state = json['state'] ?? '';
    payTermNumber = json['pay_term_number'] ?? 0;
    payTermType = json['pay_term_type'] ?? '';
    totalRp = json['total_rp'] ?? 0;
    address = json['address'] ?? '';
    contactId = json['contact_id'] ?? '';
    description = json['description'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['text'] = text;
    _data['name'] = name;
    _data['mobile'] = mobile;
    _data['landmark'] = landmark;
    _data['city'] = city;
    _data['state'] = state;
    _data['pay_term_number'] = payTermNumber;
    _data['pay_term_type'] = payTermType;
    _data['total_rp'] = totalRp;
    _data['address'] = address;
    _data['contact_id'] = contactId;
    _data['description'] = description;
    return _data;
  }
}

// class Links {
//   Links({
//     required this.next,
//   });
//   late final String next;
//
//   Links.fromJson(Map<String, dynamic> json) {
//     next = json['next'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final _data = <String, dynamic>{};
//     _data['next'] = next;
//     return _data;
//   }
// }

class Request {
  Request({
    required this.tenantcode,
    required this.username,
    required this.password,
    required this.appType,
    required this.pageLimit,
    required this.page,
    required this.type,
    required this.strsearch,
  });
  late String tenantcode;
  late String username;
  late String password;
  late String appType;
  late String pageLimit;
  late String page;
  late String type;
  late String strsearch;

  Request.fromJson(Map<String, dynamic> json) {
    tenantcode = json['tenantcode'];
    username = json['username'];
    password = json['password'];
    appType = json['app_type'];
    pageLimit = json['pageLimit'];
    page = json['page'];
    type = json['type'];
    strsearch = json['strsearch'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['tenantcode'] = tenantcode;
    _data['username'] = username;
    _data['password'] = password;
    _data['app_type'] = appType;
    _data['pageLimit'] = pageLimit;
    _data['page'] = page;
    _data['type'] = type;
    _data['strsearch'] = strsearch;
    return _data;
  }
}

class CustomerGroupResponse {
  CustomerGroupResponse({
    required this.data,
  });
  late List<CustomerGroup> data = [];

  CustomerGroupResponse.fromJson(Map<String, dynamic> json) {
    data =
        List.from(json['data']).map((e) => CustomerGroup.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['data'] = data.map((e) => e.toJson()).toList();
    return _data;
  }
}

class CustomerGroup {
  CustomerGroup({
    required this.id,
    this.name,
    this.description,
    this.amount,
  });
  late int id = 0;
  late String? name;
  late String? description;
  late int? amount;

  CustomerGroup.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    description = json["description"];
    amount = json['amount'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['name'] = name;
    _data['description'] = description;
    _data['amount'] = amount;
    return _data;
  }
}

class CustomerRequest {
  CustomerRequest({
    this.avatar = '',
    this.name = '',
    this.mobile = '',
    this.address = '',
    this.supplier_business_name = '',
    this.tax_number = '',
    this.email = '',
    this.description = '',
    this.type = '',
    this.customer_group_id = '',
    this.state = '',
    this.dateOfBirth = '',
    this.gender = true,
  });
  late String name;
  late String avatar;
  late String mobile;
  late String address;
  late String supplier_business_name;
  late String tax_number;
  late String email;
  late String description;
  late String type;
  late String customer_group_id;
  late String? state;
  late String? dateOfBirth;
  late bool gender;

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['name'] = name;
    _data['avatar'] = avatar;
    _data['mobile'] = mobile;
    _data['address'] = address;
    _data['supplier_business_name'] = supplier_business_name;
    _data['tax_number'] = tax_number;
    _data['email'] = email;
    _data['description'] = description;
    _data['type'] = type;
    _data['customer_group_id'] = customer_group_id;
    _data['custom_field4'] = dateOfBirth;
    _data['state'] = state;
    _data['gender'] = gender;
    return _data;
  }
}

class MetaData {
  MetaData({
    this.pagination,
    this.statusCode,
    this.message,
  });

  Pagination? pagination;
  int? statusCode;
  String? message;

  MetaData copyWith({
    Pagination? pagination,
    int? statusCode,
    String? message,
  }) =>
      MetaData(
        pagination: pagination ?? this.pagination,
        statusCode: statusCode ?? this.statusCode,
        message: message ?? this.message,
      );

  factory MetaData.fromJson(Map<String, dynamic> json) => MetaData(
    pagination: json["pagination"] == null ? null : Pagination.fromJson(json["pagination"]),
    statusCode: json["status_code"] == null ? null : json["status_code"],
    message: json["message"] == null ? null : json["message"],
  );

  Map<String, dynamic> toJson() => {
    "pagination": pagination == null ? null : pagination?.toJson(),
    "status_code": statusCode == null ? null : statusCode,
    "message": message == null ? null : message,
  };
}

class Pagination {
  Pagination({
    this.total,
    this.count,
    this.perPage,
    this.currentPage,
    this.totalPages,
    this.links,
  });

  int? total;
  int? count;
  int? perPage;
  int? currentPage;
  int? totalPages;
  Links? links;

  Pagination copyWith({
    int? total,
    int? count,
    int? perPage,
    int? currentPage,
    int? totalPages,
    Links? links,
  }) =>
      Pagination(
        total: total ?? this.total,
        count: count ?? this.count,
        perPage: perPage ?? this.perPage,
        currentPage: currentPage ?? this.currentPage,
        totalPages: totalPages ?? this.totalPages,
        links: links ?? this.links,
      );

  factory Pagination.fromJson(Map<String, dynamic> json) => Pagination(
    total: json["total"] == null ? null : json["total"],
    count: json["count"] == null ? null : json["count"],
    perPage: json["per_page"] == null ? null : json["per_page"],
    currentPage: json["current_page"] == null ? null : json["current_page"],
    totalPages: json["total_pages"] == null ? null : json["total_pages"],
    links: json["links"] == null ? null : Links.fromJson(json["links"]),
  );

  Map<String, dynamic> toJson() => {
    "total": total == null ? null : total,
    "count": count == null ? null : count,
    "per_page": perPage == null ? null : perPage,
    "current_page": currentPage == null ? null : currentPage,
    "total_pages": totalPages == null ? null : totalPages,
    "links": links == null ? null : links?.toJson(),
  };
}

class Links {
  Links({
    this.next,
    this.previous,
  });

  String? next;
  String? previous;

  Links copyWith({
    String? next,
    String? previous,
  }) =>
      Links(
        next: next ?? this.next,
        previous: previous ?? this.previous,
      );

  factory Links.fromJson(Map<String, dynamic> json) => Links(
    next: json["next"] == null ? null : json["next"],
    previous: json["previous"] == null ? null : json["previous"],
  );

  Map<String, dynamic> toJson() => {
    "next": next == null ? null : next,
    "previous": previous == null ? null : previous,
  };
}