
class NoticeResponse {
  List<Notice> items = [];

  NoticeResponse({required this.items});

  NoticeResponse.fromJson(Map<String, dynamic> json) {
    if (json['items'] != null) {
      // List<Notice> notices = [];
      json['items'].forEach((v) {
        items.add(Notice.fromJson(v));
      });
    }
    // meta = (json['meta'] != null ? new Meta.fromJson(json['meta']) : null)!;
  }
}

class Notice {
  String createdAt;
  String updatedAt;
  int id;
  int userId;
  int notificationId;
  int isRead;
  String deviceId;
  String status;
  String extraData;
  Notification notification;

  Notice(
      {this.createdAt = '',
      this.updatedAt = '',
      this.id = 0,
      this.userId = 0,
      this.notificationId = 0,
      this.isRead = 0,
      this.deviceId = '',
      this.status = '',
      this.extraData = '',
      required this.notification
      }
    );

  factory Notice.fromJson(Map<String, dynamic> json) => Notice(
    createdAt: json['CreatedAt'] ?? '',
    updatedAt: json['UpdatedAt'] ?? '',
    id: json['ID'] ?? 0,
    userId: json['UserId'] ?? 0,
    notificationId: json['NotificationId'] ?? 0,
    isRead: json['IsRead'] ?? 0,
    deviceId: json['DeviceId'] ?? '',
    status: json['Status'] ?? '',
    extraData: json['ExtraData'] ?? '',
    notification: new Notification.fromJson(json['Notification'])
  );

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['CreatedAt'] = this.createdAt;
    data['UpdatedAt'] = this.updatedAt;
    data['ID'] = this.id;
    data['UserId'] = this.userId;
    data['NotificationId'] = this.notificationId;
    data['IsRead'] = this.isRead;
    data['DeviceId'] = this.deviceId;
    data['Status'] = this.status;
    data['ExtraData'] = this.extraData;
    data['Notification'] = this.notification.toJson();
    return data;
  }
}

class Notification {
  late int id;
  late String title;
  late String description;
  late String content;
  late String createdAt;
  late String updatedAt;
  late String url;

  Notification(
      {required this.id,
      required this.title,
      required this.description,
      required this.content,
      this.createdAt = '',
      this.updatedAt = '',
      this.url = ''});

  Notification.fromJson(Map<String, dynamic> json) {
    id = json['NotificationId'];
    title = json['Title'] ?? '';
    description = json['Description'] ?? '';
    content = json['Content'] ?? '';
    createdAt = json['CreatedAt'];
    updatedAt = json['UpdatedAt'];
    url = json['Url'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['NotificationId'] = this.id;
    data['Title'] = this.title;
    data['Description'] = this.description;
    data['Content'] = this.content;
    data['CreatedAt'] = this.createdAt;
    data['UpdatedAt'] = this.updatedAt;
    data['Url'] = this.url;
    return data;
  }
}
