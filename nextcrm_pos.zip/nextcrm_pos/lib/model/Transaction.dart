
import 'package:vidifi/model/Meta.dart';

class TransactionRequest {
  Data? data;
  Meta? meta;
  TransactionRequest({this.data, this.meta});

  TransactionRequest.fromJson(Map<String, dynamic> json) {
    print('START PARSE ${json.toString()}');
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    return data;
  }
}

class Data {
  Transaction? transaction;

  Data({this.transaction});

  Data.fromJson(Map<String, dynamic> json) {
    transaction = json['transaction'] != null
        ? new Transaction.fromJson(json['transaction'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.transaction != null) {
      data['transaction'] = this.transaction!.toJson();
    }
    return data;
  }
}

class Transaction {
  int? tenantId;
  int? branchId;
  String? type;
  String? status;
  int? customerId;
  String? customerGroupId;
  String? invoiceNo;
  String? refNo;
  int? totalBeforeTax;
  String? transactionDate;
  String? taxId;
  String? discountType;
  int? discountAmount;
  int? taxAmount;
  int? finalTotal;
  String? additionalNotes;
  String? staffNote;
  int? createdBy;
  int? isDirectSale;
  String? commissionAgent;
  int? isQuotation;
  String? shippingDetails;
  String? shippingAddress;
  String? shippingStatus;
  String? deliveredTo;
  int? shippingCharges;
  int? exchangeRate;
  int? sellingPriceGroupId;
  String? payTermNumber;
  String? payTermType;
  int? isSuspend;
  int? isRecurring;
  String? recurInterval;
  String? recurIntervalType;
  String? subscriptionNo;
  int? recurRepetitions;
  String? orderAddresses;
  String? subType;
  int? rpEarned;
  int? rpRedeemed;
  int? rpRedeemedAmount;
  String? typesOfServiceId;
  int? packingCharge;
  String? packingChargeType;
  String? serviceCustomField1;
  String? serviceCustomField2;
  String? serviceCustomField3;
  String? serviceCustomField4;
  int? roundOffAmount;
  String? importBatch;
  String? importTime;
  int? employeeId;
  String? transferParentId;
  int? priceBookId;
  int? sourceId;
  int? isDeliver;
  String? returnParentId;
  String? estimatedDeliveryDate;
  int? returnCharges;
  int? id;
  Customer? customer;

  Transaction(
      {this.tenantId,
      this.branchId,
      this.type,
      this.status,
      this.customerId,
      this.customerGroupId,
      this.invoiceNo,
      this.refNo,
      this.totalBeforeTax,
      this.transactionDate,
      this.taxId,
      this.discountType,
      this.discountAmount,
      this.taxAmount,
      this.finalTotal,
      this.additionalNotes,
      this.staffNote,
      this.createdBy,
      this.isDirectSale,
      this.commissionAgent,
      this.isQuotation,
      this.shippingDetails,
      this.shippingAddress,
      this.shippingStatus,
      this.deliveredTo,
      this.shippingCharges,
      this.exchangeRate,
      this.sellingPriceGroupId,
      this.payTermNumber,
      this.payTermType,
      this.isSuspend,
      this.isRecurring,
      this.recurInterval,
      this.recurIntervalType,
      this.subscriptionNo,
      this.recurRepetitions,
      this.orderAddresses,
      this.subType,
      this.rpEarned,
      this.rpRedeemed,
      this.rpRedeemedAmount,
      this.typesOfServiceId,
      this.packingCharge,
      this.packingChargeType,
      this.serviceCustomField1,
      this.serviceCustomField2,
      this.serviceCustomField3,
      this.serviceCustomField4,
      this.roundOffAmount,
      this.importBatch,
      this.importTime,
      this.employeeId,
      this.transferParentId,
      this.priceBookId,
      this.sourceId,
      this.isDeliver,
      this.returnParentId,
      this.estimatedDeliveryDate,
      this.returnCharges,
      this.id,
      this.customer});

  Transaction.fromJson(Map<String, dynamic> json) {
    tenantId = json['tenant_id'];
    branchId = json['branch_id'];
    type = json['type'];
    status = json['status'];
    customerId = json['customer_id'];
    customerGroupId = json['customer_group_id'];
    invoiceNo = json['invoice_no'];
    refNo = json['ref_no'];
    totalBeforeTax = json['total_before_tax'];
    transactionDate = json['transaction_date'];
    taxId = json['tax_id'];
    discountType = json['discount_type'];
    discountAmount = json['discount_amount'];
    taxAmount = json['tax_amount'];
    finalTotal = json['final_total'];
    additionalNotes = json['additional_notes'];
    staffNote = json['staff_note'];
    createdBy = json['created_by'];
    isDirectSale = json['is_direct_sale'];
    commissionAgent = json['commission_agent'];
    isQuotation = json['is_quotation'];
    shippingDetails = json['shipping_details'];
    shippingAddress = json['shipping_address'];
    shippingStatus = json['shipping_status'];
    deliveredTo = json['delivered_to'];
    shippingCharges = json['shipping_charges'];
    exchangeRate = json['exchange_rate'];
    sellingPriceGroupId = json['selling_price_group_id'];
    payTermNumber = json['pay_term_number'];
    payTermType = json['pay_term_type'];
    isSuspend = json['is_suspend'];
    isRecurring = json['is_recurring'];
    recurInterval = json['recur_interval'];
    recurIntervalType = json['recur_interval_type'];
    subscriptionNo = json['subscription_no'];
    recurRepetitions = json['recur_repetitions'];
    orderAddresses = json['order_addresses'];
    subType = json['sub_type'];
    rpEarned = json['rp_earned'];
    rpRedeemed = json['rp_redeemed'];
    rpRedeemedAmount = json['rp_redeemed_amount'];
    typesOfServiceId = json['types_of_service_id'];
    packingCharge = json['packing_charge'];
    packingChargeType = json['packing_charge_type'];
    serviceCustomField1 = json['service_custom_field_1'];
    serviceCustomField2 = json['service_custom_field_2'];
    serviceCustomField3 = json['service_custom_field_3'];
    serviceCustomField4 = json['service_custom_field_4'];
    roundOffAmount = json['round_off_amount'];
    importBatch = json['import_batch'];
    importTime = json['import_time'];
    employeeId = json['employee_id'];
    transferParentId = json['transfer_parent_id'];
    priceBookId = json['price_book_id'];
    sourceId = json['source_id'];
    isDeliver = json['is_deliver'];
    returnParentId = json['return_parent_id'];
    estimatedDeliveryDate = json['estimated_delivery_date'];
    returnCharges = json['return_charges'];
    id = json['id'];
    customer = json['customer'] != null
        ? new Customer.fromJson(json['customer'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['tenant_id'] = this.tenantId;
    data['branch_id'] = this.branchId;
    data['type'] = this.type;
    data['status'] = this.status;
    data['customer_id'] = this.customerId;
    data['customer_group_id'] = this.customerGroupId;
    data['invoice_no'] = this.invoiceNo;
    data['ref_no'] = this.refNo;
    data['total_before_tax'] = this.totalBeforeTax;
    data['transaction_date'] = this.transactionDate;
    data['tax_id'] = this.taxId;
    data['discount_type'] = this.discountType;
    data['discount_amount'] = this.discountAmount;
    data['tax_amount'] = this.taxAmount;
    data['final_total'] = this.finalTotal;
    data['additional_notes'] = this.additionalNotes;
    data['staff_note'] = this.staffNote;
    data['created_by'] = this.createdBy;
    data['is_direct_sale'] = this.isDirectSale;
    data['commission_agent'] = this.commissionAgent;
    data['is_quotation'] = this.isQuotation;
    data['shipping_details'] = this.shippingDetails;
    data['shipping_address'] = this.shippingAddress;
    data['shipping_status'] = this.shippingStatus;
    data['delivered_to'] = this.deliveredTo;
    data['shipping_charges'] = this.shippingCharges;
    data['exchange_rate'] = this.exchangeRate;
    data['selling_price_group_id'] = this.sellingPriceGroupId;
    data['pay_term_number'] = this.payTermNumber;
    data['pay_term_type'] = this.payTermType;
    data['is_suspend'] = this.isSuspend;
    data['is_recurring'] = this.isRecurring;
    data['recur_interval'] = this.recurInterval;
    data['recur_interval_type'] = this.recurIntervalType;
    data['subscription_no'] = this.subscriptionNo;
    data['recur_repetitions'] = this.recurRepetitions;
    data['order_addresses'] = this.orderAddresses;
    data['sub_type'] = this.subType;
    data['rp_earned'] = this.rpEarned;
    data['rp_redeemed'] = this.rpRedeemed;
    data['rp_redeemed_amount'] = this.rpRedeemedAmount;
    data['types_of_service_id'] = this.typesOfServiceId;
    data['packing_charge'] = this.packingCharge;
    data['packing_charge_type'] = this.packingChargeType;
    data['service_custom_field_1'] = this.serviceCustomField1;
    data['service_custom_field_2'] = this.serviceCustomField2;
    data['service_custom_field_3'] = this.serviceCustomField3;
    data['service_custom_field_4'] = this.serviceCustomField4;
    data['round_off_amount'] = this.roundOffAmount;
    data['import_batch'] = this.importBatch;
    data['import_time'] = this.importTime;
    data['employee_id'] = this.employeeId;
    data['transfer_parent_id'] = this.transferParentId;
    data['price_book_id'] = this.priceBookId;
    data['source_id'] = this.sourceId;
    data['is_deliver'] = this.isDeliver;
    data['return_parent_id'] = this.returnParentId;
    data['estimated_delivery_date'] = this.estimatedDeliveryDate;
    data['return_charges'] = this.returnCharges;
    data['id'] = this.id;
    if (this.customer != null) {
      data['customer'] = this.customer!.toJson();
    }
    return data;
  }
}

class Customer {
  int? id;
  String? type;
  String? supplierBusinessName;
  String? name;
  String? email;
  String? contactId;
  String? taxNumber;
  String? city;
  String? state;
  String? country;
  String? landmark;
  String? mobile;
  String? landline;
  String? alternateNumber;
  int? payTermNumber;
  String? payTermType;
  String? createdBy;
  int? isDefault;
  String? creditLimit;
  int? customerGroupId;
  String? customField1;
  String? customField2;
  String? customField3;
  String? customField4;
  int? totalRp;
  int? totalRpUsed;
  int? totalRpExpired;
  String? address;
  String? description;
  String? avatar;
  String? leadId;
  int? employeeId;
  String? subjectType;
  String? subjectId;
  String? ecommerceReferId;
  int? provinceId;
  int? districtId;
  int? wardId;

  Customer(
      {this.id,
      this.type,
      this.supplierBusinessName,
      this.name,
      this.email,
      this.contactId,
      this.taxNumber,
      this.city,
      this.state,
      this.country,
      this.landmark,
      this.mobile,
      this.landline,
      this.alternateNumber,
      this.payTermNumber,
      this.payTermType,
      this.createdBy,
      this.isDefault,
      this.creditLimit,
      this.customerGroupId,
      this.customField1,
      this.customField2,
      this.customField3,
      this.customField4,
      this.totalRp,
      this.totalRpUsed,
      this.totalRpExpired,
      this.address,
      this.description,
      this.avatar,
      this.leadId,
      this.employeeId,
      this.subjectType,
      this.subjectId,
      this.ecommerceReferId,
      this.provinceId,
      this.districtId,
      this.wardId
      });

  Customer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    type = json['type'];
    supplierBusinessName = json['supplier_business_name'];
    name = json['name'];
    email = json['email'];
    contactId = json['contact_id'];
    taxNumber = json['tax_number'];
    city = json['city'];
    state = json['state'];
    country = json['country'];
    landmark = json['landmark'];
    mobile = json['mobile'];
    landline = json['landline'];
    alternateNumber = json['alternate_number'];
    payTermNumber = json['pay_term_number'];
    payTermType = json['pay_term_type'];
    createdBy = json['created_by'];
    isDefault = json['is_default'];
    creditLimit = json['credit_limit'];
    customerGroupId = json['customer_group_id'];
    customField1 = json['custom_field1'];
    customField2 = json['custom_field2'];
    customField3 = json['custom_field3'];
    customField4 = json['custom_field4'];
    totalRp = json['total_rp'];
    totalRpUsed = json['total_rp_used'];
    totalRpExpired = json['total_rp_expired'];
    address = json['address'];
    description = json['description'];
    avatar = json['avatar'];
    leadId = json['lead_id'];
    employeeId = json['employee_id'];
    subjectType = json['subject_type'];
    subjectId = json['subject_id'];
    ecommerceReferId = json['ecommerce_refer_id'];
    provinceId = json['province_id'];
    districtId = json['district_id'];
    wardId = json['ward_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['type'] = this.type;
    data['supplier_business_name'] = this.supplierBusinessName;
    data['name'] = this.name;
    data['email'] = this.email;
    data['contact_id'] = this.contactId;
    data['tax_number'] = this.taxNumber;
    data['city'] = this.city;
    data['state'] = this.state;
    data['country'] = this.country;
    data['landmark'] = this.landmark;
    data['mobile'] = this.mobile;
    data['landline'] = this.landline;
    data['alternate_number'] = this.alternateNumber;
    data['pay_term_number'] = this.payTermNumber;
    data['pay_term_type'] = this.payTermType;
    data['created_by'] = this.createdBy;
    data['is_default'] = this.isDefault;
    data['credit_limit'] = this.creditLimit;
    data['customer_group_id'] = this.customerGroupId;
    data['custom_field1'] = this.customField1;
    data['custom_field2'] = this.customField2;
    data['custom_field3'] = this.customField3;
    data['custom_field4'] = this.customField4;
    data['total_rp'] = this.totalRp;
    data['total_rp_used'] = this.totalRpUsed;
    data['total_rp_expired'] = this.totalRpExpired;
    data['address'] = this.address;
    data['description'] = this.description;
    data['avatar'] = this.avatar;
    data['lead_id'] = this.leadId;
    data['employee_id'] = this.employeeId;
    data['subject_type'] = this.subjectType;
    data['subject_id'] = this.subjectId;
    data['ecommerce_refer_id'] = this.ecommerceReferId;
    data['province_id'] = this.provinceId;
    data['district_id'] = this.districtId;
    data['ward_id'] = this.wardId;
    return data;
  }
}