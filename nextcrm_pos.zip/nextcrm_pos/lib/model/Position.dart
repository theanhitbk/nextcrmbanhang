import 'Meta.dart';

class PositionResponse {
  PositionResponse({
    // required this.meta,
    required this.data,
  });
  // late Meta meta;
  late List<Position> data = [];
  PositionResponse.fromJson(Map<String, dynamic> json) {
    // meta = Meta.fromJson(json['meta']);
    data = List.from(json['data']).map((e) => Position.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    // _data['meta'] = meta.toJson();
    _data['data'] = data.map((e) => e.toJson()).toList();
    return _data;
  }
}

class Position {
  Position({
    this.id = 0,
    this.name = '',
    this.rack,
    this.row,
  });
  late int id = 0;
  late String name = '';
  late String? rack;
  late String? row;

  Position.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    rack = json['rack'];
    row = json['row'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['name'] = name;
    _data['rack'] = rack;
    _data['row'] = row;
    return _data;
  }
}
class PositionRequest {
  late String name;
  late String description;

  PositionRequest({
    this.name = '',
    this.description = '',
  });

  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {
      'name': name,
      'description': description
    };
    return map;
  }
}
