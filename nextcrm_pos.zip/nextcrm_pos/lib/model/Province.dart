import 'Meta.dart';

class ProvinceResponse {
  ProvinceResponse({
    required this.data,
  });
  late List<Province> data = [];

  ProvinceResponse.fromJson(Map<String, dynamic> json) {
    data = List.from(json['data']).map((e) => Province.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['data'] = data.map((e) => e.toJson()).toList();
    return _data;
  }
}

class Province {
  Province({
    required this.id,
     this.name,
     this.code,
     this.divisionType,
     this.level,
     this.parentId,
     this.phoneCode,
  });
  late  int id = 0;
  late  String? name;
  late  String? code;
  late  String? divisionType;
  late  int? level;
  late  int? parentId;
  late  String? phoneCode;

  Province.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? 0;
    name = json['name'];
    code = json['code'];
    divisionType = json['division_type'];
    level = json['level'];
    parentId = json['parent_id'];
    phoneCode = json['phone_code'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['name'] = name;
    _data['code'] = code;
    _data['division_type'] = divisionType;
    _data['level'] = level;
    _data['parent_id'] = parentId;
    _data['phone_code'] = phoneCode;
    return _data;
  }
}
