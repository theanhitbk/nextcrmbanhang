class Payment {
  int? amount;
  String? method;
  String? note;
  int? accountId;
  String? paymentId;
  String? paymentType;

  Payment(
      {this.amount,
      this.method,
      this.note,
      this.accountId,
      this.paymentId,
      this.paymentType});

  Payment.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    method = json['method'];
    note = json['note'];
    accountId = json['account_id'];
    paymentId = json['payment_id'];
    paymentType = json['payment_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['amount'] = this.amount;
    data['method'] = this.method;
    data['note'] = this.note;
    data['account_id'] = this.accountId;
    data['payment_id'] = this.paymentId;
    data['payment_type'] = this.paymentType;
    return data;
  }
}