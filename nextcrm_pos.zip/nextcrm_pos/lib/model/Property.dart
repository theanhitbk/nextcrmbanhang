import 'Meta.dart';

class PropertyResponse {
  // late Meta meta;
  List<Property> data = [];

  PropertyResponse({
    // required this.meta, 
    required this.data
    });

  PropertyResponse.fromJson(Map<String, dynamic> json) {
    // meta = (json['meta'] != null ? new Meta.fromJson(json['meta']) : null)!;
    data = List.from(json['data']).map((e) => Property.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    // data['meta'] = this.meta.toJson();
    _data['data'] = data.map((e) => e.toJson()).toList();
    return _data;
  }
}

class Property {
  late int id;
  late String text;
  List<Values> values = [];
  bool isExpand = false;
  bool isSelected = false;

  Property({this.id = 0, this.text = '', required this.values});

  Property.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? 0;
    text = json['text'] ?? '';
    values = List.from(json['values']).map((e) => Values.fromJson(e)).toList();
    isSelected = json['is_selected'] == null ? false : json['is_selected'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = this.id;
    _data['text'] = this.text;
    _data['values'] = this.values.map((v) => v.toJson()).toList();
    _data['is_selected'] = this.isSelected;
    return _data;
  }
}

class Values {
  late int id;
  late String name;
  late int variationTemplateId;
  bool isSelected = false;

  Values({this.id = 0, this.name = '', this.variationTemplateId = 0});

  Values.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    variationTemplateId = json['variation_template_id'];
    isSelected = json['is_selected'] == null ? false : json['is_selected'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['variation_template_id'] = this.variationTemplateId;
    data['is_selected'] = this.isSelected;
    return data;
  }
}