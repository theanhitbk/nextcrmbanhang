class RefundResponse {
  RefundResponse({
    required this.data,
     this.recordsTotal = 0,
     this.recordsFiltered = 0,
  });
  late List<Refund> data = [];
  late int recordsTotal = 0;
  late int recordsFiltered = 0;

  RefundResponse.fromJson(Map<String, dynamic> json) {
    data = List.from(json['data']).map((e) => Refund.fromJson(e)).toList();
    recordsTotal = json['recordsTotal'];
    recordsFiltered = json['recordsFiltered'];
  }
}

class Refund {
  Refund({
    required this.id,
    this.transactionDate,
    this.invoiceNo,
    this.customerName,
    this.customerMobile,
    this.customerAddress,
    this.customerDescription,
    this.finalTotal,
    this.addedBy,
    this.branchName,
  });
  late int id = 0;
  late String? transactionDate;
  late String? invoiceNo;
  late String? customerName;
  late String? customerMobile;
  late String? customerAddress;
  late String? customerDescription;
  late int? finalTotal;
  late String? addedBy;
  late String? branchName;

  Refund.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    transactionDate = json['transaction_date'];
    invoiceNo = json['invoice_no'];
    customerName = json['customer_name'];
    customerMobile = json['customer_mobile'];
    customerAddress = json['customer_address'];
    customerDescription = json['customer_description'];
    finalTotal = json['final_total'];
    addedBy = json['added_by'];
    branchName = json['branch_name'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['transaction_date'] = transactionDate;
    _data['invoice_no'] = invoiceNo;
    _data['customer_name'] = customerName;
    _data['customer_mobile'] = customerMobile;
    _data['customer_address'] = customerAddress;
    _data['customer_description'] = customerDescription;
    _data['final_total'] = finalTotal;
    _data['added_by'] = addedBy;
    _data['branch_name'] = branchName;
    return _data;
  }
}
