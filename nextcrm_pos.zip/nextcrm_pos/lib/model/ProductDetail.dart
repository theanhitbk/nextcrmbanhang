import 'Unit.dart';

class ProductDetailResponse {
  ProductDetailData? data;

  ProductDetailResponse({this.data});

  ProductDetailResponse.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new ProductDetailData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProductDetailData {
  String? date;
  String? name;
  ProductDetail? product;
  List<Unit>? units;

  ProductDetailData({this.product, this.units, this.name, this.date});

  ProductDetailData.fromJson(Map<String, dynamic> json) {
    date = json['date'];
    name = json['name'];
    product =
        json['product'] != null ? new ProductDetail.fromJson(json['product']) : null;
    if (json['units'] != null) {
      units = <Unit>[];
      json['units'].forEach((v) {
        units!.add(new Unit.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.product != null) {
      data['product'] = this.product!.toJson();
    }
    if (this.units != null) {
      data['units'] = this.units!.map((v) => v.toJson()).toList();
    }
    data['name'] = this.name;
    data['date'] = this.date;

    return data;
  }
}

class ProductDetail {
  String? productName;
  int? productId;
  String? productType;
  int? enableStock;
  String? productCode;
  String? productActualName;
  String? productVariationName;
  String? variationName;
  String? productImage;
  String? subSku;
  String? qtyAvailable;
  String? defaultSellPrice;
  String? defaultPurchasePrice;
  String? costPrice;
  int? variationId;
  String? unit;
  int? unitId;
  String? brand;
  String? lastPurchasedPrice;
  int customerId = 0;
  List<LotNumbers>? lotNumbers;
  ProductDetail(
      {this.productName,
      this.productId,
      this.productType,
      this.enableStock,
      this.productCode,
      this.productActualName,
      this.productVariationName,
      this.variationName,
      this.productImage,
      this.subSku,
      this.qtyAvailable,
      this.defaultSellPrice,
      this.defaultPurchasePrice,
      this.costPrice,
      this.variationId,
      this.unit,
      this.unitId,
      this.brand,
      this.lastPurchasedPrice,
      this.customerId = 0,
      this.lotNumbers});

  ProductDetail.fromJson(Map<String, dynamic> json) {
    productName = json['product_name'];
    productId = json['product_id'];
    productType = json['product_type'];
    enableStock = json['enable_stock'];
    productCode = json['product_code'];
    productActualName = json['product_actual_name'];
    productVariationName = json['product_variation_name'];
    variationName = json['variation_name'];
    productImage = json['product_image'];
    subSku = json['sub_sku'];
    qtyAvailable = json['qty_available'];
    defaultSellPrice = json['default_sell_price'];
    defaultPurchasePrice = json['default_purchase_price'];
    costPrice = json['cost_price'];
    variationId = json['variation_id'];
    unit = json['unit'];
    unitId = json['unit_id'];
    brand = json['brand'];
    lastPurchasedPrice = json['last_purchased_price'];
    if (json['lot_numbers'] != null) {
      lotNumbers = <LotNumbers>[];
      json['lot_numbers'].forEach((v) {
        lotNumbers!.add(new LotNumbers.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['product_name'] = this.productName;
    data['product_id'] = this.productId;
    data['product_type'] = this.productType;
    data['enable_stock'] = this.enableStock;
    data['product_code'] = this.productCode;
    data['product_actual_name'] = this.productActualName;
    data['product_variation_name'] = this.productVariationName;
    data['variation_name'] = this.variationName;
    data['product_image'] = this.productImage;
    data['sub_sku'] = this.subSku;
    data['qty_available'] = this.qtyAvailable;
    data['default_sell_price'] = this.defaultSellPrice;
    data['default_purchase_price'] = this.defaultPurchasePrice;
    data['cost_price'] = this.costPrice;
    data['variation_id'] = this.variationId;
    data['unit'] = this.unit;
    data['unit_id'] = this.unitId;
    data['brand'] = this.brand;
    data['last_purchased_price'] = this.lastPurchasedPrice;
    if (this.lotNumbers != null) {
      data['lot_numbers'] = this.lotNumbers!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class LotNumbers {
  int? purchaseLineId;
  String? lotNumber;
  String? expDate;
  String? qtyAvailable;

  LotNumbers(
      {this.purchaseLineId, this.lotNumber, this.expDate, this.qtyAvailable});

  LotNumbers.fromJson(Map<String, dynamic> json) {
    purchaseLineId = json['purchase_line_id'];
    lotNumber = json['lot_number'];
    expDate = json['exp_date'];
    qtyAvailable = json['qty_available'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['purchase_line_id'] = this.purchaseLineId;
    data['lot_number'] = this.lotNumber;
    data['exp_date'] = this.expDate;
    data['qty_available'] = this.qtyAvailable;
    return data;
  }
}
