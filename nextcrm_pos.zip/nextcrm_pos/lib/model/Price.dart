import 'Meta.dart';

class PriceResponse {
  PriceResponse({
    // required this.meta,
    required this.data,
  });
  // late final Meta meta;
  late List<Price> data = [];
  
  PriceResponse.fromJson(Map<String, dynamic> json){
    // meta = Meta.fromJson(json['meta']);
    data = List.from(json['data']).map((e)=>Price.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    // _data['meta'] = meta.toJson();
    _data['data'] = data.map((e)=>e.toJson()).toList();
    return _data;
  }
}

class Price {
  Price({
     this.id = 0,
     this.name = '',
  });
  late int id;
  late String name;
  
  Price.fromJson(Map<String, dynamic> json){
    id = json['id'] ?? 0;
    name = json['name'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['name'] = name;
    return _data;
  }
}