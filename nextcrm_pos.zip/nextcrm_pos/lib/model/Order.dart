import 'Meta.dart';

class OrderResponse {
  List<Order>? data;
  Meta? meta;
  int? recordsTotal;
  int? recordsFiltered;
  Request? request;

  OrderResponse(
      {this.data,
      this.meta,
      this.recordsTotal,
      this.recordsFiltered,
      this.request});

  OrderResponse.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Order>[];
      json['data'].forEach((v) {
        data!.add(new Order.fromJson(v));
      });
    }
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    recordsTotal = json['recordsTotal'];
    recordsFiltered = json['recordsFiltered'];
    request =
        json['request'] != null ? new Request.fromJson(json['request']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    data['recordsTotal'] = this.recordsTotal;
    data['recordsFiltered'] = this.recordsFiltered;
    if (this.request != null) {
      data['request'] = this.request!.toJson();
    }
    return data;
  }
}

class Order {
  int? id;
  String? transactionDate;
  String? createdAt;
  String? updatedAt;
  int? isDirectSale;
  String? invoiceNo;
  String? customerName;
  String? customerMobile;
  String? customerAddress;
  String? customerDescription;
  String? paymentStatus;
  int? finalTotal;
  int? taxAmount;
  int? discountAmount;
  String? discountType;
  String? totalBeforeTax;
  String? typesOfServiceId;
  String? shippingStatus;
  String? payTermNumber;
  String? payTermType;
  String? additionalNotes;
  String? staffNote;
  String? shippingDetails;
  String? addedBy;
  int? totalPaid;
  String? branchName;
  int? returnExists;
  int? returnPaid;
  int? amountReturn;
  String? returnTransactionId;
  int? totalItems;
  List<SellLines>? sellLines;
  String? paymentMethods;
  String? status;
  Source? source;
  SalesPerson? salesPerson;
  List<Tags>? tags;
  List<PaymentLines>? paymentLines;
  int? approvedStatus;
  String? estimatedDeliveryDate;
  String? shippingCharges;
  String? modelName;

  Order(
      {this.id,
      this.transactionDate,
      this.createdAt,
      this.updatedAt,
      this.isDirectSale,
      this.invoiceNo,
      this.customerName,
      this.customerMobile,
      this.customerAddress,
      this.customerDescription,
      this.paymentStatus,
      this.finalTotal,
      this.taxAmount,
      this.discountAmount,
      this.discountType,
      this.totalBeforeTax,
      this.typesOfServiceId,
      this.shippingStatus,
      this.payTermNumber,
      this.payTermType,
      this.additionalNotes,
      this.staffNote,
      this.shippingDetails,
      this.addedBy,
      this.totalPaid,
      this.branchName,
      this.returnExists,
      this.returnPaid,
      this.amountReturn,
      this.returnTransactionId,
      this.totalItems,
      this.sellLines,
      this.paymentMethods,
      this.status,
      this.source,
      this.salesPerson,
      this.tags,
      this.paymentLines,
      this.approvedStatus,
      this.estimatedDeliveryDate,
      this.shippingCharges,
      this.modelName});

  Order.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    transactionDate = json['transaction_date'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    isDirectSale = json['is_direct_sale'];
    invoiceNo = json['invoice_no'];
    customerName = json['customer_name'];
    customerMobile = json['customer_mobile'];
    customerAddress = json['customer_address'];
    customerDescription = json['customer_description'];
    paymentStatus = json['payment_status'];
    finalTotal = json['final_total'];
    taxAmount = json['tax_amount'];
    discountAmount = json['discount_amount'];
    discountType = json['discount_type'];
    totalBeforeTax = json['total_before_tax'];
    typesOfServiceId = json['types_of_service_id'];
    shippingStatus = json['shipping_status'];
    payTermNumber = json['pay_term_number'];
    payTermType = json['pay_term_type'];
    additionalNotes = json['additional_notes'];
    staffNote = json['staff_note'];
    shippingDetails = json['shipping_details'];
    addedBy = json['added_by'];
    totalPaid = json['total_paid'];
    branchName = json['branch_name'];
    returnExists = json['return_exists'];
    returnPaid = json['return_paid'];
    amountReturn = json['amount_return'];
    returnTransactionId = json['return_transaction_id'];
    totalItems = json['total_items'];
    if (json['sell_lines'] != null) {
      sellLines = <SellLines>[];
      json['sell_lines'].forEach((v) {
        sellLines!.add(new SellLines.fromJson(v));
      });
    }
    paymentMethods = json['payment_methods'];
    status = json['status'];
    source =
        json['source'] != null ? new Source.fromJson(json['source']) : null;
    salesPerson = json['sales_person'] != null
        ? new SalesPerson.fromJson(json['sales_person'])
        : null;
    if (json['tags'] != null) {
      tags = <Tags>[];
      json['tags'].forEach((v) {
        tags!.add(new Tags.fromJson(v));
      });
    }
    if (json['payment_lines'] != null) {
      paymentLines = <PaymentLines>[];
      json['payment_lines'].forEach((v) {
        paymentLines!.add(new PaymentLines.fromJson(v));
      });
    }
    approvedStatus = json['approved_status'];
    estimatedDeliveryDate = json['estimated_delivery_date'];
    shippingCharges = json['shipping_charges'];
    modelName = json['model_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['transaction_date'] = this.transactionDate;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['is_direct_sale'] = this.isDirectSale;
    data['invoice_no'] = this.invoiceNo;
    data['customer_name'] = this.customerName;
    data['customer_mobile'] = this.customerMobile;
    data['customer_address'] = this.customerAddress;
    data['customer_description'] = this.customerDescription;
    data['payment_status'] = this.paymentStatus;
    data['final_total'] = this.finalTotal;
    data['tax_amount'] = this.taxAmount;
    data['discount_amount'] = this.discountAmount;
    data['discount_type'] = this.discountType;
    data['total_before_tax'] = this.totalBeforeTax;
    data['types_of_service_id'] = this.typesOfServiceId;
    data['shipping_status'] = this.shippingStatus;
    data['pay_term_number'] = this.payTermNumber;
    data['pay_term_type'] = this.payTermType;
    data['additional_notes'] = this.additionalNotes;
    data['staff_note'] = this.staffNote;
    data['shipping_details'] = this.shippingDetails;
    data['added_by'] = this.addedBy;
    data['total_paid'] = this.totalPaid;
    data['branch_name'] = this.branchName;
    data['return_exists'] = this.returnExists;
    data['return_paid'] = this.returnPaid;
    data['amount_return'] = this.amountReturn;
    data['return_transaction_id'] = this.returnTransactionId;
    data['total_items'] = this.totalItems;
    if (this.sellLines != null) {
      data['sell_lines'] = this.sellLines!.map((v) => v.toJson()).toList();
    }
    data['payment_methods'] = this.paymentMethods;
    data['status'] = this.status;
    if (this.source != null) {
      data['source'] = this.source!.toJson();
    }
    if (this.salesPerson != null) {
      data['sales_person'] = this.salesPerson!.toJson();
    }
    if (this.tags != null) {
      data['tags'] = this.tags!.map((v) => v.toJson()).toList();
    }
    if (this.paymentLines != null) {
      data['payment_lines'] =
          this.paymentLines!.map((v) => v.toJson()).toList();
    }
    data['approved_status'] = this.approvedStatus;
    data['estimated_delivery_date'] = this.estimatedDeliveryDate;
    data['shipping_charges'] = this.shippingCharges;
    data['model_name'] = this.modelName;
    return data;
  }
}

class SellLines {
  int? id;
  int? transactionId;
  int? productId;
  int? variationId;
  int? quantity;
  String? mfgWastePercent;
  String? quantityReturned;
  String? unitPriceBeforeDiscount;
  String? unitPrice;
  String? lineDiscountType;
  String? lineDiscountAmount;
  String? unitPriceIncTax;
  String? itemTax;
  Null? taxId;
  Null? discountId;
  Null? lotNoLineId;
  String? sellLineNote;
  Null? resServiceStaffId;
  Null? resLineOrderStatus;
  Null? parentSellLineId;
  Null? childrenType;
  int? subUnitId;
  String? fConvert;
  String? quantitySend;

  SellLines(
      {this.id,
      this.transactionId,
      this.productId,
      this.variationId,
      this.quantity,
      this.mfgWastePercent,
      this.quantityReturned,
      this.unitPriceBeforeDiscount,
      this.unitPrice,
      this.lineDiscountType,
      this.lineDiscountAmount,
      this.unitPriceIncTax,
      this.itemTax,
      this.taxId,
      this.discountId,
      this.lotNoLineId,
      this.sellLineNote,
      this.resServiceStaffId,
      this.resLineOrderStatus,
      this.parentSellLineId,
      this.childrenType,
      this.subUnitId,
      this.fConvert,
      this.quantitySend});

  SellLines.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    transactionId = json['transaction_id'];
    productId = json['product_id'];
    variationId = json['variation_id'];
    quantity = json['quantity'];
    mfgWastePercent = json['mfg_waste_percent'];
    quantityReturned = json['quantity_returned'];
    unitPriceBeforeDiscount = json['unit_price_before_discount'];
    unitPrice = json['unit_price'];
    lineDiscountType = json['line_discount_type'];
    lineDiscountAmount = json['line_discount_amount'];
    unitPriceIncTax = json['unit_price_inc_tax'];
    itemTax = json['item_tax'];
    taxId = json['tax_id'];
    discountId = json['discount_id'];
    lotNoLineId = json['lot_no_line_id'];
    sellLineNote = json['sell_line_note'];
    resServiceStaffId = json['res_service_staff_id'];
    resLineOrderStatus = json['res_line_order_status'];
    parentSellLineId = json['parent_sell_line_id'];
    childrenType = json['children_type'];
    subUnitId = json['sub_unit_id'];
    fConvert = json['f_convert'];
    quantitySend = json['quantity_send'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['transaction_id'] = this.transactionId;
    data['product_id'] = this.productId;
    data['variation_id'] = this.variationId;
    data['quantity'] = this.quantity;
    data['mfg_waste_percent'] = this.mfgWastePercent;
    data['quantity_returned'] = this.quantityReturned;
    data['unit_price_before_discount'] = this.unitPriceBeforeDiscount;
    data['unit_price'] = this.unitPrice;
    data['line_discount_type'] = this.lineDiscountType;
    data['line_discount_amount'] = this.lineDiscountAmount;
    data['unit_price_inc_tax'] = this.unitPriceIncTax;
    data['item_tax'] = this.itemTax;
    data['tax_id'] = this.taxId;
    data['discount_id'] = this.discountId;
    data['lot_no_line_id'] = this.lotNoLineId;
    data['sell_line_note'] = this.sellLineNote;
    data['res_service_staff_id'] = this.resServiceStaffId;
    data['res_line_order_status'] = this.resLineOrderStatus;
    data['parent_sell_line_id'] = this.parentSellLineId;
    data['children_type'] = this.childrenType;
    data['sub_unit_id'] = this.subUnitId;
    data['f_convert'] = this.fConvert;
    data['quantity_send'] = this.quantitySend;
    return data;
  }
}

class Source {
  int? id;
  String? name;
  String? picture;

  Source({this.id, this.name, this.picture});

  Source.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    picture = json['picture'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['picture'] = this.picture;
    return data;
  }
}

class SalesPerson {
  int? id;
  String? name;
  String? firstname;
  String? lastname;

  SalesPerson({this.id, this.name, this.firstname, this.lastname});

  SalesPerson.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    firstname = json['firstname'];
    lastname = json['lastname'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    return data;
  }
}

class Tags {
  String? name;
  String? color;
  int? order;
  int? id;
  int? tagItemsId;

  Tags({this.name, this.color, this.order, this.id, this.tagItemsId});

  Tags.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    color = json['color'];
    order = json['order'];
    id = json['id'];
    tagItemsId = json['tag_items_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['color'] = this.color;
    data['order'] = this.order;
    data['id'] = this.id;
    data['tag_items_id'] = this.tagItemsId;
    return data;
  }
}

class PaymentLines {
  int? id;
  int? transactionId;
  int? isReturn;
  String? amount;
  String? method;
  String? transactionNo;
  String? cardTransactionNumber;
  String? cardNumber;
  String? cardType;
  String? cardHolderName;
  String? cardMonth;
  String? cardYear;
  String? cardSecurity;
  String? chequeNumber;
  String? bankAccountNumber;
  String? paidOn;
  int? createdBy;
  int? paymentFor;
  int? parentId;
  String? note;
  String? document;
  String? paymentRefNo;
  String? accountId;
  int? tenantId;
  String? paymentType;
  String? paymentForEmployeeId;
  int? expenseId;
  int? branchId;
  String? objectType;
  String? transactionPaymentReferId;
  String? voucherId;

  PaymentLines(
      {this.id,
      this.transactionId,
      this.isReturn,
      this.amount,
      this.method,
      this.transactionNo,
      this.cardTransactionNumber,
      this.cardNumber,
      this.cardType,
      this.cardHolderName,
      this.cardMonth,
      this.cardYear,
      this.cardSecurity,
      this.chequeNumber,
      this.bankAccountNumber,
      this.paidOn,
      this.createdBy,
      this.paymentFor,
      this.parentId,
      this.note,
      this.document,
      this.paymentRefNo,
      this.accountId,
      this.tenantId,
      this.paymentType,
      this.paymentForEmployeeId,
      this.expenseId,
      this.branchId,
      this.objectType,
      this.transactionPaymentReferId,
      this.voucherId});

  PaymentLines.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    transactionId = json['transaction_id'];
    isReturn = json['is_return'];
    amount = json['amount'];
    method = json['method'];
    transactionNo = json['transaction_no'];
    cardTransactionNumber = json['card_transaction_number'];
    cardNumber = json['card_number'];
    cardType = json['card_type'];
    cardHolderName = json['card_holder_name'];
    cardMonth = json['card_month'];
    cardYear = json['card_year'];
    cardSecurity = json['card_security'];
    chequeNumber = json['cheque_number'];
    bankAccountNumber = json['bank_account_number'];
    paidOn = json['paid_on'];
    createdBy = json['created_by'];
    paymentFor = json['payment_for'];
    parentId = json['parent_id'];
    note = json['note'];
    document = json['document'];
    paymentRefNo = json['payment_ref_no'];
    accountId = json['account_id'];
    tenantId = json['tenant_id'];
    paymentType = json['payment_type'];
    paymentForEmployeeId = json['payment_for_employee_id'];
    expenseId = json['expense_id'];
    branchId = json['branch_id'];
    objectType = json['object_type'];
    transactionPaymentReferId = json['transaction_payment_refer_id'];
    voucherId = json['voucher_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['transaction_id'] = this.transactionId;
    data['is_return'] = this.isReturn;
    data['amount'] = this.amount;
    data['method'] = this.method;
    data['transaction_no'] = this.transactionNo;
    data['card_transaction_number'] = this.cardTransactionNumber;
    data['card_number'] = this.cardNumber;
    data['card_type'] = this.cardType;
    data['card_holder_name'] = this.cardHolderName;
    data['card_month'] = this.cardMonth;
    data['card_year'] = this.cardYear;
    data['card_security'] = this.cardSecurity;
    data['cheque_number'] = this.chequeNumber;
    data['bank_account_number'] = this.bankAccountNumber;
    data['paid_on'] = this.paidOn;
    data['created_by'] = this.createdBy;
    data['payment_for'] = this.paymentFor;
    data['parent_id'] = this.parentId;
    data['note'] = this.note;
    data['document'] = this.document;
    data['payment_ref_no'] = this.paymentRefNo;
    data['account_id'] = this.accountId;
    data['tenant_id'] = this.tenantId;
    data['payment_type'] = this.paymentType;
    data['payment_for_employee_id'] = this.paymentForEmployeeId;
    data['expense_id'] = this.expenseId;
    data['branch_id'] = this.branchId;
    data['object_type'] = this.objectType;
    data['transaction_payment_refer_id'] = this.transactionPaymentReferId;
    data['voucher_id'] = this.voucherId;
    return data;
  }
}

class Request {
  String? tenantcode;
  String? username;
  String? password;
  String? appType;
  String? pageLimit;
  String? page;
  String? invoiceCode;
  String? customerName;
  String? description;
  String? productCode;
  String? productName;
  String? fromDate;
  String? toDate;

  Request(
      {this.tenantcode,
      this.username,
      this.password,
      this.appType,
      this.pageLimit,
      this.page,
      this.invoiceCode,
      this.customerName,
      this.description,
      this.productCode,
      this.productName,
      this.fromDate,
      this.toDate});

  Request.fromJson(Map<String, dynamic> json) {
    tenantcode = json['tenantcode'];
    username = json['username'];
    password = json['password'];
    appType = json['app_type'];
    pageLimit = json['pageLimit'];
    page = json['page'];
    invoiceCode = json['invoice_code'];
    customerName = json['customer_name'];
    description = json['description'];
    productCode = json['product_code'];
    productName = json['product_name'];
    fromDate = json['from_date'];
    toDate = json['to_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['tenantcode'] = this.tenantcode;
    data['username'] = this.username;
    data['password'] = this.password;
    data['app_type'] = this.appType;
    data['pageLimit'] = this.pageLimit;
    data['page'] = this.page;
    data['invoice_code'] = this.invoiceCode;
    data['customer_name'] = this.customerName;
    data['description'] = this.description;
    data['product_code'] = this.productCode;
    data['product_name'] = this.productName;
    data['from_date'] = this.fromDate;
    data['to_date'] = this.toDate;
    return data;
  }
}