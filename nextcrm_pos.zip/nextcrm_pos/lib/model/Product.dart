import 'Unit.dart';

class ProductResponse {
  List<Product>? data;
  MetaProduct? meta;
  ProductResponse(
      {this.data, this.meta});

  ProductResponse.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Product>[];
      json['data'].forEach((v) {
        data!.add(new Product.fromJson(v));
      });
    }
    meta = json['meta'] == null ? null : MetaProduct.fromJson(json['meta']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['meta'] = this.meta == null ? null : this.meta?.toJson();
    return data;
  }
}

class Product {
  int? id;
  int? productId;
  String name = '';
  int? enableStock;
  String productImage = '';
  int? variationsId;
  String? variationName;
  String? qtyAvailable;
  String? sellingPrice;
  String? subSku;
  String? productCode;
  String? unit;
  int? unitId;
  int? totalOrdered;
  String? brand;
  String? productFullname;
  List<Unit>? units;

  Product(
      {this.id,
      this.productId,
      this.name = '',
      this.enableStock,
      this.productImage = '',
      this.variationsId,
      this.variationName,
      this.qtyAvailable,
      this.sellingPrice,
      this.subSku,
      this.productCode,
      this.unit,
      this.unitId,
      this.totalOrdered,
      this.brand,
      this.productFullname,
      this.units});

  Product.fromJson(Map<String, dynamic> json) {
    id = json['id'] == null ? null : json['id'] ;
    productId = json['product_id'] == null ? null :  json['product_id'];
    name = json['name'] == null ? '' :  json['name'];
    enableStock = json['enable_stock'] == null ? null :  json['enable_stock'];
    productImage = json['product_image'] == null ? '' : json['product_image'];
    variationsId = json['variations_id'] == null ? null :  json['variations_id'];
    variationName = json['variation_name'] == null ? null :  json['variation_name'];
    qtyAvailable = json['qty_available'] == null ? null :  json['qty_available'];
    sellingPrice = json['selling_price'] == null ? null :  json['selling_price'];
    subSku = json['sub_sku'] == null ? null :  json['sub_sku'];
    productCode = json['product_code'] == null ? null :  json['product_code'];
    unit = json['unit'] == null ? null :  json['unit'];
    unitId = json['unit_id'] == null ? null :  json['unit_id'];
    totalOrdered = json['total_ordered'] == null ? null :  json['total_ordered'];
    brand = json['brand'] == null ? null :  json['brand'];
    productFullname = json['product_fullname'] == null ? null :  json['product_fullname'];
    if (json['units'] != null) {
      units = <Unit>[];
      json['units'].forEach((v) {
        units!.add(new Unit.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['product_id'] = this.productId;
    data['name'] = this.name;
    data['enable_stock'] = this.enableStock;
    data['product_image'] = this.productImage;
    data['variations_id'] = this.variationsId;
    data['variation_name'] = this.variationName;
    data['qty_available'] = this.qtyAvailable;
    data['selling_price'] = this.sellingPrice;
    data['sub_sku'] = this.subSku;
    data['product_code'] = this.productCode;
    data['unit'] = this.unit;
    data['unit_id'] = this.unitId;
    data['total_ordered'] = this.totalOrdered;
    data['brand'] = this.brand;
    data['product_fullname'] = this.productFullname;
    if (this.units != null) {
      data['units'] = this.units!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Request {
  String? tenantcode;
  String? username;
  String? password;
  String? appType;
  String? pageLimit;
  String? page;

  Request(
      {this.tenantcode,
      this.username,
      this.password,
      this.appType,
      this.pageLimit,
      this.page});

  Request.fromJson(Map<String, dynamic> json) {
    tenantcode = json['tenantcode'];
    username = json['username'];
    password = json['password'];
    appType = json['app_type'];
    pageLimit = json['pageLimit'];
    page = json['page'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['tenantcode'] = this.tenantcode;
    data['username'] = this.username;
    data['password'] = this.password;
    data['app_type'] = this.appType;
    data['pageLimit'] = this.pageLimit;
    data['page'] = this.page;
    return data;
  }
}


// Meta metaFromJson(String str) => Meta.fromJson(json.decode(str));
//
// String metaToJson(Meta data) => json.encode(data.toJson());

class MetaProduct {
  MetaProduct({
    this.pagination,
    this.statusCode,
    this.message,
  });

  Pagination? pagination;
  int? statusCode;
  String? message;

  MetaProduct copyWith({
    Pagination? pagination,
    int? statusCode,
    String? message,
  }) =>
      MetaProduct(
        pagination: pagination ?? this.pagination,
        statusCode: statusCode ?? this.statusCode,
        message: message ?? this.message,
      );

  factory MetaProduct.fromJson(Map<String, dynamic> json) => MetaProduct(
    pagination: json["pagination"] == null ? null : Pagination.fromJson(json["pagination"]),
    statusCode: json["status_code"] == null ? null : json["status_code"],
    message: json["message"] == null ? null : json["message"],
  );

  Map<String, dynamic> toJson() => {
    "pagination": pagination == null ? null : pagination?.toJson(),
    "status_code": statusCode == null ? null : statusCode,
    "message": message == null ? null : message,
  };
}

class Pagination {
  Pagination({
    this.total,
    this.count,
    this.perPage,
    this.currentPage,
    this.totalPages,
    this.links,
  });

  int? total;
  int? count;
  int? perPage;
  int? currentPage;
  int? totalPages;
  Links? links;

  Pagination copyWith({
    int? total,
    int? count,
    int? perPage,
    int? currentPage,
    int? totalPages,
    Links? links,
  }) =>
      Pagination(
        total: total ?? this.total,
        count: count ?? this.count,
        perPage: perPage ?? this.perPage,
        currentPage: currentPage ?? this.currentPage,
        totalPages: totalPages ?? this.totalPages,
        links: links ?? this.links,
      );

  factory Pagination.fromJson(Map<String, dynamic> json) => Pagination(
    total: json["total"] == null ? null : json["total"],
    count: json["count"] == null ? null : json["count"],
    perPage: json["per_page"] == null ? null : json["per_page"],
    currentPage: json["current_page"] == null ? null : json["current_page"],
    totalPages: json["total_pages"] == null ? null : json["total_pages"],
    links: json["links"] == null ? null : Links.fromJson(json["links"]),
  );

  Map<String, dynamic> toJson() => {
    "total": total == null ? null : total,
    "count": count == null ? null : count,
    "per_page": perPage == null ? null : perPage,
    "current_page": currentPage == null ? null : currentPage,
    "total_pages": totalPages == null ? null : totalPages,
    "links": links == null ? null : links?.toJson(),
  };
}

class Links {
  Links({
    this.next,
    this.previous,
  });

  String? next;
  String? previous;

  Links copyWith({
    String? next,
    String? previous,
  }) =>
      Links(
        next: next ?? this.next,
        previous: previous ?? this.previous,
      );

  factory Links.fromJson(Map<String, dynamic> json) => Links(
    next: json["next"] == null ? null : json["next"],
    previous: json["previous"] == null ? null : json["previous"],
  );

  Map<String, dynamic> toJson() => {
    "next": next == null ? null : next,
    "previous": previous == null ? null : previous,
  };
}
