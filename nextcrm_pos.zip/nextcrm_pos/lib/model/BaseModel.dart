class MessageResponse {
  MessageResponse({
    required this.message,
    required this.statusCode,
  });
  late final String message;
  late final int statusCode;
  
  MessageResponse.fromJson(Map<String, dynamic> json){
    message = json['message'];
    statusCode = json['status_code'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['message'] = message;
    _data['status_code'] = statusCode;
    return _data;
  }
}