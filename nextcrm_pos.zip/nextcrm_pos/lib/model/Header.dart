class Header {
  late String authorization;

  Header({this.authorization = ''});

  Header.fromJson(Map<String, String> json) {
    authorization = json['Authorization'] ?? '';
  }

  Map<String, String> toJson() {
    final Map<String, String> data = new Map<String, String>();
    data['Authorization'] = this.authorization;
    return data;
  }
}