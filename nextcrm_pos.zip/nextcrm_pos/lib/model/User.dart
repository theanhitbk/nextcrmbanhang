import 'Employee.dart';
import 'branch.dart';

class User {
  int? id;
  String? email;
  String? username;
  String? tel;
  String? firstname;
  String? lastname;
  String? picture;
  String? joined;
  String? designation;
  List<Role>? roles;
  List<Permission>? permissions;
  List<Branch>? branches;
  bool? isAdmin;
  bool? isSupperUser;
  String? crmExtensionId;
  String? crmExtensionPwd;
  int? employeeId;
  Employee? employee;
  int? subscription;

  User(
      {this.id,
      this.email,
      this.username,
      this.tel,
      this.firstname,
      this.lastname,
      this.picture,
      this.joined,
      this.designation,
      this.roles,
      this.permissions,
      this.branches,
      this.isAdmin,
      this.isSupperUser,
      this.crmExtensionId,
      this.crmExtensionPwd,
      this.employeeId,
      this.employee,
      this.subscription});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    username = json['username'];
    tel = json['tel'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    picture = json['picture'];
    joined = json['joined'];
    designation = json['designation'];
    if (json['roles'] != null) {
      roles = <Role>[];
      json['roles'].forEach((v) {
        roles!.add(new Role.fromJson(v));
      });
    }
    if (json['permissions'] != null) {
      permissions = <Permission>[];
      json['permissions'].forEach((v) {
        permissions!.add(new Permission.fromJson(v));
      });
    }
    if (json['branches'] != null) {
      branches = <Branch>[];
      json['branches'].forEach((v) {
        branches!.add(new Branch.fromJson(v));
      });
    }
    isAdmin = json['isAdmin'];
    isSupperUser = json['isSupperUser'];
    crmExtensionId = json['crm_extension_id'];
    crmExtensionPwd = json['crm_extension_pwd'];
    employeeId = json['employee_id'];
    employee = json['employee'] != null
        ? new Employee.fromJson(json['employee'])
        : null;
    subscription = json['subscription'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['email'] = this.email;
    data['username'] = this.username;
    data['tel'] = this.tel;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['picture'] = this.picture;
    data['joined'] = this.joined;
    data['designation'] = this.designation;
    if (this.roles != null) {
      data['roles'] = this.roles!.map((v) => v.toJson()).toList();
    }
    if (this.permissions != null) {
      data['permissions'] = this.permissions!.map((v) => v.toJson()).toList();
    }
    if (this.branches != null) {
      data['branches'] = this.branches!.map((v) => v.toJson()).toList();
    }
    data['isAdmin'] = this.isAdmin;
    data['isSupperUser'] = this.isSupperUser;
    data['crm_extension_id'] = this.crmExtensionId;
    data['crm_extension_pwd'] = this.crmExtensionPwd;
    data['employee_id'] = this.employeeId;
    if (this.employee != null) {
      data['employee'] = this.employee!.toJson();
    }
    data['subscription'] = this.subscription;
    return data;
  }
}

class Permission {
  int? id;
  String? name;
  int? parentId;
  int? isAdd;
  int? isDelete;
  int? isUpdate;
  int? isActive;
  int? isImport;
  int? isExport;
  int? isView;

  Permission(
      {this.id,
      this.name,
      this.parentId,
      this.isAdd,
      this.isDelete,
      this.isUpdate,
      this.isActive,
      this.isImport,
      this.isExport,
      this.isView});

  Permission.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    parentId = json['parent_id'];
    isAdd = json['is_add'];
    isDelete = json['is_delete'];
    isUpdate = json['is_update'];
    isActive = json['is_active'];
    isImport = json['is_import'];
    isExport = json['is_export'];
    isView = json['is_view'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['parent_id'] = this.parentId;
    data['is_add'] = this.isAdd;
    data['is_delete'] = this.isDelete;
    data['is_update'] = this.isUpdate;
    data['is_active'] = this.isActive;
    data['is_import'] = this.isImport;
    data['is_export'] = this.isExport;
    data['is_view'] = this.isView;
    return data;
  }
}

class Role {
  int? id;
  String? name;
  String? slug;
  String? description;
  int? level;
  int? tenantId;
  String? deletedAt;
  Pivot? pivot;

  Role(
      {this.id,
      this.name,
      this.slug,
      this.description,
      this.level,
      this.tenantId,
      this.deletedAt,
      this.pivot});

  Role.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    slug = json['slug'];
    description = json['description'];
    level = json['level'];
    tenantId = json['tenant_id'];
    deletedAt = json['deleted_at'];
    pivot = json['pivot'] != null ? new Pivot.fromJson(json['pivot']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['slug'] = this.slug;
    data['description'] = this.description;
    data['level'] = this.level;
    data['tenant_id'] = this.tenantId;
    data['deleted_at'] = this.deletedAt;
    if (this.pivot != null) {
      data['pivot'] = this.pivot!.toJson();
    }
    return data;
  }
}

class Pivot {
  int? userId;
  int? roleId;
  String? createdAt;
  String? updatedAt;

  Pivot({this.userId, this.roleId, this.createdAt, this.updatedAt});

  Pivot.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    roleId = json['role_id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['role_id'] = this.roleId;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
