import 'package:flutter/cupertino.dart';

class ProductRequest {
  String? name;
  String? code;
  String? sku;
  int? brandId;
  String? categoryId;
  List<Media>? media;
  int? costPrice;
  int? purchasePrice;
  int? sellPrice;
  int? beginStock;
  int? weight;
  UnitRequest? unit;
  List<int>? productRacks;
  String? description;
  String? productCustomField1;
  int? stockMin;
  int? stockMax;
  List<int>? productBranches;
  bool notForSelling;
  bool isInactive;
  List<ProductVariation>? productVariation;
  bool enableStock;

  ProductRequest(
      {this.name,
      this.code,
      this.sku,
      this.brandId,
      this.categoryId,
      this.media,
      this.costPrice,
      this.purchasePrice,
      this.sellPrice,
      this.beginStock,
      this.weight,
      this.unit,
      this.productRacks,
      this.description,
      this.productCustomField1,
      this.stockMin,
      this.stockMax,
      this.productBranches,
      this.notForSelling = true,
      this.isInactive = true,
      this.productVariation,
      this.enableStock = true});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['code'] = this.code;
    data['sku'] = this.sku;
    data['brand_id'] = this.brandId;
    data['category_id'] = this.categoryId;
    if (this.media != null) {
      data['media'] = this.media!.map((v) => v.toJson()).toList();
    }
    data['cost_price'] = this.costPrice;
    data['purchase_price'] = this.purchasePrice;
    data['sell_price'] = this.sellPrice;
    data['begin_stock'] = this.beginStock;
    data['weight'] = this.weight;
    if (this.unit != null) {
      data['unit'] = this.unit!.toJson();
    }
    data['product_racks'] = this.productRacks;
    data['description'] = this.description;
    data['product_custom_field1'] = this.productCustomField1;
    data['stock_min'] = this.stockMin;
    data['stock_max'] = this.stockMax;
    data['product_branches'] = this.productBranches;
    data['not_for_selling'] = this.notForSelling;
    data['is_inactive'] = this.isInactive;
    if (this.productVariation != null) {
      data['product_variation'] =
          this.productVariation!.map((v) => v.toJson()).toList();
    }
    data['enable_stock'] = this.enableStock;
    return data;
  }
}

class Media {
  String? url;

  Media({this.url});

  Media.fromJson(Map<String, dynamic> json) {
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['url'] = this.url;
    return data;
  }
}

class UnitRequest {
  UnitBase? unitBase;
  List<SubUnit>? subUnit;

  UnitRequest({this.unitBase, this.subUnit});

  UnitRequest.fromJson(Map<String, dynamic> json) {
    unitBase = json['unit_base'] != null
        ? new UnitBase.fromJson(json['unit_base'])
        : null;
    if (json['sub_unit'] != null) {
      subUnit = <SubUnit>[];
      json['sub_unit'].forEach((v) {
        subUnit!.add(new SubUnit.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.unitBase != null) {
      data['unit_base'] = this.unitBase!.toJson();
    }
    if (this.subUnit != null) {
      data['sub_unit'] = this.subUnit!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UnitBase {
  String? name;
  bool? isDirectSell;

  UnitBase({this.name, this.isDirectSell});

  UnitBase.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    isDirectSell = json['is_direct_sell'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['is_direct_sell'] = this.isDirectSell;
    return data;
  }
}

class SubUnit {
  int? index;
  String? name;
  int? fConvert;
  int? price;
  bool? isDirectSell;

  TextEditingController nameUnitController = new TextEditingController();
  TextEditingController fUnitController = new TextEditingController();
  TextEditingController priceUnitController = new TextEditingController();

  SubUnit(
      {this.index, this.name, this.fConvert, this.price, this.isDirectSell});

  SubUnit.fromJson(Map<String, dynamic> json) {
    index = json['index'];
    name = json['name'];
    fConvert = json['f_Convert'];
    price = json['price'];
    isDirectSell = json['is_direct_sell'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['index'] = this.index;
    data['name'] = this.name;
    data['f_Convert'] = this.fConvert;
    data['price'] = this.price;
    data['is_direct_sell'] = this.isDirectSell;
    return data;
  }
}

class ProductVariation {
  int? variationTemplateId;
  List<Variations>? variations;

  ProductVariation({this.variationTemplateId, this.variations});

  ProductVariation.fromJson(Map<String, dynamic> json) {
    variationTemplateId = json['variation_template_id'];
    if (json['variations'] != null) {
      variations = <Variations>[];
      json['variations'].forEach((v) {
        variations!.add(new Variations.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['variation_template_id'] = this.variationTemplateId;
    if (this.variations != null) {
      data['variations'] = this.variations!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Variations {
  String? variationName;
  int? index;
  String? subSku;
  int? stock;
  int? defaultPurchasePrice;
  int? defaultSellPrice;

  Variations(
      {this.variationName,
      this.index,
      this.subSku,
      this.stock,
      this.defaultPurchasePrice,
      this.defaultSellPrice});

  Variations.fromJson(Map<String, dynamic> json) {
    variationName = json['variation_name'];
    index = json['index'];
    subSku = json['sub_sku'];
    stock = json['stock'];
    defaultPurchasePrice = json['default_purchase_price'];
    defaultSellPrice = json['default_sell_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['variation_name'] = this.variationName;
    data['index'] = this.index;
    data['sub_sku'] = this.subSku;
    data['stock'] = this.stock;
    data['default_purchase_price'] = this.defaultPurchasePrice;
    data['default_sell_price'] = this.defaultSellPrice;
    return data;
  }
}