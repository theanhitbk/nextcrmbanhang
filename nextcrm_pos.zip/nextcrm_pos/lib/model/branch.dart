import 'Meta.dart';
class BranchResponse {
  BranchResponse({
     required this.meta,
     required this.data,
  });
  late  Meta meta;
  late  List<Branch> data = [];
  
  BranchResponse.fromJson(Map<String, dynamic> json){
    meta = Meta.fromJson(json['meta']);
    data = List.from(json['data']).map((e)=>Branch.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['meta'] = meta.toJson();
    _data['data'] = data.map((e)=>e.toJson()).toList();
    return _data;
  }
}

class Branch {
  int? id;
  String? name;
  String? code;
  String? tel;
  String? address;

  Branch({this.id, this.name, this.code});

  Branch.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    code = json['code'];
    tel = json['tel'];
    address = json['address'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['code'] = this.code;
    data['address'] = this.address;
    data['tel'] = this.tel;
    return data;
  }
}