import 'Meta.dart';

class CategoryResponse {
  Meta? meta;
  List<Category>? data;

  CategoryResponse({this.meta, this.data});

  CategoryResponse.fromJson(Map<String, dynamic> json) {
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      data = <Category>[];
      json['data'].forEach((v) {
        data!.add(new Category.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Category {
  String? name;
  int? id;
  int? parentId;
  String? description;
  Null? picture;

  Category({this.name, this.id, this.parentId, this.description, this.picture});

  Category.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    id = json['id'];
    parentId = json['parent_id'];
    description = json['description'];
    picture = json['picture'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['id'] = this.id;
    data['parent_id'] = this.parentId;
    data['description'] = this.description;
    data['picture'] = this.picture;
    return data;
  }
}
