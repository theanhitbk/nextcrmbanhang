import 'Meta.dart';

class ChannelResponse {
  Meta? meta;
  List<Channel>? channel;

  ChannelResponse({this.meta, this.channel});

  ChannelResponse.fromJson(Map<String, dynamic> json) {
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      channel = <Channel>[];
      json['data'].forEach((v) {
        channel!.add(new Channel.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    if (this.channel != null) {
      data['data'] = this.channel!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Channel {
  late int id;
  late String name;
  String? shortCode;
  int? parentId;
  String? slug;
  String? picture;

  Channel(
      {this.id = 0,
      this.name = '',
      this.shortCode,
      this.parentId,
      this.slug,
      this.picture});

  Channel.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? 0;
    name = json['name'] ?? '';
    shortCode = json['short_code'];
    parentId = json['parent_id'];
    slug = json['slug'];
    picture = json['picture'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_code'] = this.shortCode;
    data['parent_id'] = this.parentId;
    data['slug'] = this.slug;
    data['picture'] = this.picture;
    return data;
  }
}
