import 'Meta.dart';

class BankAcountResponse {
  Meta? meta;
  List<BankAcount>? data;

  BankAcountResponse({this.meta, this.data});

  BankAcountResponse.fromJson(Map<String, dynamic> json) {
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      data = <BankAcount>[];
      json['data'].forEach((v) {
        data!.add(new BankAcount.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class BankAcount {
  int? id;
  String? name;
  String? accountNumber;
  int? accountTypeId;
  String? note;
  int? createdBy;
  int? isClosed;
  AccountType? accountType;
  String? addedBy;
  String? accountTypeName;
  String? parentAccountTypeName;
  String? balance;

  BankAcount(
      {this.id,
      this.name,
      this.accountNumber,
      this.accountTypeId,
      this.note,
      this.createdBy,
      this.isClosed,
      this.accountType,
      this.addedBy,
      this.accountTypeName,
      this.parentAccountTypeName,
      this.balance});

  BankAcount.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    accountNumber = json['account_number'];
    accountTypeId = json['account_type_id'];
    note = json['note'];
    createdBy = json['created_by'];
    isClosed = json['is_closed'];
    accountType = json['account_type'] != null
        ? new AccountType.fromJson(json['account_type'])
        : null;
    addedBy = json['added_by'];
    accountTypeName = json['account_type_name'];
    parentAccountTypeName = json['parent_account_type_name'];
    balance = json['balance'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['account_number'] = this.accountNumber;
    data['account_type_id'] = this.accountTypeId;
    data['note'] = this.note;
    data['created_by'] = this.createdBy;
    data['is_closed'] = this.isClosed;
    if (this.accountType != null) {
      data['account_type'] = this.accountType!.toJson();
    }
    data['added_by'] = this.addedBy;
    data['account_type_name'] = this.accountTypeName;
    data['parent_account_type_name'] = this.parentAccountTypeName;
    data['balance'] = this.balance;
    return data;
  }
}

class AccountType {
  int? id;
  String? name;
  String? description;
  String? parentAccountTypeId;
  int? tenantId;

  AccountType(
      {this.id,
      this.name,
      this.description,
      this.parentAccountTypeId,
      this.tenantId});

  AccountType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    description = json['description'];
    parentAccountTypeId = json['parent_account_type_id'];
    tenantId = json['tenant_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['description'] = this.description;
    data['parent_account_type_id'] = this.parentAccountTypeId;
    data['tenant_id'] = this.tenantId;
    return data;
  }
}

