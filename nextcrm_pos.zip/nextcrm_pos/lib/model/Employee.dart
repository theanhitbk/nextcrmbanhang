import 'Meta.dart';

class EmployeeResponse {
  EmployeeResponse({
    this.meta,
    required this.data,
  });
  late  Meta? meta;
  late  List<Employee> data = [];
  
  EmployeeResponse.fromJson(Map<String, dynamic> json){
    meta = Meta.fromJson(json['meta']);
    data = List.from(json['data']).map((e)=>Employee.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['meta'] = meta!.toJson();
    _data['data'] = data.map((e)=>e.toJson()).toList();
    return _data;
  }
}

class Employee {
  int? id;
  String? code;
  String? firstName;
  String? lastName;
  String? enrollNumber;
  int? sex;
  String? birthdate;
  String? address;
  String? tel;
  String? email;
  String? avatar;
  String? idCard;
  String? beginDate;
  int? isOffWork;
  int? isPt;
  int? isSale;
  String? description;
  int? branchId;
  int? tenantId;

  Employee(
      {this.id,
      this.code,
      this.firstName,
      this.lastName,
      this.enrollNumber,
      this.sex,
      this.birthdate,
      this.address,
      this.tel,
      this.email,
      this.avatar,
      this.idCard,
      this.beginDate,
      this.isOffWork,
      this.isPt,
      this.isSale,
      this.description,
      this.branchId,
      this.tenantId});

  Employee.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    code = json['code'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    enrollNumber = json['enroll_number'];
    sex = json['sex'];
    birthdate = json['birthdate'];
    address = json['address'];
    tel = json['tel'];
    email = json['email'];
    avatar = json['avatar'];
    idCard = json['id_card'];
    beginDate = json['begin_date'];
    isOffWork = json['is_off_work'];
    isPt = json['isPt'];
    isSale = json['isSale'];
    description = json['description'];
    branchId = json['branch_id'];
    tenantId = json['tenant_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['code'] = this.code;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['enroll_number'] = this.enrollNumber;
    data['sex'] = this.sex;
    data['birthdate'] = this.birthdate;
    data['address'] = this.address;
    data['tel'] = this.tel;
    data['email'] = this.email;
    data['avatar'] = this.avatar;
    data['id_card'] = this.idCard;
    data['begin_date'] = this.beginDate;
    data['is_off_work'] = this.isOffWork;
    data['isPt'] = this.isPt;
    data['isSale'] = this.isSale;
    data['description'] = this.description;
    data['branch_id'] = this.branchId;
    data['tenant_id'] = this.tenantId;
    return data;
  }
}