import 'Meta.dart';

class BrandResponse {
  BrandResponse({
    // required this.meta,
    required this.data,
  });
  // late final Meta meta;
  late List<Brand> data = [];
  
  BrandResponse.fromJson(Map<String, dynamic> json){
    // meta = Meta.fromJson(json['meta']);
    data = List.from(json['data']).map((e)=>Brand.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    // _data['meta'] = meta.toJson();
    _data['data'] = data.map((e)=>e.toJson()).toList();
    return _data;
  }
}

class Brand {
  Brand({
     this.id = 0,
     this.text = '',
  });
  late int id;
  late String text;
  
  Brand.fromJson(Map<String, dynamic> json){
    id = json['id'] ?? 0;
    text = json['text'] ?? '';
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['text'] = text;
    return _data;
  }
}