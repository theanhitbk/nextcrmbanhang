import 'Payment.dart';
import 'PurchaseRequest.dart';

class SellRequest {
  String? transactionDate;
  int? branchId;
  int? customerId;
  int? priceBookId;
  String? discountType;
  int? discountAmount;
  int? totalBeforeTax;
  int? taxAmount;
  int? finalTotal;
  String? shippingDetails;
  String? shippingAddress;
  String? shippingStatus;
  String? deliveredTo;
  String? saleNote;
  String? additionalNotes;
  String? staffNote;
  String? isSuspend;
  String? status;
  int? sourceId;
  int? isDeliver;
  int? userId;
  String? purchaseId;
  String? deposit;
  String? estimatedDeliveryDate;
  int? shippingCharges;
  List<Products>? products;
  List<Payment>? payment;
  String? invoiceNo;

  SellRequest(
      {this.transactionDate,
      this.branchId,
      this.customerId,
      this.priceBookId,
      this.discountType,
      this.discountAmount,
      this.totalBeforeTax,
      this.taxAmount,
      this.finalTotal,
      this.shippingDetails,
      this.shippingAddress,
      this.shippingStatus,
      this.deliveredTo,
      this.saleNote,
      this.additionalNotes,
      this.staffNote,
      this.isSuspend,
      this.status,
      this.sourceId,
      this.isDeliver,
      this.userId,
      this.purchaseId,
      this.deposit,
      this.estimatedDeliveryDate,
      this.shippingCharges,
      this.products,
      this.payment,
      this.invoiceNo});

  SellRequest.fromJson(Map<String, dynamic> json) {
    transactionDate = json['transaction_date'];
    branchId = json['branch_id'];
    customerId = json['customer_id'];
    priceBookId = json['price_book_id'];
    discountType = json['discount_type'];
    discountAmount = json['discount_amount'];
    totalBeforeTax = json['total_before_tax'];
    taxAmount = json['tax_amount'];
    finalTotal = json['final_total'];
    shippingDetails = json['shipping_details'];
    shippingAddress = json['shipping_address'];
    shippingStatus = json['shipping_status'];
    deliveredTo = json['delivered_to'];
    saleNote = json['sale_note'];
    additionalNotes = json['additional_notes'];
    staffNote = json['staff_note'];
    isSuspend = json['is_suspend'];
    status = json['status'];
    sourceId = json['source_id'];
    isDeliver = json['is_deliver'];
    userId = json['user_id'];
    purchaseId = json['purchase_id'];
    deposit = json['deposit'];
    estimatedDeliveryDate = json['estimated_delivery_date'];
    shippingCharges = json['shipping_charges'];
    if (json['products'] != null) {
      products = <Products>[];
      json['products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
    if (json['payment'] != null) {
      payment = <Payment>[];
      json['payment'].forEach((v) {
        payment!.add(new Payment.fromJson(v));
      });
    }
    invoiceNo = json['invoice_no'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['transaction_date'] = this.transactionDate;
    data['branch_id'] = this.branchId;
    data['customer_id'] = this.customerId;
    data['price_book_id'] = this.priceBookId;
    data['discount_type'] = this.discountType;
    data['discount_amount'] = this.discountAmount;
    data['total_before_tax'] = this.totalBeforeTax;
    data['tax_amount'] = this.taxAmount;
    data['final_total'] = this.finalTotal;
    data['shipping_details'] = this.shippingDetails;
    data['shipping_address'] = this.shippingAddress;
    data['shipping_status'] = this.shippingStatus;
    data['delivered_to'] = this.deliveredTo;
    data['sale_note'] = this.saleNote;
    data['additional_notes'] = this.additionalNotes;
    data['staff_note'] = this.staffNote;
    data['is_suspend'] = this.isSuspend;
    data['status'] = this.status;
    data['source_id'] = this.sourceId;
    data['is_deliver'] = this.isDeliver;
    data['user_id'] = this.userId;
    data['purchase_id'] = this.purchaseId;
    data['deposit'] = this.deposit;
    data['estimated_delivery_date'] = this.estimatedDeliveryDate;
    data['shipping_charges'] = this.shippingCharges;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    if (this.payment != null) {
      data['payment'] = this.payment!.map((v) => v.toJson()).toList();
    }
    data['invoice_no'] = this.invoiceNo;
    return data;
  }
}
