import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/firebase_notification_handler.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/global_key.dart';
import 'package:vidifi/view/history/history.dart';
import 'package:vidifi/view/home/home.dart';
import 'package:vidifi/view/invoice/cubit/temporary_cubit.dart';
import 'package:vidifi/view/invoice/temporary_invoice.dart';
import 'package:vidifi/view/login.dart';
import 'package:vidifi/view/notification/notification.dart';
import 'package:vidifi/view/profile/profile.dart';
import 'package:vidifi/view/more/more.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_backgroundHandler);
  final appDocumentDirectory = await getApplicationDocumentsDirectory();
  Hive.init(appDocumentDirectory.path);
  await Hive.openBox('hive_box');
  // TemporaryInvoiceManager.getInstance()?.getTemporaryInvoiceData();
  runApp(ProviderScope(child: MyApp()));
}

class MyApp extends StatefulWidget {
  @override
  MyAppSate createState() => MyAppSate();
}

class MyAppSate extends State<MyApp> {
  FirebaseNotifications firebaseNotifications = new FirebaseNotifications();
  String _token = '';
  String _tokenFcm = '';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      firebaseNotifications.setupFirebase(context);
    });
    _loadToken();
    // _loadTokenFcm();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<TemporaryCubit>(create: (context) => TemporaryCubit()),
        BlocProvider<ProfileCubit>(create: (context) => ProfileCubit()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: "Bottom navigation",
        theme: ThemeData(primaryColor: Colors.white),
        home: _token.isEmpty ? LoginView() : Home(),
        navigatorKey: NavigationService.navigatorKey,
      ),
    );
  }

  void _loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _token = prefs.getString('token') ?? '';
    });
  }

  void _loadTokenFcm() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _tokenFcm = prefs.getString('tokenFcm') ?? '';
      addDeviceFcm();
    });
  }

  void addDeviceFcm() {
    print('Token fcm: $_tokenFcm');
    APIService apiService = new APIService();
    apiService
        .addDeviceFCM(_tokenFcm)
        .then((value) => {print(value ? 'Put fcm token success' : 'Put fcm token failed')});
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;
  Widget _myHome = MyHome();
  Widget _noticePage = NotificationPage();
  Widget _historyPage = HistoryPage();
  Widget _profilePage = ProfilePage();
  Widget _morePage = MorePage();
  Widget _tempPage = TemporaryPage();
  List<Widget> pages = [];
  int badgeTemporary = 0;

  @override
  void initState() {
    super.initState();
    context.read<TemporaryCubit>().getTemporaryInvoiceData();
    context.read<ProfileCubit>().getCurrentUser();
    context.read<ProfileCubit>().getCurrentBranch();
    pages = [_myHome, _tempPage, _historyPage, _morePage];
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TemporaryCubit, TemporaryState>(
      listener: (context, state) {
        if (state is TemporaryFetchSuccess) {
          badgeTemporary = state.temporaryInvoice.data?.length ?? 0;
        }
      },
      builder: (context, state) {
        return Scaffold(
          // body: this.getBody(),
          body: IndexedStack(
            index: _currentIndex,
            children: pages,
          ),
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _currentIndex,
            type: BottomNavigationBarType.fixed,
            iconSize: 24,
            items: [
              BottomNavigationBarItem(
                icon: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    child: Icon(
                      Icons.badge,
                      size: 28,
                    )),
                label: 'Bán hàng',
              ),
              BottomNavigationBarItem(
                icon: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      child: Icon(
                        Icons.pages,
                        size: 28,
                      ),
                    ),
                    Visibility(
                      visible: badgeTemporary > 0,
                      child: Positioned(
                        // draw a red marble
                        top: 0.0,
                        right: 0.0,
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.red),
                          // padding: EdgeInsets.all(5),
                          child: Center(
                            child: Text(
                              badgeTemporary > 9 ? '9+' : badgeTemporary.toString(),
                              style: TextStyle(color: Colors.white, fontSize: 10),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                label: 'Đơn tạm',
              ),
              BottomNavigationBarItem(
                icon: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    child: Icon(
                      Icons.history,
                      size: 28,
                    )),
                label: 'Lịch sử',
              ),
              BottomNavigationBarItem(
                icon: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    child: Icon(
                      Icons.menu,
                      size: 28,
                    )),
                label: 'More',
              ),
            ],
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
          ),
        );
      },
    );
  }

  Widget? getBody() {
    switch (_currentIndex) {
      case 0:
        {
          return this._myHome;
        }
      case 1:
        {
          return this._tempPage;
        }
      case 2:
        {
          return this._historyPage;
        }
      case 3:
        {
          return this._morePage;
        }
      default:
        return null;
    }
  }
}

Future<void> _backgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print('Handle background service $message');
  dynamic data = message.data['data'];
  FirebaseNotifications.showNotification(data['title'], data['body']);
}
