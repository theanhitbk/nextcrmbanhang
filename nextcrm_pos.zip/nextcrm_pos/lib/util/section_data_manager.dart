import 'package:vidifi/model/Property.dart';

class SectionDataManager {
  static SectionDataManager? _instance;
  static PropertyResponse? propertyResponse;

  SectionDataManager._();

  static SectionDataManager? getInstance() {
    if (_instance == null) {
      _instance = new SectionDataManager._();
    }
    return _instance;
  }

  void savePropertyResponse(PropertyResponse property) {
    propertyResponse = property;
  }

  PropertyResponse? returnProperty() {
    return propertyResponse ?? null;
  }

}