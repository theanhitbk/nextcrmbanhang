import 'dart:async';

import 'package:flutter/material.dart';

class LoadingDialog {
  late final BuildContext bContext;
  LoadingDialog(this.bContext);
  Timer? _timer;
  int _start = 25;

  bool isShowing = false;

  // static final LoadingDialog _instance = new LoadingDialog.internal(this.bContext);
  //
  // LoadingDialog.internal(this.bContext);

  // factory LoadingDialog() {
  //   return _instance;
  // }

  show({bool cancelable = false}) async {
    if (isShowing) return;
    isShowing = true;
    print('SHOWWW');
    _showDialog(cancelable);
    startTimer(); // Auto dismiss dialog loading
  }

  Future<void> dismiss() async {
    await Future.delayed(Duration(milliseconds: 100));
    if (isShowing) {
      Navigator.of(bContext).pop();
      _timer?.cancel();
    }
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _start = 25;
    _timer = Timer.periodic(
      oneSec,
          (Timer timer) {
        print(_start.toString());
        if (_start <= 0) {
          timer.cancel();
          dismiss();
        } else {
          _start--;
        }
      },
    );
  }

  void _showDialog(bool canPop) {
    showDialog(
        context: bContext,
        builder: (BuildContext ct) => WillPopScope(
          onWillPop: () async {
            return canPop;
          },
          child: Center(
            child: Container(
              width: 165,
              height: 118,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.white,
              ),
              child: Center(child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16,),
                  Text('Loading...', style: TextStyle(color: Colors.blue, fontSize: 14,
                    decoration: TextDecoration.none,),),
                ],
              )),
            ),
          ),
        ),
        barrierDismissible: false,
        barrierColor: Color(0xff73000000))
        .then((value) {
      isShowing = false;
      _timer?.cancel();
    });
  }
}
