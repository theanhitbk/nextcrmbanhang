
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/view/invoice/cubit/temporary_cubit.dart';
import 'package:provider/src/provider.dart';
import 'package:vidifi/view/login.dart';

class RemoveTokenAndCached {
  late final BuildContext bContext;

  RemoveTokenAndCached(this.bContext);

  static final navKey = new GlobalKey<NavigatorState>();
  void remove() async {
    HiveManager.getInstance()?.clear();
    navKey.currentContext?.read<TemporaryCubit>().removeData();
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
      Navigator.pushAndRemoveUntil(
          bContext,
          MaterialPageRoute(
              builder: (context) => LoginView()),
              (route) => false);
  }
}