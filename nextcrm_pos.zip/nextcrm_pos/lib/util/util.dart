import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';

import 'global_key.dart';
import 'handle_logout.dart';

String convertToCurrency(int amount, {bool unit = true}) {
  final formatter = new NumberFormat("#,###", "en_US");
  return formatter.format(amount).replaceAll('.', ',') + (unit ? "₫" : "");
}

bool stringIsEmptyOrNull(String? inputString) {
  if (inputString == null || inputString.isEmpty) {
    return true;
  } else {
    return false;
  }
}

String dateTimeStringFromInt(int time) {
  var date = DateTime.fromMillisecondsSinceEpoch(time * 1000);
  String formatDateTime = DateFormat('dd/MM/yyyy - HH:mm').format(date);
  return formatDateTime;
}

String dateFormatToString(DateTime dateTime) {
  return DateFormat('HH:mm - dd/MM/yyyy').format(dateTime);
}
//yyyy-MM-dd kk:mm:ss
String getDateFromString(String stringDate) {
  DateTime dateTime = new DateFormat('yyyy-MM-dd HH:mm:ss').parse(stringDate);
  String time = DateFormat('dd/MM/yyyy').format(dateTime);
  stringDate = time;
  return stringDate;
}

String formatDateTime(String stringDate) {
  DateTime dateTime = new DateFormat('yyyy-MM-dd HH:mm:ss').parse(stringDate);
  String time = DateFormat('dd/MM/yyyy HH:mm').format(dateTime);
  stringDate = time;
  return stringDate;
}

String getTimeFromString(String stringTime) {
  DateTime dateTime = new DateFormat('yyyy-MM-dd HH:mm:ss').parse(stringTime);
  String time = DateFormat('HH:mm').format(dateTime);
  stringTime = time;
  return stringTime;
}

String getTodayLabel(String stringDate) {
 String input = getDateFromString(stringDate);
 String today = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
 today = getDateFromString(today);
 String dayWeek = DateFormat('EEEE').format(DateFormat('yyyy-MM-dd HH:mm:ss').parse(stringDate));
  return today == input ? 'Hôm nay, ' : '${convertVNeseDay(dayWeek)}, ';
}

String convertVNeseDay(String day) {
  switch (day) {
    case 'Monday':
      return 'Thứ hai';
    case 'Tuesday':
      return 'Thứ ba';
    case 'Wednesday':
      return 'Thứ tư';
    case 'Thursday':
      return 'Thứ năm';
    case 'Friday':
      return 'Thứ sáu';
    case 'Saturday':
      return 'Thứ bảy';
    case 'Sunday':
      return 'Chủ nhật';
  }
  return'';
}

void showToastCustom(
    {message, backgroundColor, textColor}) {
  Fluttertoast.showToast(
      msg: message ?? '',
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 2,
      backgroundColor: backgroundColor,
      textColor: textColor,
      fontSize: 16.0);
}

void showToastSuccess(message) {
  showToastCustom(
      message: message,
      backgroundColor: Color(0xff31AE4A),
      textColor: Colors.white,);
}

void showToastFailed(message) {
  showToastCustom(
      message: message,
      backgroundColor: Color(0xffFC2435),
      textColor: Colors.white,
  );
}

Color getColorFromName(String name) {
  String raw = name.replaceAll(' ', '');
  List<int> listNumber = raw.codeUnits;
  // List<String> listNumber = rawName.split("");
  int sum = 0;
  listNumber.forEach((element) {
    sum += element;
  });

  switch (sum % 7) {
    case 0:
      return Color(0xffEE9C53);
    case 1:
      return Color(0xff31AE4A);
    case 2:
      return Color(0xffF25A55);
    case 3:
      return Color(0xff23D4AD);
    case 4:
      return Color(0xffB451DF);
    case 5:
      return Color(0xffFFD662);
    default:
      return Color(0xff23A1D1);
  }//abc/def/ghi/jkl/mno/pqr/stu/vwx/yz
}

showAlertTokenExpired() {
  // set up the buttons
  Widget cancelButton = TextButton(
    child: Text("Đã hiểu"),
    onPressed: () {
      RemoveTokenAndCached(NavigationService.navigatorKey.currentContext!).remove();
      // _removeToken();
      // Navigator.pushAndRemoveUntil(
      //     context,
      //     MaterialPageRoute(builder: (context) => LoginView()),
      //     (route) => false);
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text('Hết phiên'),
    content: Text('Phiên đăng nhập của bạn hết hạn! Bạn hãy thực hiện đăng nhập lại'),
    actions: [
      cancelButton,
    ],
  );

  // show the dialog
  showDialog(
    context: NavigationService.navigatorKey.currentContext!,
    builder: (BuildContext context) {
      return alert;
    },
  );
}