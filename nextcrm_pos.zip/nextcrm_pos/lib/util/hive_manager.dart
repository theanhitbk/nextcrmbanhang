import 'package:hive/hive.dart';

class HiveManager {
  static Box? box;

  static Box? getInstance() {
    if (box == null) {
      box = Hive.box("hive_box");
    }
    return box;
  }
}