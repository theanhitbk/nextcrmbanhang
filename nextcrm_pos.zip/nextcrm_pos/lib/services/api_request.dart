import 'dart:convert';
import 'dart:math';

import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/model/BaseModel.dart';
import 'package:vidifi/model/Header.dart';
import 'package:vidifi/util/util.dart';

import 'api_const.dart';

class BaseRequestAPI {
  static Dio _dio = Dio();
  static final _singleton = BaseRequestAPI._internal();

  factory BaseRequestAPI() {
    _dio = Dio();
    _dio.options.connectTimeout = 60000;
    _dio.options.baseUrl = getDomainAppConfig();
    _dio.interceptors.add(
        DioCacheManager(CacheConfig(defaultRequestMethod: "GET")).interceptor);
    bool _showLogDio = true; // Khi nào cần thì bật lên

    if (kDebugMode && _showLogDio)
      _dio.interceptors.add(PrettyDioLogger(
          requestHeader: true,
          requestBody: true,
          responseBody: true,
          responseHeader: true,
          error: true,
          compact: true,
          maxWidth: 90));
    return _singleton;
  }
  BaseRequestAPI._internal();

  /// `useCache` not support method POST,
  /// Default = false
  /// forceRefreshCache default = true, get before data from network, if error use cache.
  Future<Map<String, dynamic>> sendRequest(
      String path, RequestMethod requestMethod,
      {dynamic jsonMap,
      dynamic queryParams,
      bool useCache = false,
      int cacheMaxDay = 3,
      int maxStale = 7,
      bool forceRefreshCache = true}) async {
    final prefs = await SharedPreferences.getInstance();
    String token = prefs.getString('token') ?? '';
    Header headers = new Header(authorization: 'Bearer $token');
    var response;
    switch (requestMethod) {
      case RequestMethod.POST:
        response = await _dio.post(
          path,
          data: jsonMap,
          queryParameters: queryParams,
          options: Options(
              headers: headers.toJson(),
              followRedirects: false,
              validateStatus: (status) {
                return status! <= 500;
              }),
        );
        break;
      case RequestMethod.GET:
        response = await _dio
            .get(
              path,
              options: useCache
                  ? buildCacheOptions(Duration(days: cacheMaxDay),
                      forceRefresh: forceRefreshCache,
                      options: Options(headers: headers.toJson()),
                      maxStale: Duration(days: maxStale))
                  : Options(headers: headers.toJson()),
              queryParameters: queryParams,
            )
            .catchError((e) {});
        break;
      case RequestMethod.DELETE:
        response = await _dio.delete(
          path,
          options: useCache
              ? buildCacheOptions(Duration(days: cacheMaxDay),
                  forceRefresh: forceRefreshCache,
                  options: Options(headers: headers.toJson()),
                  maxStale: Duration(days: maxStale))
              : Options(headers: headers.toJson()),
          queryParameters: queryParams,
        );
        break;
      case RequestMethod.PUT:
        response = await _dio.put(
          path,
          options: useCache
              ? buildCacheOptions(Duration(days: cacheMaxDay),
                  forceRefresh: forceRefreshCache,
                  options: Options(headers: headers.toJson()),
                  maxStale: Duration(days: maxStale))
              : Options(headers: headers.toJson()),
          queryParameters: queryParams,
        );
        break;
    }
    switch (response.statusCode) {
      case 201:
        return response.data;
      case 200:
        return response.data;
      default:
        final message = MessageResponse.fromJson(json.decode(response.data));
        Fluttertoast.showToast(
            msg: message.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        throw Exception(message.statusCode);
    }
  }

  void lockRequest() {
    _dio.lock();
  }

  void unlockRequest() {
    _dio.unlock();
  }

  // Future<Map<String, dynamic>> _getBaseHeader() async {
  //   final String token = header.authorization;
  //   // log(token);
  //   final map = header.toJson();
  //   map['Authorization'] = token;
  //   return map;
  // }

  static String getDomainAppConfig() {
    return 'https://api-nextcrm.nextcrm.vn';
    // return 'http://vietkara.vn/api/check-info';
  }
}
