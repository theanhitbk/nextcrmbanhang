import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:vidifi/model/BaseModel.dart';
import 'package:vidifi/model/Category.dart';
import 'package:vidifi/model/Channel.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Order.dart';
import 'package:vidifi/model/Position.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/Product.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/model/Header.dart';
import 'package:vidifi/model/Notification.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/model/ProductRequest.dart';
import 'package:vidifi/model/Property.dart';
import 'package:vidifi/model/Province.dart';
import 'package:vidifi/model/PurchaseRequest.dart';
import 'package:vidifi/model/Refund.dart';
import 'package:vidifi/model/SellRequest.dart';
import 'package:vidifi/model/Transaction.dart';
import 'package:vidifi/model/User.dart';
import 'package:vidifi/model/LoginResponse.dart';
import 'package:vidifi/model/brand.dart';
import 'package:vidifi/services/api_const.dart';
import 'package:vidifi/model/Meta.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/profile/default_config_response.dart';

import 'api_request.dart';

class APIService {
  static Header headers = Header();
  Future<LoginResponse> login(LoginRequestModel loginRequestModel) async {
    final response = await http.post(Uri.parse('$baseUrl$loginRoute'),
        body: loginRequestModel.toJson());
    print('====='+response.body);
    if (response.statusCode == 200){
      print('===== FAILED0');
      LoginResponse _reponse = LoginResponse.fromJson(json.decode(response.body));
      return _reponse;
    }
    else if (response.statusCode == 404) {
      print('===== FAILED1');
      throw Exception('Login fail');}
    else {
      print('===== FAILED2');
      throw Exception('Sai thông tin đăng nhập');
    }
  }

  Future<User> getProfile() async {
    final prefs = await SharedPreferences.getInstance();
    String token = prefs.getString('token') ?? '';
    headers.authorization = 'Bearer $token';
    print('Token: ${headers.authorization}');
    final response = await http.get(Uri.parse('$baseUrl$profile'),
        headers: headers.toJson());
    if (response.statusCode == 200)
      return User.fromJson(json.decode(response.body));
    else if (response.statusCode == 404)
      throw Exception('Login fail');
    else
      throw Exception('Fail to load data');
  }

  Future<DefaultConfigResponse> fetchDefaultConfig() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' +
            '/api/setting/pos-setting'),
        RequestMethod.GET,
        null,
        null);
    return DefaultConfigResponse.fromJson(json.decode(response));
  }

  Future<NoticeResponse> fetchNotice(int page) async {
    final prefs = await SharedPreferences.getInstance();
    String token = prefs.getString('token') ?? '';
    Header headers = new Header(authorization: 'Bearer $token');
    print('Token: ${headers.authorization}');
    final response = await http.get(
        Uri.parse('$baseUrl' + 'notifications?page=$page&limit=10'),
        headers: headers.toJson());
    if (response.statusCode == 200)
      return NoticeResponse.fromJson(json.decode(response.body));
    else if (response.statusCode == 404)
      throw Exception('Not found');
    else
      throw Exception('Cannot get notifications');
  }

  Future<bool> addDeviceFCM(String tokenFcm) async {
    final prefs = await SharedPreferences.getInstance();
    String token = prefs.getString('token') ?? '';
    Header headers = new Header(authorization: 'Bearer $token');
    var jsonHeader = headers.toJson();
    jsonHeader['Platform'] = Platform.isAndroid ? 'android' : 'ios';
    print('Token: ${headers.authorization}');
    final response = await http.post(Uri.parse('$baseUrl$addDevice'),
        body: <String, String>{'token': tokenFcm}, headers: jsonHeader);
    if (response.statusCode == 204)
      return true;
    else if (response.statusCode == 404)
      throw Exception('Login fail');
    else
      throw Exception('Fail to load data');
  }

  Future<ProductResponse> fetchProducts(int page, {String? filterString, String? branchID}) async {
    // final response = await BaseRequestAPI().sendRequest(
    //     '$baseUrl' + '/api/mobile/products?pageLimit=10&page=$page',
    //     RequestMethod.GET);
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/mobile/products?pageLimit=15&page=$page${filterString ?? ''}&search[branch_id]=${branchID ?? ''}'),
        RequestMethod.GET,
        null,
        null);
    return ProductResponse.fromJson(json.decode(response));
  }

  Future<ProductDetailResponse> fetchProductDetail(int id, int branch_id) async {
    // final response = await BaseRequestAPI().sendRequest(
    //     '$baseUrl' + '/api/mobile/products?pageLimit=10&page=$page',
    //     RequestMethod.GET);
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/mobile/get-product-row/$id?branch_id=$branch_id'),
        RequestMethod.GET,
        null,
        null);
    return ProductDetailResponse.fromJson(json.decode(response));
  }

  Future<CustomerResponse> fetchCustomers(int page) async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' +
            '/api/customer/search?pageLimit=15&page=$page&type=customer&strsearch='),
        RequestMethod.GET,
        null,
        null);
    return CustomerResponse.fromJson(json.decode(response));
  }

  Future<CustomerResponse> addNewCustomer(
      CustomerRequest customerRequest) async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/customer/customer'),
        RequestMethod.POST,
        json.encode(customerRequest),
        null);
    final jsonResponse = json.decode(response);
    return CustomerResponse.fromJson(jsonResponse['data']);
  }

  Future<PropertyResponse> fetchProperties() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/mobile/variation-templates'),
        RequestMethod.GET,
        null,
        null);
    return PropertyResponse.fromJson(json.decode(response));
  }

  Future<PriceResponse> fetchPrice() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/mobile/price-books?branch_id'),
        RequestMethod.GET,
        null,
        null);
    return PriceResponse.fromJson(json.decode(response));
  }

  Future<BrandResponse> fetchBrands() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/cate/brand-list'),
        RequestMethod.GET,
        null,
        null);
    return BrandResponse.fromJson(json.decode(response));
  }

  Future<PositionResponse> fetchPositions() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/cate/rack-forDropdown'),
        RequestMethod.GET,
        null,
        null);
    return PositionResponse.fromJson(json.decode(response));
  }

  Future<Position> addNewPosition(PositionRequest positionRequest) async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/cate/rack'),
        RequestMethod.POST,
        positionRequest.toJson(),
        null);
    final jsonResponse = json.decode(response);
    return Position.fromJson(jsonResponse['data']);
  }

  Future<TransactionRequest?> createPurchase(PurchaseRequest purchaseRequest) async {
    final response = await BaseRequestAPI().sendRequest(
        '$baseUrl' + '/api/purchase/purchase', RequestMethod.POST,
        jsonMap: json.encode(purchaseRequest));
    final jsonResponse = response;
    print('RESPONSE: ${response.toString()}');
    // return Transaction.fromJson(jsonResponse);
    return TransactionRequest.fromJson(jsonResponse);
  }

  Future<TransactionRequest?> createSell(SellRequest sellRequest) async {
    final response = await BaseRequestAPI().sendRequest(
        '$baseUrl' + '/api/sell/sell', RequestMethod.POST,
        jsonMap: json.encode(sellRequest));
    final jsonResponse = response["data"];
    return TransactionRequest.fromJson(jsonResponse);
  }

  Future<Meta> addNewProduct(ProductRequest productRequest) async {
    final response = await BaseRequestAPI().sendRequest(
        '$baseUrl' + '/api/product/product', RequestMethod.POST,
        jsonMap: json.encode(productRequest));
    final meta = Meta.fromJson(response["meta"]);
    return meta;
    // Fluttertoast.showToast(
    //     msg: meta.message ?? '',
    //     toastLength: Toast.LENGTH_SHORT,
    //     gravity: ToastGravity.CENTER,
    //     timeInSecForIosWeb: 2,
    //     backgroundColor: Colors.green,
    //     textColor: Colors.white,
    //     fontSize: 16.0);
  }

  Future<OrderResponse> fetchOrders(int page) async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' +
            '/api/sell/purchase?pageLimit=15&page=$page&invoice_code=&customer_name=&description=&product_code=&product_name=&from_date=&to_date='),
        RequestMethod.GET,
        null,
        null);
    return OrderResponse.fromJson(json.decode(response));
  }

  Future<RefundResponse> fetchRefunds(int page) async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' +
            '/api/sell-return/sell-order?pageLimit=10&page=$page&invoice_code=&customer_name=&description=&product_code=&product_name=&from_date=&to_date='),
        RequestMethod.GET,
        null,
        null);
    return RefundResponse.fromJson(json.decode(response));
  }

  Future<CustomerGroupResponse> fetchCustomerGroup() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/cate/customer-list'),
        RequestMethod.GET,
        null,
        null);
    return CustomerGroupResponse.fromJson(json.decode(response));
  }

  Future<CategoryResponse> fetchCategory() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/mobile/product-cate'),
        RequestMethod.GET,
        null,
        null);
    return CategoryResponse.fromJson(json.decode(response));
  }

  Future<ProvinceResponse> fetchProvince() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' + '/api/common/provinces?search[parent_id]=0'),
        RequestMethod.GET,
        null,
        null);
    return ProvinceResponse.fromJson(json.decode(response));
  }

  Future<ChannelResponse> fetchSaleChannel() async {
    final response = await this.sendRequest(
        Uri.parse('$baseUrl' +
            '/api/cate/cat-and-sub?&search[category_type]=pos_product_sell_type_category'),
        RequestMethod.GET,
        null,
        null);
    return ChannelResponse.fromJson(json.decode(response));
  }

  Future<dynamic> sendRequest(Uri path, RequestMethod requestMethod,
      dynamic param, dynamic queryParams) async {
    final prefs = await SharedPreferences.getInstance();
    String token = prefs.getString('token') ?? '';
    Header headers = new Header(authorization: 'Bearer $token');
    print('Url: $path');
    print('Token: ${headers.authorization}');
    print('Params: $param');
    var response;
    switch (requestMethod) {
      case RequestMethod.POST:
        response =
            await http.post(path, headers: headers.toJson(), body: param);
        break;
      case RequestMethod.GET:
        response = await http.get(path, headers: headers.toJson());
        break;
      case RequestMethod.DELETE:
        response = await http.delete(path, headers: headers.toJson());
        break;
      case RequestMethod.PUT:
        response = await http.put(path, headers: headers.toJson());
        break;
    }
    print('Response: ${response.body}');
    switch (response.statusCode) {
      case 201:
        return response.body;
      case 200:
        return response.body;
      case 401:
        showAlertTokenExpired();
        throw Exception("message.statusCode");
      default:
        final message = MessageResponse.fromJson(json.decode(response.body));
        Fluttertoast.showToast(
            msg: message.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        throw Exception(message.statusCode);
    }
  }
}
