final baseUrl = 'https://api-nextcrm.nextcrm.vn';
// final baseUrl = 'http://192.168.0.102:4000/v2/';
// final baseUrl = 'http://192.168.1.60:4000/v2/';
final docUrl = 'http://mail.vidifi.vn';
final loginRoute = '/api/mobile/login';
final contact = 'users/contacts';
final profile = 'users/profile';
final articles = 'articles?GroupId=28&limit=10&page=1';
final documentary = 'incoming-docs?limit=10&page=1';
enum RequestMethod { POST, GET, DELETE, PUT }
//Notification
final addDevice = 'devices/token';
final notifications = 'notifications';
final noticeDetail = 'notifications';
final productsRoute = '/api/mobile/products?pageLimit=10&page=0&search[branch_id]=1&search[term]&search[category_id]&variations[]=66';
String cookieWebview = 'ASPXAUTH=5BE8DA85AAB5FCBC81B2222A86F1CEEACFBCDFCB6D987C3BBCB23EDDD5489836836292C6BB3D4AFDCAE75979CE4BF0FAB3701727AB850ECB24495DA2B43ECA2FB59CCFFFA7CC41A03E23EEAE97D0ECDF6C5B2E0D603E6188B5CAFC31815C51DD; expires=Sat, 25-Sep-2021 04:45:01 GMT; path=/; HttpOnly';