import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/LoginResponse.dart';
import 'package:vidifi/model/User.dart';
import 'package:vidifi/model/branch.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/main.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:vidifi/util/dialog_utils.dart';
import 'package:vidifi/util/hide_keyboard.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';
import 'package:url_launcher/url_launcher.dart' as UrlLauncher;

import 'common/default_button.dart';

class LoginView extends StatefulWidget {
  _LoginViewState createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final txtUserName = TextEditingController();
  final txtPassword = TextEditingController();
  final tenantCode = TextEditingController(text: 'hosco');
  final hintText = TextEditingController(text: 'hosco.nextcrm.vn');
  late LoginRequestModel requestModel;
  bool remember = false;
  late ProfileCubit profileCubit;
  FocusNode focusNode = FocusNode();
  late LoadingDialog loadingDialog;
  @override
  void initState() {
    super.initState();
    profileCubit = context.read<ProfileCubit>();
    requestModel = new LoginRequestModel();
    loadingDialog = LoadingDialog(context);
  }

  @override
  void dispose() {
    txtPassword.dispose();
    txtUserName.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        hideKeyboard(context);
      },
      child: Scaffold(
        backgroundColor: Colors.green,
        resizeToAvoidBottomInset: false,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 200,
              color: Colors.white,
              child: Image(
                image: AssetImage("assets/icons/logo.png"),
                color: Colors.green,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 0, left: 25, right: 25, top: 16),
              child: Stack(
                children: [
                  TextField(
                    style: TextStyle(color: Colors.white60),
                    controller: hintText,
                    maxLength: 20,
                    decoration: InputDecoration(
                      counterText: '',
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      prefixIcon: new Icon(Icons.shopping_bag, color: Colors.white60),
                      border: InputBorder.none,
                      hintText: 'Mã đăng nhập',
                      hintStyle: TextStyle(color: Colors.white),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white60),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white60),
                      ),
                    ),
                  ),
                  TextField(
                    onChanged: (txtUser) {
                      requestModel.tenantcode = txtUser;
                      if (stringIsEmptyOrNull(tenantCode.text)) {
                        hintText.text = 'Mã đăng nhập.nextcrm.vn';
                      } else {
                        hintText.text = tenantCode.text + '.nextcrm.vn';
                      }
                    },
                    // onTap: () => focusNode.requestFocus(),
                    textInputAction: TextInputAction.next,
                    controller: tenantCode,
                    maxLength: 20,
                    obscureText: false,
                    autofocus: stringIsEmptyOrNull(tenantCode.text),
                    // focusNode: focusNode,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      // suffixIcon: tenantCode.text != '' ? IconButton(
                      //     icon: Icon(Icons.cancel, color: Colors.grey),
                      //     onPressed: () {
                      //       setState(() {
                      //         tenantCode.clear();
                      //       });
                      //     }) : null,
                      counterText: '',
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      prefixIcon: new Icon(Icons.shopping_bag, color: Colors.white60),
                      border: InputBorder.none,
                      hintText: 'Mã đăng nhập',
                      hintStyle: TextStyle(color: Colors.white),
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white60),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white60),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 0, left: 25, right: 25, top: 16),
              child: TextField(
                onChanged: (txtUser) => requestModel.username = txtUser,
                textInputAction: TextInputAction.next,
                controller: txtUserName,
                obscureText: false,
                focusNode: focusNode,
                onTap: () => focusNode.requestFocus(),
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  prefixIcon: new Icon(Icons.person, color: Colors.white60),
                  // suffixIcon: (focusNode.hasFocus && txtUserName.text != '') ? IconButton(
                  //     icon: Icon(Icons.cancel, color: Colors.grey),
                  //     onPressed: () {
                  //       setState(() {
                  //         txtUserName.clear();
                  //       });
                  //     }) : null,
                  border: InputBorder.none,
                  hintText: 'Tên đăng nhập',
                  hintStyle: TextStyle(color: Colors.white),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white60),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white60),
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 0, left: 25, right: 25, top: 16),
              child: TextField(
                onChanged: (txtUser) => requestModel.password = txtUser,
                controller: txtPassword,
                textInputAction: TextInputAction.done,
                // focusNode: focusNode,
                // onTap: () => focusNode.requestFocus(),
                obscureText: true,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  prefixIcon: new Icon(Icons.lock_rounded, color: Colors.white60),
                  border: InputBorder.none,
                  hintText: 'Mật khẩu',
                  hintStyle: TextStyle(color: Colors.white),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white60),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white60),
                  ),
                ),
              ),
            ),
            // Row(
            //   children: [
            //     Checkbox(
            //       value: remember,
            //       activeColor: primaryColor,
            //       onChanged: (value) {
            //         setState(() {
            //           remember = value ?? false;
            //         });
            //       },
            //     ),
            //     Text("Remember me"),
            //     Spacer(),
            //     TextButton(
            //       onPressed: () => {},
            //       child: Text(
            //         "Forgot Password",
            //         style: TextStyle(decoration: TextDecoration.underline),
            //       ),
            //     )
            //   ],
            // ),
            Spacer(),
            Padding(
              padding: const EdgeInsets.only(left: 45, right: 45, top: 0, bottom: 50),
              child: DefaultButton(
                  press: () {
                    if (requestModel.password.isNotEmpty && requestModel.username.isNotEmpty) {

                      APIService apiService = new APIService();
                      apiService.login(requestModel).then((value) {
                        if (value.meta?.statusCode == 0) {
                          this._saveTokenLogin(value.data?.token ?? '');
                          print('Token: ${value.data?.token}');
                          if (value.data?.user != null) {
                            profileCubit.saveProfileInfo(value.data!.user!);
                            profileCubit.updateSelectedBranch(
                                value.data!.user!.branches?.first ?? new Branch());
                            // userProfile = value.data!.user!;
                            // this._saveUserProfile(userProfile);
                          }
                          Navigator.pushAndRemoveUntil(context,
                              MaterialPageRoute(builder: (context) => Home()), (route) => false);
                        } else {
                          showToastFailed(value.meta?.message ?? 'Đã có lỗi xảy ra');
                        }
                      }).catchError((e) {
                        Fluttertoast.showToast(
                            msg: e.toString(),
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.CENTER,
                            timeInSecForIosWeb: 1,
                            backgroundColor: Colors.red,
                            textColor: Colors.white,
                            fontSize: 16.0);
                      });
                    } else {
                      showAlertDialog(context);
                    }
                  },
                  text: 'Đăng nhập'),
            ),

            Text(
              'Tổng đài hỗ trợ',
              style: TextStyle(color: Colors.white60),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () async {
                  final Uri launchUri = Uri(
                    scheme: 'tel',
                    path: '1900638056',
                  );
                  await UrlLauncher.canLaunch(launchUri.toString()).then((value) {
                    if (value) UrlLauncher.launch(launchUri.toString());
                  });
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.phone_in_talk_rounded, color: Colors.white),
                    SizedBox(
                      width: 5,
                    ),
                    Text(
                      '1900638056',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
          ],
        ),
      ),
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("Đã hiểu"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text('Thiếu thông tin'),
      content: Text('Bạn cần nhập đúng thông tin đăng nhập'),
      actions: [
        cancelButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void _saveTokenLogin(String token) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      prefs.setString('token', token);
    });
  }

// void _saveUserProfile(User user) async {
//   final prefs = await SharedPreferences.getInstance();
//   setState(() {
//     prefs.setString('UserProfile', jsonEncode(user));
//   });
// }
}
