import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:vidifi/model/ProductRequest.dart';
import 'package:vidifi/services/api_const.dart';
import 'package:vidifi/services/api_request.dart';
import 'package:vidifi/view/product/model/add_new_product_model.dart';

class AddProductRepo {

  Future<AddNewProductModel>addNewProduct(ProductRequest request) async {
    String url = '/api/product/product';
    final response = await BaseRequestAPI().sendRequest(baseUrl+url, RequestMethod.POST,
    jsonMap: json.encode(request));
    // Meta result = Meta.fromJson(re)
    return await compute(addNewProductModelFromJson, response);
  }
}