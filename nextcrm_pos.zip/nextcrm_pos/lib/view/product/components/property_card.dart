import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Property.dart';

class PropertyCard extends StatefulWidget {
  final Property property;

  PropertyCard(this.property);

  @override
  createState() => _PropertyCard(this.property);
}

class _PropertyCard extends State<PropertyCard> {
  // const PropertyCard({
  //   Key? key,
  //   required this.property,
  // }) : super(key: key);
  Property _property;

  _PropertyCard(this._property);

  // bool remember = false;
  _checkIsExpanded() {
    var isSelected = _property.values.where((element) => element.isSelected);
    _property.isExpand = isSelected.isNotEmpty;
    if (_property.isSelected) _property.isExpand = false;
  }

  @override
  void initState() {
    _checkIsExpanded();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.yellow,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextButton(
            child: Row(
              children: <Widget>[
                Checkbox(
                  value: _property.isSelected,
                  activeColor: Colors.green,
                  onChanged: (value) {
                    setState(() {
                      _property.isSelected = value ?? false;
                        _property.values.forEach((elememt) {
                          elememt.isSelected = _property.isSelected;
                        });
                    });
                  },
                ),
                Text(
                  _property.text,
                  style: TextStyle(color: primaryColor),
                ),
              ],
            ),
            onPressed: () {
              setState(() {
                _property.isExpand = !_property.isExpand;
              });
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
              shape: MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(6)),
              )),
            ),
          ),
          _property.isExpand && _property.values.length > 0 ? ListView.separated(
            itemBuilder: (BuildContext bCtx, index) {
              return Row(
                children: <Widget>[
                  SizedBox(
                    width: 16,
                  ),
                  Checkbox(
                    value: _property.values[index].isSelected,
                    activeColor: Colors.green,
                    onChanged: (value) {
                      setState(() {
                        _property.values[index].isSelected = value ?? false;
                        if (!_property.values[index].isSelected) {
                          _property.isSelected = false;
                        } else {
                          bool propertySelected = false;
                          for (var item in _property.values) {
                            propertySelected = item.isSelected;
                            print('SELECTED STATUS: $propertySelected');
                            if (!propertySelected) {
                              return;
                            }
                          }
                          if (propertySelected ) {
                            _property.isSelected = propertySelected;}
                        }

                      });
                    },
                  ),
                  Text(
                    _property.values[index].name,
                    style: TextStyle(color: primaryColor),
                  ),
                ],
              );
            },
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: _property.values.length,
            separatorBuilder: (BuildContext context, int index) {
              return Divider(
                height: 1,
              );
            },
          ) : Container()
        ],
      ),
      margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }
}
