import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:provider/src/provider.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Product.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/slider_class.dart';
import 'package:vidifi/view/home/invoice.dart';
import 'package:vidifi/view/home/parcel_managment_screen.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

class ProductCard extends StatelessWidget {
  ProductCard({
    Key? key,
    required this.product,
  }) : super(key: key);
  final Product product;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        _getProductDetail(context);
      },
      child: Container(
        color: Colors.white,
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Row(
          children: <Widget>[
            Container(
              width: 50.0,
              height: 50.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(5)),
                // border: Border.all(color: Colors.grey),
                color: getColorFromName(product.name),
              ),
              child: product.productImage.isEmpty
                  ? Center(
                      child: Text(
                        stringIsEmptyOrNull(product.name)
                            ? ''
                            : product.name.characters.first.toUpperCase(),
                        style: TextStyle(fontSize: 32, color: Colors.white),
                      ),
                    )
                  : GestureDetector(
                      onTap: () {
                        showImagePopupDetail(context);
                      },
                      child: Image.network(
                        product.productImage.replaceAll(" ", ""),
                        fit: BoxFit.cover,
                        loadingBuilder:
                            (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            width: 24,
                            height: 24,
                            child: Center(
                              child: CircularProgressIndicator(
                                backgroundColor: primaryColor,
                                value: loadingProgress.expectedTotalBytes != null &&
                                        loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                        loadingProgress.expectedTotalBytes!
                                    : null,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
            ),
            SizedBox(
              width: 4,
            ),
            Flexible(
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      product.name,
                      maxLines: 2,
                      style: TextStyle(
                          color: primaryColor, fontSize: 14, fontWeight: FontWeight.normal),
                      textAlign: TextAlign.start,
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Text(
                      product.productCode ?? '',
                      maxLines: 1,
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ],
                ),
              ),
              SizedBox(width: 16,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    convertToCurrency(double.parse(product.sellingPrice ?? '0.0').toInt()),
                    maxLines: 1,
                    style:
                        TextStyle(color: Colors.green, fontSize: 14, fontWeight: FontWeight.normal),
                  ),
                  SizedBox(
                    height: 3,
                  ),
                  Text(
                    double.parse(product.qtyAvailable ?? '0.0').toInt().toString(),
                    maxLines: 5,
                    style: TextStyle(
                      color: primaryColor,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(
                    height: 3,
                  ),
                  Text(
                    'KH đặt: ${product.totalOrdered ?? 0}',
                    maxLines: 1,
                    style:
                    TextStyle(color: primaryColor, fontSize: 12, fontWeight: FontWeight.normal),
                  ),
                ],
              ),
            ]))
          ],
        ),
        // margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
      ),
    );
  }

  void _getProductDetail(BuildContext context) async {
    final response = await APIService().fetchProductDetail(product.id ?? 0, context.read<ProfileCubit>().currentBranch?.id ?? 1);
    if (response != null) {
      if ((response.data?.product?.lotNumbers?.length ?? 0) > 0) {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ParcelManagementScreen(response.data!), fullscreenDialog: true),
        );
      } else {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => InvoiceScreen(response.data!)));
      }
    }
  }

  showImagePopupDetail(BuildContext ctx) {
    Navigator.push(
        ctx,
        MaterialPageRoute(
            builder: (ctx) => CarouselWithIndicatorDemo(generateImgSlider(), product), fullscreenDialog: true));

    // showDialog(
    //     barrierDismissible: false,
    //     context: ctx,
    //     builder: (BuildContext context) {
    //       return CarouselWithIndicatorDemo(generateImgSlider(), product);
    //     });
  }

  List<Widget> generateImgSlider() {
    return [product.productImage]
        .map((item) => Container(
              child: Container(
                margin: EdgeInsets.all(5.0),
                child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    child: Center(child: Image.network(item, fit: BoxFit.fitHeight, width: 1200))),
              ),
            ))
        .toList();
  }
}
