
import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Position.dart';

class PositionCard extends StatelessWidget {
  const PositionCard({
    Key? key,
    required this.position,
  }) : super(key: key);
  final Position position;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextButton(
        child: Row(
          children: <Widget>[
            Flexible(
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          position.name,
                          maxLines: 2,
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: 14,
                              fontWeight: FontWeight.normal),
                          textAlign: TextAlign.start,
                        ),
                      ],
                    ),
                  ),
                ]))
          ],
        ),
        onPressed: () {
          // Open detail
          // Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //           builder: (context) => WebViewExample(news.ArticleUrl)));
        },
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          shape:
              MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(6)),
          )),
        ),
      ),
      margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }
}
