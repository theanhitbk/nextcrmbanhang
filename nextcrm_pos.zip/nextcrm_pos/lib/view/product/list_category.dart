import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Category.dart';
import 'package:vidifi/services/api_service.dart';

class ListCategory extends StatefulWidget {
  final void Function(Category) onSelectedCategory;
  ListCategory(this.onSelectedCategory);
  @override
  _ListCategory createState() => _ListCategory(this.onSelectedCategory);
}

class _ListCategory extends State<ListCategory> {
  var _onSelectedCategory;
  _ListCategory(this._onSelectedCategory);
  ScrollController _sc = new ScrollController();
  List<Category> categories = [];
  @override
  void initState() {
    this._getListProperty();
    super.initState();
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chọn nhóm hàng',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                'Xong',
                style: TextStyle(color: Colors.white),
              ))
        ],
      ),
      backgroundColor: greyColor2,
      body: Padding(
        padding: EdgeInsets.all(4),
        child: Container(
          child: _buildListProperty(),
        ),
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  void _getListProperty() async {
    final response = await APIService().fetchCategory().catchError((e) {});
    setState(() {
      if (response.data != null) {
        categories.addAll(response.data!);
      }
    });
  }

  Widget _buildListProperty() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: categories.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        var category = categories[index];
        return Container(
          child: TextButton(
            child: Row(
              children: <Widget>[
                Flexible(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              category.name ?? '',
                              maxLines: 2,
                              style: TextStyle(
                                  color: primaryColor,
                                  fontSize: 14,
                                  fontWeight: FontWeight.normal),
                              textAlign: TextAlign.start,
                            ),
                          ],
                        ),
                      ),
                    ]))
              ],
            ),
            onPressed: () {
              _onSelectedCategory(category);
              Navigator.pop(context);
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
              shape: MaterialStateProperty.all<OutlinedBorder>(
                  RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(6)),
              )),
            ),
          ),
          margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
        );
      },
      controller: _sc,
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
