// To parse this JSON data, do
//
//     final addNewProductModel = addNewProductModelFromJson(jsonString);

import 'dart:convert';

import 'package:vidifi/model/Meta.dart';

AddNewProductModel addNewProductModelFromJson(dynamic str) => AddNewProductModel.fromJson(str);

String addNewProductModelToJson(AddNewProductModel data) => json.encode(data.toJson());

class AddNewProductModel {
  AddNewProductModel({
    this.meta,
    this.data,
  });

  Meta? meta;
  Data? data;

  AddNewProductModel copyWith({
    Meta? meta,
    Data? data,
  }) =>
      AddNewProductModel(
        meta: meta ?? this.meta,
        data: data ?? this.data,
      );

  factory AddNewProductModel.fromJson(Map<String, dynamic> json) => AddNewProductModel(
    meta: json["meta"] == null ? null : Meta.fromJson(json["meta"]),
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "meta": meta == null ? null : meta?.toJson(),
    "data": data == null ? null : data?.toJson(),
  };
}

class Data {
  Data({
    this.id,
    this.name,
    this.code,
    this.type,
    this.unitId,
    this.subUnitIds,
    this.brandId,
    this.categoryId,
    this.subCategoryId,
    this.tax,
    this.taxType,
    this.enableStock,
    this.alertQuantity,
    this.sku,
    this.barcodeType,
    this.expiryPeriod,
    this.expiryPeriodType,
    this.enableSrNo,
    this.weight,
    this.productCustomField1,
    this.productCustomField2,
    this.productCustomField3,
    this.productCustomField4,
    this.image,
    this.description,
    this.warrantyId,
    this.isInactive,
    this.notForSelling,
    this.variations,
    this.beginStock,
    this.stockMin,
    this.stockMax,
    this.costPrice,
    this.purchasePrice,
    this.sellPrice,
    this.isRewardPoint,
    this.rewardPoint,
    this.isBatchExpireControl,
    this.attributes,
  });

  int? id;
  String? name;
  String? code;
  String? type;
  int? unitId;
  dynamic subUnitIds;
  int? brandId;
  String? categoryId;
  dynamic subCategoryId;
  dynamic tax;
  dynamic taxType;
  bool? enableStock;
  dynamic alertQuantity;
  String? sku;
  dynamic barcodeType;
  dynamic expiryPeriod;
  dynamic expiryPeriodType;
  dynamic enableSrNo;
  int? weight;
  String? productCustomField1;
  dynamic productCustomField2;
  dynamic productCustomField3;
  dynamic productCustomField4;
  String? image;
  String? description;
  dynamic warrantyId;
  bool? isInactive;
  bool? notForSelling;
  List<Variation>? variations;
  int? beginStock;
  int? stockMin;
  int? stockMax;
  int? costPrice;
  int? purchasePrice;
  int? sellPrice;
  dynamic isRewardPoint;
  dynamic rewardPoint;
  dynamic isBatchExpireControl;
  List<Attribute>? attributes;

  Data copyWith({
    int? id,
    String? name,
    String? code,
    String? type,
    int? unitId,
    dynamic subUnitIds,
    int? brandId,
    String? categoryId,
    dynamic subCategoryId,
    dynamic tax,
    dynamic taxType,
    bool? enableStock,
    dynamic alertQuantity,
    String? sku,
    dynamic barcodeType,
    dynamic expiryPeriod,
    dynamic expiryPeriodType,
    dynamic enableSrNo,
    int? weight,
    String? productCustomField1,
    dynamic productCustomField2,
    dynamic productCustomField3,
    dynamic productCustomField4,
    String? image,
    String? description,
    dynamic warrantyId,
    bool? isInactive,
    bool? notForSelling,
    List<Variation>? variations,
    int? beginStock,
    int? stockMin,
    int? stockMax,
    int? costPrice,
    int? purchasePrice,
    int? sellPrice,
    dynamic isRewardPoint,
    dynamic rewardPoint,
    dynamic isBatchExpireControl,
    List<Attribute>? attributes,
  }) =>
      Data(
        id: id ?? this.id,
        name: name ?? this.name,
        code: code ?? this.code,
        type: type ?? this.type,
        unitId: unitId ?? this.unitId,
        subUnitIds: subUnitIds ?? this.subUnitIds,
        brandId: brandId ?? this.brandId,
        categoryId: categoryId ?? this.categoryId,
        subCategoryId: subCategoryId ?? this.subCategoryId,
        tax: tax ?? this.tax,
        taxType: taxType ?? this.taxType,
        enableStock: enableStock ?? this.enableStock,
        alertQuantity: alertQuantity ?? this.alertQuantity,
        sku: sku ?? this.sku,
        barcodeType: barcodeType ?? this.barcodeType,
        expiryPeriod: expiryPeriod ?? this.expiryPeriod,
        expiryPeriodType: expiryPeriodType ?? this.expiryPeriodType,
        enableSrNo: enableSrNo ?? this.enableSrNo,
        weight: weight ?? this.weight,
        productCustomField1: productCustomField1 ?? this.productCustomField1,
        productCustomField2: productCustomField2 ?? this.productCustomField2,
        productCustomField3: productCustomField3 ?? this.productCustomField3,
        productCustomField4: productCustomField4 ?? this.productCustomField4,
        image: image ?? this.image,
        description: description ?? this.description,
        warrantyId: warrantyId ?? this.warrantyId,
        isInactive: isInactive ?? this.isInactive,
        notForSelling: notForSelling ?? this.notForSelling,
        variations: variations ?? this.variations,
        beginStock: beginStock ?? this.beginStock,
        stockMin: stockMin ?? this.stockMin,
        stockMax: stockMax ?? this.stockMax,
        costPrice: costPrice ?? this.costPrice,
        purchasePrice: purchasePrice ?? this.purchasePrice,
        sellPrice: sellPrice ?? this.sellPrice,
        isRewardPoint: isRewardPoint ?? this.isRewardPoint,
        rewardPoint: rewardPoint ?? this.rewardPoint,
        isBatchExpireControl: isBatchExpireControl ?? this.isBatchExpireControl,
        attributes: attributes ?? this.attributes,
      );

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"] == null ? null : json["id"],
    name: json["name"] == null ? null : json["name"],
    code: json["code"] == null ? null : json["code"],
    type: json["type"] == null ? null : json["type"],
    unitId: json["unit_id"] == null ? null : json["unit_id"],
    subUnitIds: json["sub_unit_ids"],
    brandId: json["brand_id"] == null ? null : json["brand_id"],
    categoryId: json["category_id"] == null ? null : json["category_id"],
    subCategoryId: json["sub_category_id"],
    tax: json["tax"],
    taxType: json["tax_type"],
    enableStock: json["enable_stock"] == null ? null : json["enable_stock"],
    alertQuantity: json["alert_quantity"],
    sku: json["sku"] == null ? null : json["sku"],
    barcodeType: json["barcode_type"],
    expiryPeriod: json["expiry_period"],
    expiryPeriodType: json["expiry_period_type"],
    enableSrNo: json["enable_sr_no"],
    weight: json["weight"] == null ? null : json["weight"],
    productCustomField1: json["product_custom_field1"] == null ? null : json["product_custom_field1"],
    productCustomField2: json["product_custom_field2"],
    productCustomField3: json["product_custom_field3"],
    productCustomField4: json["product_custom_field4"],
    image: json["image"] == null ? null : json["image"],
    description: json["description"] == null ? null : json["description"],
    warrantyId: json["warranty_id"],
    isInactive: json["is_inactive"] == null ? null : json["is_inactive"],
    notForSelling: json["not_for_selling"] == null ? null : json["not_for_selling"],
    variations: json["variations"] == null ? null : List<Variation>.from(json["variations"].map((x) => Variation.fromJson(x))),
    beginStock: json["begin_stock"] == null ? null : json["begin_stock"],
    stockMin: json["stock_min"] == null ? null : json["stock_min"],
    stockMax: json["stock_max"] == null ? null : json["stock_max"],
    costPrice: json["cost_price"] == null ? null : json["cost_price"],
    purchasePrice: json["purchase_price"] == null ? null : json["purchase_price"],
    sellPrice: json["sell_price"] == null ? null : json["sell_price"],
    isRewardPoint: json["is_reward_point"],
    rewardPoint: json["reward_point"],
    isBatchExpireControl: json["is_batch_expire_control"],
    attributes: json["attributes"] == null ? null : List<Attribute>.from(json["attributes"].map((x) => Attribute.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
    "code": code == null ? null : code,
    "type": type == null ? null : type,
    "unit_id": unitId == null ? null : unitId,
    "sub_unit_ids": subUnitIds,
    "brand_id": brandId == null ? null : brandId,
    "category_id": categoryId == null ? null : categoryId,
    "sub_category_id": subCategoryId,
    "tax": tax,
    "tax_type": taxType,
    "enable_stock": enableStock == null ? null : enableStock,
    "alert_quantity": alertQuantity,
    "sku": sku == null ? null : sku,
    "barcode_type": barcodeType,
    "expiry_period": expiryPeriod,
    "expiry_period_type": expiryPeriodType,
    "enable_sr_no": enableSrNo,
    "weight": weight == null ? null : weight,
    "product_custom_field1": productCustomField1 == null ? null : productCustomField1,
    "product_custom_field2": productCustomField2,
    "product_custom_field3": productCustomField3,
    "product_custom_field4": productCustomField4,
    "image": image == null ? null : image,
    "description": description == null ? null : description,
    "warranty_id": warrantyId,
    "is_inactive": isInactive == null ? null : isInactive,
    "not_for_selling": notForSelling == null ? null : notForSelling,
    "variations": variations == null ? null : (List<Variation>.from(variations!.map((x) => x.toJson()))),
    "begin_stock": beginStock == null ? null : beginStock,
    "stock_min": stockMin == null ? null : stockMin,
    "stock_max": stockMax == null ? null : stockMax,
    "cost_price": costPrice == null ? null : costPrice,
    "purchase_price": purchasePrice == null ? null : purchasePrice,
    "sell_price": sellPrice == null ? null : sellPrice,
    "is_reward_point": isRewardPoint,
    "reward_point": rewardPoint,
    "is_batch_expire_control": isBatchExpireControl,
    "attributes": attributes == null ? null : List<Attribute>.from(attributes!.map((x) => x.toJson())),
  };
}

class Attribute {
  Attribute({
    this.slug,
    this.name,
    this.sortOrder,
    this.type,
    this.isRequired,
    this.attributeDefault,
    this.content,
    this.dataSource,
    this.dataSourceApi,
    this.dataSourceType,
  });

  String? slug;
  String? name;
  int? sortOrder;
  String? type;
  bool? isRequired;
  String? attributeDefault;
  dynamic content;
  List<dynamic>? dataSource;
  dynamic dataSourceApi;
  dynamic dataSourceType;

  Attribute copyWith({
    String? slug,
    String? name,
    int? sortOrder,
    String? type,
    bool? isRequired,
    String? attributeDefault,
    dynamic content,
    List<dynamic>? dataSource,
    dynamic dataSourceApi,
    dynamic dataSourceType,
  }) =>
      Attribute(
        slug: slug ?? this.slug,
        name: name ?? this.name,
        sortOrder: sortOrder ?? this.sortOrder,
        type: type ?? this.type,
        isRequired: isRequired ?? this.isRequired,
        attributeDefault: attributeDefault ?? this.attributeDefault,
        content: content ?? this.content,
        dataSource: dataSource ?? this.dataSource,
        dataSourceApi: dataSourceApi ?? this.dataSourceApi,
        dataSourceType: dataSourceType ?? this.dataSourceType,
      );

  factory Attribute.fromJson(Map<String, dynamic> json) => Attribute(
    slug: json["slug"] == null ? null : json["slug"],
    name: json["name"] == null ? null : json["name"],
    sortOrder: json["sort_order"] == null ? null : json["sort_order"],
    type: json["type"] == null ? null : json["type"],
    isRequired: json["is_required"] == null ? null : json["is_required"],
    attributeDefault: json["default"] == null ? null : json["default"],
    content: json["content"],
    dataSource: json["data_source"] == null ? null : List<dynamic>.from(json["data_source"].map((x) => x)),
    dataSourceApi: json["data_source_api"],
    dataSourceType: json["data_source_type"],
  );

  Map<String, dynamic> toJson() => {
    "slug": slug == null ? null : slug,
    "name": name == null ? null : name,
    "sort_order": sortOrder == null ? null : sortOrder,
    "type": type == null ? null : type,
    "is_required": isRequired == null ? null : isRequired,
    "default": attributeDefault == null ? null : attributeDefault,
    "content": content,
    "data_source": dataSource == null ? null : List<dynamic>.from(dataSource!.map((x) => x)),
    "data_source_api": dataSourceApi,
    "data_source_type": dataSourceType,
  };
}

class Variation {
  Variation({
    this.id,
    this.name,
    this.productId,
    this.subSku,
    this.productVariationId,
    this.variationValueId,
    this.defaultPurchasePrice,
    this.dppIncTax,
    this.profitPercent,
    this.defaultSellPrice,
    this.sellPriceIncTax,
    this.comboVariations,
    this.stock,
    this.rewardPoint,
  });

  int? id;
  String? name;
  int? productId;
  String? subSku;
  int? productVariationId;
  int? variationValueId;
  String? defaultPurchasePrice;
  String? dppIncTax;
  String? profitPercent;
  String? defaultSellPrice;
  String? sellPriceIncTax;
  dynamic comboVariations;
  String? stock;
  int? rewardPoint;

  Variation copyWith({
    int? id,
    String? name,
    int? productId,
    String? subSku,
    int? productVariationId,
    int? variationValueId,
    String? defaultPurchasePrice,
    String? dppIncTax,
    String? profitPercent,
    String? defaultSellPrice,
    String? sellPriceIncTax,
    dynamic comboVariations,
    String? stock,
    int? rewardPoint,
  }) =>
      Variation(
        id: id ?? this.id,
        name: name ?? this.name,
        productId: productId ?? this.productId,
        subSku: subSku ?? this.subSku,
        productVariationId: productVariationId ?? this.productVariationId,
        variationValueId: variationValueId ?? this.variationValueId,
        defaultPurchasePrice: defaultPurchasePrice ?? this.defaultPurchasePrice,
        dppIncTax: dppIncTax ?? this.dppIncTax,
        profitPercent: profitPercent ?? this.profitPercent,
        defaultSellPrice: defaultSellPrice ?? this.defaultSellPrice,
        sellPriceIncTax: sellPriceIncTax ?? this.sellPriceIncTax,
        comboVariations: comboVariations ?? this.comboVariations,
        stock: stock ?? this.stock,
        rewardPoint: rewardPoint ?? this.rewardPoint,
      );

  factory Variation.fromJson(Map<String, dynamic> json) => Variation(
    id: json["id"] == null ? null : json["id"],
    name: json["name"] == null ? null : json["name"],
    productId: json["product_id"] == null ? null : json["product_id"],
    subSku: json["sub_sku"] == null ? null : json["sub_sku"],
    productVariationId: json["product_variation_id"] == null ? null : json["product_variation_id"],
    variationValueId: json["variation_value_id"] == null ? null : json["variation_value_id"],
    defaultPurchasePrice: json["default_purchase_price"] == null ? null : json["default_purchase_price"],
    dppIncTax: json["dpp_inc_tax"] == null ? null : json["dpp_inc_tax"],
    profitPercent: json["profit_percent"] == null ? null : json["profit_percent"],
    defaultSellPrice: json["default_sell_price"] == null ? null : json["default_sell_price"],
    sellPriceIncTax: json["sell_price_inc_tax"] == null ? null : json["sell_price_inc_tax"],
    comboVariations: json["combo_variations"],
    stock: json["stock"] == null ? null : json["stock"],
    rewardPoint: json["reward_point"] == null ? null : json["reward_point"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
    "product_id": productId == null ? null : productId,
    "sub_sku": subSku == null ? null : subSku,
    "product_variation_id": productVariationId == null ? null : productVariationId,
    "variation_value_id": variationValueId == null ? null : variationValueId,
    "default_purchase_price": defaultPurchasePrice == null ? null : defaultPurchasePrice,
    "dpp_inc_tax": dppIncTax == null ? null : dppIncTax,
    "profit_percent": profitPercent == null ? null : profitPercent,
    "default_sell_price": defaultSellPrice == null ? null : defaultSellPrice,
    "sell_price_inc_tax": sellPriceIncTax == null ? null : sellPriceIncTax,
    "combo_variations": comboVariations,
    "stock": stock == null ? null : stock,
    "reward_point": rewardPoint == null ? null : rewardPoint,
  };
}

// class Meta {
//   Meta({
//     this.statusCode,
//     this.message,
//   });
//
//   int? statusCode;
//   String message;
//
//   Meta copyWith({
//     int statusCode,
//     String message,
//   }) =>
//       Meta(
//         statusCode: statusCode ?? this.statusCode,
//         message: message ?? this.message,
//       );
//
//   factory Meta.fromJson(Map<String, dynamic> json) => Meta(
//     statusCode: json["status_code"] == null ? null : json["status_code"],
//     message: json["message"] == null ? null : json["message"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "status_code": statusCode == null ? null : statusCode,
//     "message": message == null ? null : message,
//   };
// }
