// To parse this JSON data, do
//
//     final uploadImgReponse = uploadImgReponseFromJson(jsonString);

import 'dart:convert';

UploadImgResponse uploadImgResponseFromJson(dynamic str) => UploadImgResponse.fromJson(str);

String uploadImgResponseToJson(UploadImgResponse data) => json.encode(data.toJson());

class UploadImgResponse {
  UploadImgResponse({
    this.cdnImage,
    this.message,
    this.statusCode,
  });

  String? cdnImage;
  String? message;
  int? statusCode;

  UploadImgResponse copyWith({
    String? cdnImage,
    String? message,
    int? statusCode,
  }) =>
      UploadImgResponse(
        cdnImage: cdnImage ?? this.cdnImage,
        message: message ?? this.message,
        statusCode: statusCode ?? this.statusCode,
      );

  factory UploadImgResponse.fromJson(Map<String, dynamic> json) => UploadImgResponse(
    cdnImage: json["cdn_image"] == null ? null : json["cdn_image"],
    message: json["message"] == null ? null : json["message"],
    statusCode: json["status_code"] == null ? null : json["status_code"],
  );

  Map<String, dynamic> toJson() => {
    "cdn_image": cdnImage == null ? null : cdnImage,
    "message": message == null ? null : message,
    "status_code": statusCode == null ? null : statusCode,
  };
}
