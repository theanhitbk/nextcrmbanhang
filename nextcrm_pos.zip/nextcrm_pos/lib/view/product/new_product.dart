import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Category.dart';
import 'package:vidifi/model/Position.dart';
import 'package:vidifi/model/ProductRequest.dart';
import 'package:vidifi/model/brand.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/dialog_utils.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/brand/list_brand.dart';
import 'package:image_picker/image_picker.dart';
import 'package:vidifi/view/product/cubit/add_product_cubit.dart';
import 'package:vidifi/view/product/model/upload_img_model.dart';
import 'package:vidifi/view/product/unit_widget.dart';

import 'list_category.dart';
import 'list_position.dart';

class NewProduct extends StatefulWidget {
  @override
  _NewProduct createState() => _NewProduct();
}

class _NewProduct extends State<NewProduct> {
  String _scanBarcode = 'Unknown';
  File? _image = null;
  bool _switchManager = true;
  bool _switchSell = true;
  bool _switchGetPoint = true;
  final ImagePicker picker = ImagePicker();
  final txtCategory = TextEditingController();
  final txtTaxNumber = TextEditingController();
  final txtGroup = TextEditingController();
  final txtBrand = TextEditingController();
  final txtPosition = TextEditingController();
  final txtBarCode = TextEditingController();
  final txtPriceCost = TextEditingController();
  final txtPrice = TextEditingController();
  final txtDescription = TextEditingController();
  final txtStock = TextEditingController();
  late ProductRequest requestModel = ProductRequest();

  var unit_base = UnitBase(name: "", isDirectSell: true);
  List<SubUnit> subUnitArr = [];
  List<UploadImgResponse> photoArr = [];
  int maxPhotos = 5;

  // var sub_init = SubUnit(index: 0, name: 'thùng', fConvert: 10, price: 280000, isDirectSell: true);

  String b64Img = '';

  AddProductCubit cubit = AddProductCubit();
  late LoadingDialog loadingDialog;

  Future getImage() async {
    final pickerFile = await picker.getImage(source: ImageSource.gallery, imageQuality: 20);
    if (pickerFile != null) {
      cubit.updateStatusUploadImg(true);
      _image = File(pickerFile.path);
      var bytes = await pickerFile.readAsBytes();
      b64Img = base64.encode(bytes);
      print('BASE64 IMG: $b64Img');
      Future.delayed(Duration(milliseconds: 500), () {
        cubit.uploadImage(b64Img);
      });
    } else {
      print('No image selected.');
    }
  }

  @override
  void initState() {
    loadingDialog = LoadingDialog(context);
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> startBarcodeScanStream() async {
    FlutterBarcodeScanner.getBarcodeStreamReceiver('#ff6666', 'Cancel', true, ScanMode.BARCODE)!
        .listen((barcode) => print(barcode));
  }

  Future<void> scanQR() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes =
          await FlutterBarcodeScanner.scanBarcode('#ff6666', 'Cancel', true, ScanMode.QR);
      print('barcodeScanRes $barcodeScanRes');
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      if (barcodeScanRes != '-1') {
        txtBarCode.text = barcodeScanRes;
      }
    });
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> scanBarcodeNormal() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes =
          await FlutterBarcodeScanner.scanBarcode('#ff6666', 'Cancel', true, ScanMode.BARCODE);
      print('barcodeScanRes $barcodeScanRes');
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      if (barcodeScanRes != '-1') {
        txtTaxNumber.text = barcodeScanRes;
      }
    });
  }

  Future<bool> _onWillPop() async {
    return (await showDialog(
          context: context,
          builder: (context) => new AlertDialog(
            content:
                new Text('Thay đổi trên hàng hoá sẽ không được lưu lại. Bạn có chắc muốn thoát?'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: new Text('Bỏ qua'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: new Text('Đồng ý'),
              ),
            ],
          ),
        )) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => cubit,
      child: BlocConsumer<AddProductCubit, AddProductState>(
        listener: (context, state) {
          if (state is UploadImgSuccess) {
            print('UPLOAD IMG SUCCESS');
            photoArr.add(state.response);
            // loadingDialog.dismiss();
            // _saveProduct();
          }
          if (state is UploadImgFailed) {
            loadingDialog.dismiss();
            showToastFailed('Xảy ra lỗi khi upload ảnh');
          }
          if (state is AddProductSuccess) {
            loadingDialog.dismiss();
            showToastSuccess(state.response.meta?.message ?? 'Success');
            Future.delayed(Duration(milliseconds: 200), () {
              Navigator.of(context).pop(true);
            });
          }
          if (state is AddProductFailed) {
            loadingDialog.dismiss();
            showToastFailed(state.reasonFailed);
          }
        },
        builder: (context, state) {
          return WillPopScope(
            onWillPop: _onWillPop,
            child: Scaffold(
              appBar: AppBar(
                centerTitle: true,
                title: Text(
                  'Thêm hàng hoá',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                backgroundColor: Colors.green,
                actions: [
                  TextButton(
                      onPressed: () {
                        this._saveProduct();
                        // _uploadImageFirst();
                      },
                      child: Text(
                        'Lưu',
                        style: TextStyle(color: Colors.white),
                      )),
                  IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.more_horiz,
                        color: Colors.white,
                      ))
                ],
              ),
              backgroundColor: greyColor2,
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildPhotoSelection(),
                    _infoProduct(),
                    SizedBox(
                      height: 32,
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 16, right: 16),
                      color: Colors.white,
                      child: Column(
                        children: [
                          Row(
                            children: <Widget>[
                              Text('Quản lí theo lô, hạn sử dụng'),
                              Spacer(),
                              CupertinoSwitch(
                                value: _switchManager,
                                onChanged: (value) {
                                  setState(() {
                                    _switchManager = value;
                                    requestModel.enableStock = value;
                                  });
                                },
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            children: <Widget>[
                              Text('Bán trực tiếp'),
                              Spacer(),
                              CupertinoSwitch(
                                value: _switchSell,
                                onChanged: (value) {
                                  setState(() {
                                    _switchSell = value;
                                    requestModel.notForSelling = value;
                                  });
                                },
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            children: <Widget>[
                              Text('Tích điểm'),
                              Spacer(),
                              CupertinoSwitch(
                                value: _switchGetPoint,
                                onChanged: (value) {
                                  setState(() {
                                    _switchGetPoint = value;
                                    requestModel.isInactive = value;
                                  });
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 32,
                    ),
                    UnitWidget(
                      subUnitArray: subUnitArr,
                      unitBase: unit_base,
                      removeSubUnit: (ind) {
                        setState(() {
                          subUnitArr.removeAt(ind);
                        });
                      },
                    ),
                    SizedBox(
                      height: 32,
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 16, right: 16),
                      color: Colors.white,
                      child: TextField(
                        obscureText: false,
                        decoration: InputDecoration(labelText: 'Mô tả'),
                        style: TextStyle(fontSize: 14, height: 1),
                        onChanged: (value) => {requestModel.description = value},
                      ),
                    ),
                    SizedBox(
                      height: 32,
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 16, right: 16),
                      color: Colors.white,
                      child: TextField(
                        obscureText: false,
                        decoration: InputDecoration(labelText: 'Mẫu ghi chú(hoá đơn, đặt hàng)'),
                        style: TextStyle(fontSize: 14, height: 1),
                        onChanged: (value) => {requestModel.productCustomField1 = value},
                      ),
                    ),
                    SizedBox(
                      height: 32,
                    ),
                  ],
                ),
              ),
              resizeToAvoidBottomInset: true,
            ),
          );
        },
      ),
    );
  }

  void _uploadImageFirst() async {
    if (unit_base.name != '') {
      for (int i = 0; i < subUnitArr.length; i++) {
        subUnitArr[i].index = i;
      }
      // var unit = UnitRequest(unitBase: unit_base, subUnit: [sub_init]);
      var unit = UnitRequest(unitBase: unit_base, subUnit: subUnitArr);
      requestModel.unit = unit;
    }
    // requestModel.unit = unit;
    requestModel.code = txtTaxNumber.text;
    requestModel.sku = txtBarCode.text;
    requestModel.media = [Media(url: cubit.uploadImgModel?.cdnImage ?? '')];
    String result = await cubit.validateInputData(requestModel);
    print('=====$result');
    if (stringIsEmptyOrNull(result)) {
      if (cubit.uploadImgModel?.cdnImage == '' || b64Img != '') {
        await loadingDialog.show();
        await cubit.uploadImage(b64Img);
      } else {
        _saveProduct();
      }
    } else {
      showToastFailed(result);
    }
  }

  void _addDataToRequest() {
    if (unit_base.name != '') {
      for (int i = 0; i < subUnitArr.length; i++) {
        subUnitArr[i].index = i;
      }
      // var unit = UnitRequest(unitBase: unit_base, subUnit: [sub_init]);
      var unit = UnitRequest(unitBase: unit_base, subUnit: subUnitArr);
      requestModel.unit = unit;
    }
    requestModel.code = txtTaxNumber.text;
    requestModel.sku = txtBarCode.text;
    if (photoArr.isNotEmpty) {
      List<Media> mediaArr = [];
      photoArr.forEach((element) {
        mediaArr.add(Media(url: element.cdnImage));
      });
      requestModel.media = mediaArr;
    }
  }

  void _saveProduct() async {
    _addDataToRequest();
    String result = await cubit.validateInputData(requestModel);
    print('=====$result');
    if (!stringIsEmptyOrNull(result)) {
      showToastFailed(result);
    } else {
      loadingDialog.show();
      cubit.addNewProduct(requestModel);
    }
  }

  void onSelectedBrand(Brand p1) {
    txtBrand.text = p1.text;
    requestModel.brandId = p1.id;
  }

  Widget _infoProduct() {
    return Container(
      padding: EdgeInsets.only(left: 16, right: 16),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: [
              Expanded(
                child: TextField(
                  obscureText: false,
                  decoration: InputDecoration(
                    labelText: 'Mã hàng',
                  ),
                  style: TextStyle(
                    fontSize: 14,
                    height: 1,
                  ),
                  controller: txtTaxNumber,
                ),
              ),
              IconButton(
                icon: Icon(
                  Icons.qr_code,
                ),
                onPressed: () {
                  this.scanBarcodeNormal();
                },
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                  child: TextField(
                obscureText: false,
                decoration: InputDecoration(labelText: 'Mã vạch'),
                style: TextStyle(fontSize: 14, height: 1),
                controller: txtBarCode,
              )),
              IconButton(
                icon: Icon(
                  Icons.qr_code,
                ),
                onPressed: () {
                  this.scanQR();
                },
              ),
            ],
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Tên hàng'),
            style: TextStyle(fontSize: 14, height: 1),
            onChanged: (value) => {requestModel.name = value},
          ),
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(
                labelText: 'Thương hiệu',
                suffixIcon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                )),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => ListBrand(onSelectedBrand)))
            },
            controller: txtBrand,
          ),
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(
                labelText: 'Nhóm hàng',
                suffixIcon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                )),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => ListCategory(onSelectedCate)))
            },
            controller: txtCategory,
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Giá bán'),
            style: TextStyle(fontSize: 14, height: 1),
            controller: txtPrice,
            keyboardType: TextInputType.number,
            onChanged: (value) => {requestModel.sellPrice = int.parse(value)},
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Giá vốn'),
            style: TextStyle(fontSize: 14, height: 1),
            keyboardType: TextInputType.number,
            onChanged: (value) => {requestModel.costPrice = int.parse(value)},
            controller: txtPriceCost,
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Tồn kho'),
            style: TextStyle(fontSize: 14, height: 1),
            controller: txtStock,
            keyboardType: TextInputType.number,
            onChanged: (value) => {requestModel.beginStock = int.parse(value)},
          ),
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(
                labelText: 'Vị trí',
                suffixIcon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                )),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ListPosition(onSelectedPosition)))
            },
            controller: txtPosition,
          ),
        ],
      ),
    );
  }

  void onSelectedCate(Category p1) {
    txtCategory.text = p1.name!;
    requestModel.categoryId = '${p1.id}';
  }

  void onSelectedPosition(Position p1) {
    txtPosition.text = p1.name;
    requestModel.productRacks = [p1.id];
  }

  _buildPhotoSelection() {
    return Container(
      height: 132,
      width: double.infinity,
      child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
          child: ListView.separated(
            itemCount: photoArr.length + 1,
            shrinkWrap: true,
            physics: BouncingScrollPhysics(),
            scrollDirection: Axis.horizontal,
            itemBuilder: (buildContext, ind) {
              if (ind == photoArr.length) {
                return ClipRRect(
                    borderRadius: BorderRadius.circular(12.0),
                    child: InkWell(
                      onTap: () {
                        if (cubit.isUploadImg) return;
                        this.getImage();
                      },
                      child: Container(
                        width: 100,
                        height: 100,
                        color: Colors.blueGrey,
                        child: Center(
                          child: cubit.isUploadImg
                              ? CircularProgressIndicator(
                                  color: Colors.white,
                                )
                              : Icon(
                                  Icons.photo_camera,
                                  color: Colors.white,
                                  size: 45,
                                ),
                        ),
                      ),
                    ));
              } else {
                return _buildPhotoItem(ind);
              }
            },
            separatorBuilder: (BuildContext context, int index) {
              return SizedBox(
                width: 8,
              );
            },
          )),
    );
  }

  _buildPhotoItem(int index) {
    return Stack(
      children: [
        ClipRRect(
            borderRadius: BorderRadius.circular(12.0),
            child: CachedNetworkImage(
              imageUrl: photoArr[index].cdnImage ?? '',
              width: 100,
              height: 100,
              fit: BoxFit.cover,
            )
            // Image.file(
            //   _image!,
            //   width: 100,
            //   height: 100,
            //   fit: BoxFit.cover,
            // ),
            ),
        Positioned(
          right: -5,
          top: -5,
          child: IconButton(
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
            icon: Icon(
              Icons.remove_circle_sharp,
              color: Colors.red,
            ),
            onPressed: () {
              setState(() {
                photoArr.removeAt(index);
              });
            },
          ),
        )
      ],
    );
  }
}
