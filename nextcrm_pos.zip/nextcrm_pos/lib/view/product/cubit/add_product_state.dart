part of 'add_product_cubit.dart';

@immutable
abstract class AddProductState {}

class AddProductInitial extends AddProductState {}

class UploadImgSuccess extends AddProductState {
  final UploadImgResponse response;

  UploadImgSuccess(this.response);
}

class UploadImgFailed extends AddProductState {}
class StatusUploadImg extends AddProductState {}

class AddProductSuccess extends AddProductState {
  final AddNewProductModel response;

  AddProductSuccess(this.response);
}

class AddProductFailed extends AddProductState {
  final String reasonFailed;
  AddProductFailed(this.reasonFailed);
}