import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:vidifi/model/ProductRequest.dart';
import 'package:vidifi/util/dialog_utils.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/upload_image_repo.dart';
import 'package:vidifi/view/product/model/add_new_product_model.dart';
import 'package:vidifi/view/product/model/upload_img_model.dart';
import 'package:vidifi/view/product/repo/add_product_repo.dart';

part 'add_product_state.dart';

class AddProductCubit extends Cubit<AddProductState> {
  AddProductCubit() : super(AddProductInitial());

  AddProductRepo repo = AddProductRepo();
  UploadImgResponse? uploadImgModel;
  AddNewProductModel? newProductModel;
  bool isUploadImg = false;

  Future<void> updateStatusUploadImg(bool isUploading) async {
    isUploadImg = isUploading;
    emit(StatusUploadImg());
  }

  Future<String> validateInputData(ProductRequest productRequest) async {
    String stringResult = '';
    if (stringIsEmptyOrNull(productRequest.code)) {
      stringResult = stringResult + 'Mã sản phẩm không được để trống\n';
    }
    if (stringIsEmptyOrNull(productRequest.name)) {
      stringResult = stringResult + 'Tên sản phẩm không được để trống\n';
    }
    return stringResult;
  }

  Future<void> uploadImage(String b64Img) async {
    try {
      // LoadingDialog().show();
      isUploadImg = true;
      Map data = {'image_base64': 'data:image/jpeg;base64,'+b64Img};
      uploadImgModel = await UploadImageRepo().uploadImage(data);
      isUploadImg = false;
      if (stringIsEmptyOrNull(uploadImgModel?.cdnImage)) {
        emit(UploadImgFailed());
      } else {
        emit(UploadImgSuccess(uploadImgModel!));
      }
    } catch (e) {
      print(e.toString());
      print('============== ERROR');
      emit(UploadImgFailed());
    }
  }

  Future<void> addNewProduct(ProductRequest productRequest) async {
    try {
      newProductModel = await repo.addNewProduct(productRequest);
      if (newProductModel != null) {
        if (newProductModel?.meta?.statusCode == 0) {
          emit(AddProductSuccess(newProductModel!));
        } else {
          emit(AddProductFailed(newProductModel?.meta?.message ?? 'Đã có lỗi xảy ra'));
        }
      }
    } catch (e) {
      emit(AddProductFailed('Đã có lỗi xảy ra'));
    }
  }
}
