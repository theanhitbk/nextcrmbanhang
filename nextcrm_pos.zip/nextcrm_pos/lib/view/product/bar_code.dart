import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/util/handle_logout.dart';

import '../login.dart';

class ScanBarCode extends StatefulWidget {
  @override
  _ScanBarCode createState() => _ScanBarCode();
}

class _ScanBarCode extends State<ScanBarCode> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Chọn thuộc tính'),
      backgroundColor: Colors.green,),
      backgroundColor: greyColor2,
      body: Padding(
        padding: EdgeInsets.all(4),
        child: Container(
          child: Center(),
        ),
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
