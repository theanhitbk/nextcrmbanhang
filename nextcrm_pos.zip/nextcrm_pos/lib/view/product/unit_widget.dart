import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vidifi/model/ProductRequest.dart';

class UnitWidget extends StatefulWidget {
  // final Function({UnitBase unit, List<SubUnit> subUnitArray}) updateValue;
  final UnitBase unitBase;
  final List<SubUnit> subUnitArray;
  final Function(int index) removeSubUnit;
  const UnitWidget({Key? key, required this.unitBase, required this.subUnitArray, required this.removeSubUnit}) : super(key: key);

  @override
  _UnitWidgetState createState() => _UnitWidgetState();
}

class _UnitWidgetState extends State<UnitWidget> {

  List<TextEditingController> _controllers = [];
  TextEditingController _unitController = new TextEditingController();

  bool isDidAddUnit = false;
  bool isEnableCreate = true;

  // var unit_base = UnitBase(name: "", isDirectSell: true);
  // var sub_init = SubUnit(index: 0, name: 'thùng', fConvert: 10, price: 280000, isDirectSell: true);

  @override
  void initState() {
    _controllers.add(new TextEditingController());
    super.initState();
  }

  void updateValue() {
    if (widget.subUnitArray.length > 0 ) {
      for(SubUnit unit in widget.subUnitArray) {
        if (unit.name?.trim() != '') {
          isEnableCreate = true;
        } else {
          isEnableCreate = false;
          return;
        }
      }

    } else {
      isEnableCreate = widget.unitBase.name != '';
    }

  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      // height: 50+ _list.length * 50,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Visibility(
            visible: isDidAddUnit,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  color: Colors.white,
                  height: 50,
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          /// REMOVE ALL UNIT
                          if (widget.unitBase.name?.trim() == '') {
                            FocusScope.of(context).unfocus();
                            widget.unitBase.name = '';
                            widget.unitBase.isDirectSell = true;
                            _unitController.text = '';
                            widget.subUnitArray.clear();
                            isEnableCreate = true;
                            isDidAddUnit = false;
                          } else {
                            showPopupConfirmRemoveUnit();
                          }
                        },
                        child: Container(
                          height: double.infinity,
                          width: 32,
                          child: Icon(
                            Icons.remove_circle_outline_outlined,
                            color: Colors.red,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 4,
                      ),
                      Container(
                        width: 150,
                        child: Text(
                          'Đơn vị tính cơ bản',
                          // style: TextStyle(color: Colors.grey, fontSize: 14),
                        ),
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Expanded(
                        child: TextField(
                          obscureText: false,
                          autofocus: true,
                          decoration: InputDecoration(hintText: 'Đơn vị', border: InputBorder.none),
                          style: TextStyle(fontSize: 14, height: 1),
                          controller: _unitController,
                          onChanged: (value)  {
                            // _unitController.text = value;
                            isEnableCreate = value.length > 0;
                            widget.unitBase.name = value;
                          },
                        ),
                      )
                      // Text(_list[index].valueUnit, style: TextStyle(color: Colors.grey, fontSize: 14),),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 16, left: 50),
                  child: Divider(
                    color: Colors.grey,
                    height: 1,
                  ),
                ),
                Container(
                  color: Colors.white,
                  height: 50,
                  padding: EdgeInsets.only(left: 50),
                  child: Row(
                    children: <Widget>[
                      Text('Bán trực tiếp'),
                      Spacer(),
                      CupertinoSwitch(
                        value: widget.unitBase.isDirectSell ?? true,
                        onChanged: (value) {
                          setState(() {
                            widget.unitBase.isDirectSell = value;
                          });
                        },
                      ),
                      SizedBox(
                        width: 16,
                      )
                    ],
                  ),
                  // Row(
                  //   children: [
                  //     Text('Bán trực tiếp', style: TextStyle(color: Colors.grey, fontSize: 14),),
                  //     SizedBox(width: 8,),
                  //     Expanded(
                  //       child: TextField(
                  //         obscureText: false,
                  //         decoration: InputDecoration(hintText: _list[index].valueUnit, border: InputBorder.none),
                  //         style: TextStyle(fontSize: 14, height: 1),
                  //         controller: _controllers[index],
                  //         onChanged: (value) => {_list[index].valueUnit = value},
                  //       ),
                  //     )
                  //     // Text(_list[index].valueUnit, style: TextStyle(color: Colors.grey, fontSize: 14),),
                  //   ],
                  // ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Divider(
              color: Colors.grey,
              height: 1,
            ),
          ),
          ListView.separated(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            physics: BouncingScrollPhysics(),
            itemCount: widget.subUnitArray.length,
            itemBuilder: (ctx, index) {
              return buildSubUnitItem(index);
            },
            separatorBuilder: (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Divider(
                  color: Colors.grey,
                  height: 1,
                ),
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Divider(
              color: Colors.grey,
              height: 1,
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                /// Add UNIT
                isDidAddUnit = true;
                updateValue();
                if (isEnableCreate) {
                  // FocusScope.of(context).unfocus();
                  widget.subUnitArray.add(SubUnit(index: 0, name: '', fConvert: 0, price: 0, isDirectSell: true));
                  updateValue();
                }
              });
            },
            child: Container(
              color: Colors.white,
              height: 50,
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Container(
                    width: 32,
                    child: Icon(
                      Icons.add_circle_outline_outlined,
                      color: Colors.blue,
                      // color: !isCanAddSub ? Colors.blue : (isDidAddUnit ? Colors.grey : Colors.blue),
                    ),
                  ),
                  SizedBox(
                    width: 4,
                  ),
                  Text(
                    'Thêm đơn vị',
                    // style: TextStyle(color: Colors.grey, fontSize: 14),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  buildSubUnitItem(int index) {
    // TextEditingController _nameUnitController = new TextEditingController();
    // TextEditingController _fUnitController = new TextEditingController();
    // TextEditingController _priceUnitController = new TextEditingController();
    return Column(
      children: [
        Container(
          color: Colors.white,
          height: 50,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  FocusScope.of(context).unfocus();
                    setState(() {
                      print('REMOVE AT $index');
                      widget.removeSubUnit(index);
                      updateValue();
                      // widget.subUnitArray.removeAt(index);
                    });
                },
                child: Container(
                  height: double.infinity,
                  width: 32,
                  child: Icon(
                    Icons.remove_circle_outline_outlined,
                    color: Colors.red,
                  ),
                ),
              ),
              SizedBox(
                width: 4,
              ),
              Container(
                width: 150,
                child: Text(
                  'Tên đơn vị',
                  // style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: TextField(
                  obscureText: false,
                  autofocus: true,
                  decoration: InputDecoration(hintText: 'Tên đơn vị', border: InputBorder.none),
                  style: TextStyle(fontSize: 14, height: 1),
                  controller: widget.subUnitArray[index].nameUnitController,
                  onChanged: (value) => {
                    widget.subUnitArray[index].name = value
                  },
                ),
              )
              // Text(_list[index].valueUnit, style: TextStyle(color: Colors.grey, fontSize: 14),),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 16, left: 50),
          child: Divider(
            color: Colors.grey,
            height: 1,
          ),
        ),
        Container(
          color: Colors.white,
          height: 50,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              SizedBox(
                width: 34,
              ),
              Container(
                width: 150,
                child: Text(
                  'Giá trị quy đổi',
                  // style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: TextField(
                  obscureText: false,
                  keyboardType: TextInputType.number,
                  decoration:
                      InputDecoration(hintText: 'Giá trị quy đổi', border: InputBorder.none),
                  style: TextStyle(fontSize: 14, height: 1),
                  controller: widget.subUnitArray[index].fUnitController,
                  onChanged: (value) => {
                    widget.subUnitArray[index].fConvert = int.parse(value)
                  },
                ),
              )
              // Text(_list[index].valueUnit, style: TextStyle(color: Colors.grey, fontSize: 14),),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 16, left: 50),
          child: Divider(
            color: Colors.grey,
            height: 1,
          ),
        ),
        Container(
          color: Colors.white,
          height: 50,
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              // Icon(Icons.remove_circle_outline_outlined, color: index == (_list.length - 1) ? Colors.blue : Colors.red,),
              SizedBox(
                width: 34,
              ),
              Container(
                width: 150,
                child: Text(
                  'Giá bán',
                  // style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: TextField(
                  obscureText: false,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(hintText: 'Giá bán', border: InputBorder.none),
                  style: TextStyle(fontSize: 14, height: 1),
                  controller: widget.subUnitArray[index].priceUnitController,
                  onChanged: (value) => {
                    widget.subUnitArray[index].fConvert = int.parse(value)
                  },
                ),
              )
              // Text(_list[index].valueUnit, style: TextStyle(color: Colors.grey, fontSize: 14),),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 16, left: 50),
          child: Divider(
            color: Colors.grey,
            height: 1,
          ),
        ),
        Container(
          color: Colors.white,
          height: 50,
          padding: EdgeInsets.only(left: 50),
          child: Row(
            children: <Widget>[
              Text('Bán trực tiếp'),
              Spacer(),
              CupertinoSwitch(
                value: widget.subUnitArray[index].isDirectSell ?? true,
                onChanged: (value) {
                  setState(() {
                    widget.subUnitArray[index].isDirectSell = value;
                  });
                },
              ),
              SizedBox(
                width: 16,
              )
            ],
          ),
          // Row(
          //   children: [
          //     Text('Bán trực tiếp', style: TextStyle(color: Colors.grey, fontSize: 14),),
          //     SizedBox(width: 8,),
          //     Expanded(
          //       child: TextField(
          //         obscureText: false,
          //         decoration: InputDecoration(hintText: _list[index].valueUnit, border: InputBorder.none),
          //         style: TextStyle(fontSize: 14, height: 1),
          //         controller: _controllers[index],
          //         onChanged: (value) => {_list[index].valueUnit = value},
          //       ),
          //     )
          //     // Text(_list[index].valueUnit, style: TextStyle(color: Colors.grey, fontSize: 14),),
          //   ],
          // ),
        ),
      ],
    );
  }

  void showPopupConfirmRemoveUnit() {
    showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        content: new Text(
            'Bạn có chắc chắn muốn xóa đơn vị tính này?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: new Text('Bỏ qua'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                FocusScope.of(context).unfocus();
                widget.unitBase.name = '';
                widget.unitBase.isDirectSell = true;
                _unitController.text = '';
                widget.subUnitArray.clear();
                isEnableCreate = true;
                isDidAddUnit = false;
                // updateValue();
              });
              Navigator.of(context).pop(false);
            },
            child: new Text('Đồng ý'),
          ),
        ],
      ),
    );
  }

}

