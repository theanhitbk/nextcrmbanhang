import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Property.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/util/section_data_manager.dart';

import 'components/property_card.dart';

class ListProperty extends StatefulWidget {
  final void Function(List<Property>) onSelected;
  ListProperty(this.onSelected);
  @override
  _ListProperty createState() => _ListProperty(this.onSelected);
}

class _ListProperty extends State<ListProperty> {
  var _onSelected;
  _ListProperty(this._onSelected);
  ScrollController _sc = new ScrollController();
  List<Property> properties = [];
  @override
  void initState() {
    this._getListProperty();
    super.initState();
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chọn thuộc tính',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
        actions: [
          TextButton(
              onPressed: () async {
                PropertyResponse propertyRes = PropertyResponse(data: properties);
                SectionDataManager.getInstance()?.savePropertyResponse(propertyRes);
                this._onSelected(properties);
                Navigator.pop(context);
              },
              child: Text(
                'Xong',
                style: TextStyle(color: Colors.white),
              ))
        ],
      ),
      backgroundColor: greyColor2,
      body: Padding(
        padding: EdgeInsets.all(4),
        child: Container(
          child: _buildListProperty(),
        ),
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  void _getListProperty() async {
    var property = SectionDataManager.getInstance()?.returnProperty();
    if (property != null) {
      print('NOT NULL');
      setState(() {
        properties.addAll(property.data);
      });
    } else {
      print('DATA NULL');
      final response = await APIService().fetchProperties().catchError((e) {});
      setState(() {
        properties.addAll(response.data);
        print('======= ${jsonEncode(response)}');
        SectionDataManager.getInstance()?.savePropertyResponse(response);
        // HiveManager.getInstance().put('list_property', jsonEncode(response));
      });
    }


    ///This save to local storage
    // Map<String, dynamic> listPropertyJson = await jsonDecode(HiveManager.getInstance().get('list_property') ?? '{}') ?? {};
    // print('JSON $listPropertyJson');
    // if (listPropertyJson.length == 0) {
    //   print('NULL HIVE');
    //   final response = await APIService().fetchProperties().catchError((e) {});
    //   setState(() {
    //     properties.addAll(response.data);
    //     print('======= ${jsonEncode(response)}');
    //     HiveManager.getInstance().put('list_property', jsonEncode(response));
    //   });
    // } else {
    //   print('NOT NULL HIVE');
    //   print(listPropertyJson.toString());
    //   setState(() {
    //     properties.addAll(PropertyResponse.fromJson(listPropertyJson).data);
    //   });
    // }

  }

  Widget _buildListProperty() {
    return ListView.builder(
      shrinkWrap: true,
      physics: BouncingScrollPhysics(),
      padding: EdgeInsets.only(top: 16),
      itemCount: properties.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        return PropertyCard(properties[index]);
      },
      controller: _sc,
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
