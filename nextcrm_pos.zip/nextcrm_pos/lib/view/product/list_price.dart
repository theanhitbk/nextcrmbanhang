import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/search_bar.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

class ListPrice extends StatefulWidget {
  final void Function(Price) onSelected;
  ListPrice(this.onSelected);

  @override
  _ListPrice createState() => _ListPrice(this.onSelected);
}

class _ListPrice extends State<ListPrice> {
  var _onSelected;

  _ListPrice(this._onSelected);

  ScrollController _sc = new ScrollController();
  TextEditingController _cSearch = TextEditingController();
  List<Price> prices = [];
  List<Price> rawArray = [];
  late ProfileCubit _profileCubit;
  Price? _selectedPrice;

  @override
  void initState() {
    _profileCubit = context.read<ProfileCubit>();
    this._getListPrice();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chọn bảng giá', style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
      ),
      backgroundColor: greyColor2,
      body: Column(
        children: [
          SearchBarCommon(
            controller: _cSearch,
            hintText: 'Nhập tên bảng giá',
            textChanged: (text) {
              print('CHANGED TEXT: $text');
              _filter(text);
            },
            isDelayed: false,
          ),
          Expanded(child: _buildListPrice()),
        ],
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  void _getListPrice() async {
    // final response = await APIService().fetchPrice().catchError((e) {});
    // setState(() {
    //   prices.addAll(response.data);
    //   rawArray = prices;
    // });
    setState(() {
      if (_profileCubit.priceBooks != null) {
        prices.addAll(_profileCubit.priceBooks!);
        rawArray = prices;
      }
      _selectedPrice = _profileCubit.selectedPrice;
    });
  }

  Widget _buildListPrice() {
    return Container(
      color: Colors.white,
      child: ListView.separated(
        padding: EdgeInsets.only(top: 0),
        itemCount: prices.length,
        itemBuilder: (BuildContext context, int index) {
          var price = prices[index];
          return TextButton(
            child: Row(mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
              SizedBox(
                width: 12,
              ),
              Text(
                price.name,
                maxLines: 2,
                style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.normal),
                textAlign: TextAlign.start,
              ),
              Spacer(),
              Visibility(
                visible: price == _selectedPrice,
                  child: Icon(
                Icons.check,
                color: Colors.green,
              ))
            ]),
            onPressed: () {
              _profileCubit.updatePriceBook(price);
              _onSelected(price);
              Navigator.pop(context);
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
              // shape:
              //     MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
              //   borderRadius: BorderRadius.all(Radius.circular(6)),
              // )),
            ),
          );
        },
        controller: _sc,
        separatorBuilder: (BuildContext context, int index) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Divider(
              height: 1,
            ),
          );
        },
      ),
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  void _filter(String text) {
    text = text.trim().toLowerCase();
    if (stringIsEmptyOrNull(text)) {
      setState(() {
        prices = rawArray;
      });
      return;
    }
    List<Price> _searchedList = [];
    print('LENGTH RAW: ${rawArray.length}');
    if (text.length > 0) {
      rawArray.forEach((element) {
        if (element.name.toLowerCase().contains(text)) {
          _searchedList.add(element);
        }
      });
    }
    print('LENGTH FILTER: ${_searchedList.length}');

    setState(() {
      if (_searchedList.length > 0) prices = _searchedList;
    });
  }
}
