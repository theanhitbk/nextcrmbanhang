import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Position.dart';
import 'package:vidifi/services/api_service.dart';

class ListPosition extends StatefulWidget {
  final void Function(Position) onSelected;
  ListPosition(this.onSelected);
  @override
  _ListPosition createState() => _ListPosition(this.onSelected);
}

class _ListPosition extends State<ListPosition> {
  var _onSelected;
  _ListPosition(this._onSelected);
  ScrollController _sc = new ScrollController();
  List<Position> positions = [];
  final txtPositionName = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  late PositionRequest requestModel;
  @override
  void initState() {
    this._getListPosition();
    super.initState();
    requestModel = new PositionRequest();
  }

  @override
  void dispose() {
    txtPositionName.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chọn vị trí',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        content: Stack(
                          overflow: Overflow.visible,
                          children: <Widget>[
                            Form(
                              key: _formKey,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Text(
                                      'Thêm vị trí',
                                      style: TextStyle(fontSize: 18),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: TextFormField(
                                      controller: txtPositionName,
                                      onChanged: (txtName) =>
                                          requestModel.name = txtName,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        // ignore: deprecated_member_use
                                        child: RaisedButton(
                                          child: Text("Hủy bỏ"),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ),
                                      Spacer(),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        // ignore: deprecated_member_use
                                        child: RaisedButton(
                                          child: Text("Lưu"),
                                          onPressed: () {
                                            this._savePosition();
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    });
              },
              icon: Icon(
                Icons.add,
                color: Colors.white,
              ))
        ],
      ),
      backgroundColor: greyColor2,
      body: Padding(padding: EdgeInsets.all(4), child: _buildListPrice()),
      resizeToAvoidBottomInset: false,
    );
  }

  void _getListPosition() async {
    final response = await APIService().fetchPositions().catchError((e) {});
    setState(() {
      positions.clear();
      positions.addAll(response.data);
    });
  }

  void _savePosition() async {
    requestModel.description = "";
    final response =
        await APIService().addNewPosition(requestModel).catchError((e) {});
    setState(() {
      _getListPosition();
    });
  }

  Widget _buildListPrice() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: positions.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        var position = positions[index];
        return Container(
          child: TextButton(
            child: Row(
              children: <Widget>[
                Flexible(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              position.name,
                              maxLines: 2,
                              style: TextStyle(
                                  color: primaryColor,
                                  fontSize: 14,
                                  fontWeight: FontWeight.normal),
                              textAlign: TextAlign.start,
                            ),
                          ],
                        ),
                      ),
                    ]))
              ],
            ),
            onPressed: () {
              _onSelected(position);
              Navigator.pop(context);
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
              shape: MaterialStateProperty.all<OutlinedBorder>(
                  RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(6)),
              )),
            ),
          ),
          margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
        );
      },
      controller: _sc,
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
