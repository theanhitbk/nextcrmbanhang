import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/services/api_const.dart';
import 'package:vidifi/services/api_request.dart';
import 'package:vidifi/view/customer/model/create_customer_response.dart';

class CreateCustomerRepo {

  Future<CreateCustomerResponse> createNewCustomer(CustomerRequest customerRequest) async {
    String url = '/api/customer/customer';
    final response = await BaseRequestAPI().sendRequest(baseUrl+url, RequestMethod.POST,
        jsonMap: json.encode(customerRequest));
    return await compute(createCustomerResponseFromJson, response);
  }

}