part of 'create_customer_cubit.dart';

@immutable
abstract class CreateCustomerState {}

class CreateCustomerInitial extends CreateCustomerState {}


class UploadAvatarSuccess extends CreateCustomerState {
  final UploadImgResponse response;

  UploadAvatarSuccess(this.response);
}

class UploadAvatarFailed extends CreateCustomerState {}

class CreateCustomerSuccess extends CreateCustomerState {
  final CreateCustomerResponse response;

  CreateCustomerSuccess(this.response);
}

class CreateCustomerFailed extends CreateCustomerState {
  final String reasonFailed;
  CreateCustomerFailed(this.reasonFailed);
}