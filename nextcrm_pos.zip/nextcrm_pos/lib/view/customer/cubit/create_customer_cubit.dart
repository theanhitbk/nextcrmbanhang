import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/upload_image_repo.dart';
import 'package:vidifi/view/customer/cubit/create_customer_repo.dart';
import 'package:vidifi/view/customer/model/create_customer_response.dart';
import 'package:vidifi/view/product/model/upload_img_model.dart';

part 'create_customer_state.dart';

class CreateCustomerCubit extends Cubit<CreateCustomerState> {
  CreateCustomerCubit() : super(CreateCustomerInitial());

  CreateCustomerRepo repo = CreateCustomerRepo();

  UploadImgResponse? uploadImgModel;
  CreateCustomerResponse? customerResponse;

  Future<void> uploadAvatarCustomer(String b64Img) async {
    try {
      Map data = {'image_base64': 'data:image/jpeg;base64,'+b64Img};
      uploadImgModel = await UploadImageRepo().uploadImage(data);
      if (stringIsEmptyOrNull(uploadImgModel?.cdnImage)) {
        emit(UploadAvatarFailed());
      } else {
        emit(UploadAvatarSuccess(uploadImgModel!));
      }
    } catch (e) {
      print(e.toString());
      emit(UploadAvatarFailed());
    }
  }

  Future<void> createNewCustomer(CustomerRequest customerRequest) async {
    try {
      customerResponse = await repo.createNewCustomer(customerRequest);
      if (customerResponse != null) {
        if (customerResponse?.meta?.statusCode == 0) {
          emit(CreateCustomerSuccess(customerResponse!));
        } else {
          emit(CreateCustomerFailed(customerResponse?.meta?.message ?? 'Đã có lỗi xảy ra'));
        }
      }
    } catch (e) {
      emit(CreateCustomerFailed('Đã có lỗi xảy ra'));
    }
  }
}
