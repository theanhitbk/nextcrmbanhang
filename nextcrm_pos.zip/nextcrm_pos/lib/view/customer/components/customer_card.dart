import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';

class CustomerCard extends StatelessWidget {
  const CustomerCard({
    Key? key,
    required this.customer,
  }) : super(key: key);
  final Customer customer;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextButton(
        child: Row(
          children: <Widget>[
            customer.landmark.isEmpty
                ? CircleAvatar(
                    child: Text(
                      customer.text.characters.first.toUpperCase(),
                      style: TextStyle(fontSize: 32, color: Colors.white),
                    ),
                    backgroundColor: Colors.blue,
                  )
                : Image.network(
                    customer.landmark,
                    fit: BoxFit.cover,
                    width: 50.0,
                    height: 50.0,
                    loadingBuilder: (BuildContext context, Widget child,
                        ImageChunkEvent? loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Container(
                        width: 24,
                        height: 24,
                        child: Center(
                          child: CircularProgressIndicator(
                            backgroundColor: primaryColor,
                            value: loadingProgress.expectedTotalBytes != null &&
                                    loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded /
                                    loadingProgress.expectedTotalBytes!
                                : null,
                          ),
                        ),
                      );
                    },
                  ),
            Flexible(
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          customer.text,
                          maxLines: 2,
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: 14,
                              fontWeight: FontWeight.normal),
                          textAlign: TextAlign.start,
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        Text(
                          customer.contactId,
                          maxLines: 1,
                          style: TextStyle(
                            color: primaryColor,
                            fontSize: 10,
                          ),
                          textAlign: TextAlign.left,
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        SizedBox(
                          height: 16,
                          child: FlatButton.icon(
                              padding: const EdgeInsets.only(left: 0),
                              label: Text(
                                customer.mobile.isEmpty
                                    ? 'Chưa cập nhật'
                                    : customer.mobile,
                                maxLines: 1,
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 12,
                                ),
                              ),
                              icon: const Icon(
                                Icons.phone,
                                size: 12,
                              ),
                              onPressed: () {}),
                        ),
                      ],
                    ),
                  ),
                ]))
          ],
        ),
        onPressed: () {
          // Open detail
          // Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //           builder: (context) => WebViewExample(news.ArticleUrl)));
        },
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          shape:
              MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(6)),
          )),
        ),
      ),
      margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }
}
