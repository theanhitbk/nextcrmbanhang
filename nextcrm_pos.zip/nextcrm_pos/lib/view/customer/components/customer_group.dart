
import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Price.dart';

class CustomerGroupCard extends StatelessWidget {
  const CustomerGroupCard({
    Key? key,
    required this.customerGroup, required this.onSelected,
  }) : super(key: key);
  final CustomerGroup customerGroup;
  final void Function(CustomerGroup) onSelected;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextButton(
        child: Row(
          children: <Widget>[
            Flexible(
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          customerGroup.name ?? '',
                          maxLines: 1,
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: 14,
                              fontWeight: FontWeight.normal),
                          textAlign: TextAlign.start,
                        ),
                      ],
                    ),
                  ),
                ]))
          ],
        ),
        onPressed: () => onSelected(customerGroup),
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          shape:
              MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(6)),
          )),
        ),
      ),
      margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }
}
