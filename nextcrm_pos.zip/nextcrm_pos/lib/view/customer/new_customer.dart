import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Province.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/dialog_utils.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/customer/cubit/create_customer_cubit.dart';
import 'package:vidifi/view/customer/list_group_customer.dart';

import 'list_province.dart';

class NewCustomer extends StatefulWidget {
  @override
  _NewCustomer createState() => _NewCustomer();
}

class _NewCustomer extends State<NewCustomer> {
  File? _image = null;
  final ImagePicker picker = ImagePicker();

  String dropdownValue = 'Nam';
  ScrollController _sc = new ScrollController();
  DateTime selectedDate = DateTime.now();
  final txtBirthday = TextEditingController();
  final txtTaxNumber = TextEditingController();
  final txtGroup = TextEditingController();
  final txtPhone = TextEditingController();
  final txtProvince = TextEditingController();
  final txtCustomerGroup = TextEditingController();
  final txtAddress = TextEditingController();
  final txtEmail = TextEditingController();
  final txtDescription = TextEditingController();
  final txtName = TextEditingController();
  late CustomerRequest requestModel = CustomerRequest();

  String b64Img = '';

  CreateCustomerCubit cubit = CreateCustomerCubit();
  late LoadingDialog loadingDialog;

  @override
  void initState() {
    loadingDialog = LoadingDialog(context);
    super.initState();
  }

  @override
  void dispose() {
    _sc.dispose();
    txtBirthday.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => cubit,
      child: BlocConsumer<CreateCustomerCubit, CreateCustomerState>(
        listener: (context, state) {
          if (state is UploadAvatarSuccess) {
            loadingDialog.dismiss();
            requestModel.avatar = state.response.cdnImage ?? '';
            _saveCustomer();
          }
          if (state is UploadAvatarFailed) {
            loadingDialog.dismiss();
            showToastFailed('Xảy ra lỗi khi upload ảnh');
          }
          if (state is CreateCustomerSuccess) {
            loadingDialog.dismiss();
            showToastSuccess(state.response.meta?.message ?? 'Success');
            Future.delayed(Duration(milliseconds: 500), (){
              Navigator.of(context).pop();
            } );
          }
          if (state is CreateCustomerFailed) {
            loadingDialog.dismiss();
            showToastFailed(state.reasonFailed);
          }
        },
        builder: (context, state) {
          return Scaffold(
              appBar: AppBar(
                title: Text('Thêm khách hàng',
                    style: TextStyle(color: Colors.white, fontSize: 16)),
                backgroundColor: Colors.green,
                actions: [
                  TextButton(
                      onPressed: () {
                        // this._saveCustomer();
                        _uploadAvatarFirst();
                      },
                      child: Text(
                        'Lưu',
                        style: TextStyle(color: Colors.white),
                      ))
                ],
              ),
              backgroundColor: greyColor2,
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      color: Colors.white,
                      child: Row(
                        children: <Widget>[
                          Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: _image == null
                                  ? CircleAvatar(
                                child: TextButton(
                                  onPressed: () {
                                    this.getImage();
                                  },
                                  child: Text(
                                    'Thêm ảnh',
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.amber),
                                  ),
                                ),
                                backgroundColor: Colors.grey,
                                radius: 50.0,
                              )
                                  : Image.file(
                                _image!,
                                width: 100,
                                height: 100,
                              )),
                          Flexible(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                TextField(
                                  obscureText: false,
                                  decoration:
                                  InputDecoration(labelText: 'Mã tự động'),
                                  style: TextStyle(fontSize: 14, height: 1),
                                ),
                                TextField(
                                  obscureText: false,
                                  decoration:
                                  InputDecoration(labelText: 'Tên khách hàng'),
                                  style: TextStyle(fontSize: 14, height: 1),
                                  controller: txtName,
                                ),
                                TextField(
                                  obscureText: false,
                                  decoration: InputDecoration(labelText: 'Cá nhân'),
                                  style: TextStyle(fontSize: 14, height: 1),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 44,
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 16, right: 16),
                      color: Colors.white,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          TextField(
                            readOnly: true,
                            obscureText: false,
                            decoration: InputDecoration(
                                labelText: 'Chọn giói tính',
                                suffixIcon: DropdownButton<String>(
                                  value: dropdownValue,
                                  icon: const Icon(
                                    Icons.arrow_downward,
                                    size: 20,
                                  ),
                                  elevation: 12,
                                  style: const TextStyle(color: Colors.deepPurple),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      dropdownValue = newValue!;
                                      requestModel.gender = ['Nam', 'Nữ'].indexOf(newValue) == 0;
                                    });
                                  },
                                  items: <String>['Nam', 'Nữ']
                                      .map<DropdownMenuItem<String>>((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                )
                            ),
                            style: TextStyle(fontSize: 14, height: 1),
                            onTap: () => {},
                          ),
                          TextField(
                            readOnly: true,
                            obscureText: false,
                            decoration: InputDecoration(labelText: 'Ngày sinh'),
                            style: TextStyle(fontSize: 14, height: 1),
                            onTap: () => _selectDate(context),
                            controller: txtBirthday,
                          ),
                          TextField(
                            readOnly: true,
                            obscureText: false,
                            decoration: InputDecoration(
                                labelText: 'Nhóm khách hàng',
                                suffixIcon: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 20,
                                )),
                            style: TextStyle(fontSize: 14, height: 1),
                            onTap: () =>
                            {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ListCustomerGroup(onSelectedGroup)))
                            },
                            controller: txtCustomerGroup,
                          ),
                          TextField(
                            obscureText: false,
                            decoration: InputDecoration(labelText: 'Mã số thuế'),
                            style: TextStyle(fontSize: 14, height: 1),
                            controller: txtTaxNumber,
                          ),
                          TextField(
                            obscureText: false,
                            decoration: InputDecoration(labelText: 'Điện thoại'),
                            style: TextStyle(fontSize: 14, height: 1),
                            controller: txtPhone,
                          ),
                          TextField(
                            obscureText: false,
                            decoration: InputDecoration(labelText: 'Địa chỉ'),
                            style: TextStyle(fontSize: 14, height: 1),
                            controller: txtAddress,
                          ),
                          TextField(
                            readOnly: true,
                            obscureText: false,
                            maxLines: 2,
                            autofocus: false,
                            controller: txtProvince,
                            decoration: InputDecoration(
                                labelText: 'Khu vực',
                                suffixIcon: Icon(
                                  stringIsEmptyOrNull(txtProvince.text) ? Icons.arrow_forward_ios
                                  : Icons.clear,
                                  size: 20,
                                )),
                            style: TextStyle(fontSize: 14, height: 1),
                            onTap: ()
                            {
                              if (stringIsEmptyOrNull(txtProvince.text)) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            ListProvince(onSelectedArea),fullscreenDialog: true));
                              } else {
                                setState(() {
                                  txtProvince.clear();
                                });
                              }

                            },
                          ),
                          TextField(
                            obscureText: false,
                            decoration: InputDecoration(labelText: 'Email'),
                            style: TextStyle(fontSize: 14, height: 1),
                            controller: txtEmail,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 44,
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 16, right: 16),
                      color: Colors.white,
                      child: TextField(
                        obscureText: false,
                        decoration: InputDecoration(labelText: 'Nhập ghi chú'),
                        style: TextStyle(fontSize: 14, height: 1),
                        controller: txtDescription,
                      ),
                    ),
                    SizedBox(
                      height: 44,
                    ),
                  ],
                ),
              ));
        },
      ),
    );
  }

  void onSelectedGroup(CustomerGroup p1) {
    print('==== CUSTOMER GROUP :${p1.toJson()}');
    txtCustomerGroup.text = p1.name ?? '';
    requestModel.customer_group_id = '${p1.id}';
  }

  void onSelectedArea(String areaString) {
    setState(() {
      print('AREA STRING: $areaString');
      txtProvince.text = areaString;
    });
    // requestModel.state = p1.name ?? '';
  }

  void _uploadAvatarFirst() async {
    if(stringIsEmptyOrNull(txtName.text)) {
      showToastFailed('Bạn chưa nhập tên khách hàng');
      return;
    } else {
      if (cubit.uploadImgModel?.cdnImage == '' || b64Img != '') {
        await loadingDialog.show();
        await cubit.uploadAvatarCustomer(b64Img);
      } else {
        _saveCustomer();
      }
    }

  }

  void _saveCustomer() async {
    requestModel.email = txtEmail.text;
    requestModel.description = txtDescription.text;
    requestModel.mobile = txtPhone.text;
    requestModel.tax_number = txtTaxNumber.text;
    requestModel.type = 'customer';
    requestModel.address = txtAddress.text + '\n${txtProvince.text}';
    requestModel.name = txtName.text;

    print('==== ${requestModel.toJson()}');
    loadingDialog.show();
    cubit.createNewCustomer(requestModel);

    // final response =
    // await APIService().addNewCustomer(requestModel).catchError((e) {});
    // setState(() {
    //   Navigator.pop(context);
    // });
  }


  Future getImage() async {
    final pickerFile = await picker.getImage(source: ImageSource.gallery, imageQuality: 20);
    setState(() async {
      if (pickerFile != null) {
        _image = File(pickerFile.path);
        var bytes = await pickerFile.readAsBytes();
        b64Img = base64.encode(bytes);
        print('BASE64 IMG: $b64Img');
        setState(() {});
      } else {
        print('No image selected.');
      }
    });
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(1900, 1),
        lastDate: DateTime.now());
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
        String formattedDate = DateFormat('dd-MM-yyyy').format(selectedDate);
        txtBirthday.text = formattedDate;
        requestModel.dateOfBirth = formattedDate;
      });
  }
}

class InfoCustomer extends StatelessWidget {
  const InfoCustomer({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 16, right: 16),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(
                labelText: 'Chọn giói tính',
                suffixIcon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                )),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {},
          ),
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(labelText: 'Ngày sinh'),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {},
          ),
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(
                labelText: 'Nhóm khách hàng',
                suffixIcon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                )),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {},
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Mã số thuế'),
            style: TextStyle(fontSize: 14, height: 1),
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Điện thoại'),
            style: TextStyle(fontSize: 14, height: 1),
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Địa chỉ'),
            style: TextStyle(fontSize: 14, height: 1),
          ),
          TextField(
            readOnly: true,
            obscureText: false,
            decoration: InputDecoration(
                labelText: 'Khu vực',
                suffixIcon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                )),
            style: TextStyle(fontSize: 14, height: 1),
            onTap: () => {},
          ),
          TextField(
            obscureText: false,
            decoration: InputDecoration(labelText: 'Email'),
            style: TextStyle(fontSize: 14, height: 1),
          ),
        ],
      ),
    );
  }
}
