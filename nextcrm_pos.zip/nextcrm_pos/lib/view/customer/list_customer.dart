import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/hide_keyboard.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/ProgressIndicator.dart';
import 'package:vidifi/view/common/search_bar.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

import 'new_customer.dart';

class ListCustomer extends StatefulWidget {
  final void Function(Customer) onSelected;

  ListCustomer(this.onSelected);

  @override
  _ListCustomer createState() => _ListCustomer(this.onSelected);
}

class _ListCustomer extends State<ListCustomer> {
  var _onSelected;

  _ListCustomer(this._onSelected);

  static int page = 0;
  bool isLoading = false;
  ScrollController _sc = new ScrollController();
  List<Customer> customers = [];
  List<Customer> rawArray = [];
  RefreshController _refreshController = RefreshController();
  TextEditingController _cSearch = TextEditingController();
  bool enableLoadMore = true;
  late ProfileCubit profileCubit;

  @override
  void initState() {
    this._getListCustomer(page);
    profileCubit = context.read<ProfileCubit>();
    super.initState();
    _sc.addListener(() {
      if (_sc.position.pixels == _sc.position.maxScrollExtent) {
        _getListCustomer(page);
      }
    });
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        hideKeyboard(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('Chọn khách hàng', style: TextStyle(color: Colors.white, fontSize: 16)),
          backgroundColor: Colors.green,
          actions: [
            IconButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => NewCustomer(), fullscreenDialog: true));
                },
                icon: Icon(
                  Icons.add,
                  color: Colors.white,
                ))
          ],
        ),
        backgroundColor: greyColor2,
        body: Container(
          child: Column(
            children: [
              Container(
                color: Colors.white,
                child: Row(
                  children: [
                    Expanded(
                        child: SearchBarCommon(
                          controller: _cSearch,
                          maxLength: 20,
                          hintText: 'Tên, mã, sđt, email, công ty',
                          textChanged: (text) {
                            print('CHANGED TEXT: $text');
                            // setState(() {
                            //
                            // });
                            _filter(text);
                          },
                          isDelayed: false,
                        )),
                    IconButton(
                        onPressed: () {
                          // scanBarcodeNormal();
                          showToastFailed('Testing');
                        },
                        icon: Icon(
                          Icons.qr_code,
                          color: Colors.black,
                          size: 24,
                        ))
                  ],
                ),
              ),
              Expanded(
                child: SmartRefresher(
                    controller: _refreshController,
                    onRefresh: () async {
                      _getListCustomer(1);
                    },
                    footer: CustomFooter(
                      loadStyle: LoadStyle.ShowWhenLoading,
                      builder: (ctx, loadStatus) {
                        return loadStatus == LoadStatus.loading
                            ? Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: CupertinoActivityIndicator(),
                        )
                            : Container();
                      },
                    ),
                    enablePullUp: enableLoadMore,
                    child: _buildListCustomer()),
              ),
            ],
          ),
        ),
        resizeToAvoidBottomInset: false,
      ),
    );
  }

  void _getListCustomer(int page) async {
    setState(() {
      isLoading = true;
    });
    final response = await APIService().fetchCustomers(page).catchError((e) {});
    setState(() {

      enableLoadMore = response.meta?.pagination?.currentPage != response.meta?.pagination?.totalPages;
      if (mounted) {
        _refreshController.refreshCompleted();
        _refreshController.loadComplete();
      }
      isLoading = false;
      if (page == 1) {
        customers.clear();
      }
      customers.addAll(response.data);
      rawArray = customers;
      print('CUSTOMER LENGTH: ${customers.length}');
      page++;
    });
  }

  Widget _buildListCustomer() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: customers.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        if (index == customers.length) {
          return buildProgressIndicator(isLoading);
        } else {
          var customer = customers[index];
          return Container(
            child: TextButton(
              child: Row(
                children: <Widget>[
                  customer.landmark.isEmpty
                      ? CircleAvatar(
                          child: Text(
                            customer.text.characters.first.toUpperCase(),
                            style: TextStyle(fontSize: 32, color: Colors.white),
                          ),
                          backgroundColor: Colors.blue,
                        )
                      : Image.network(
                          customer.landmark,
                          fit: BoxFit.cover,
                          width: 50.0,
                          height: 50.0,
                          loadingBuilder: (BuildContext context, Widget child,
                              ImageChunkEvent? loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Container(
                              width: 24,
                              height: 24,
                              child: Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: primaryColor,
                                  value: loadingProgress.expectedTotalBytes != null &&
                                          loadingProgress.expectedTotalBytes != null
                                      ? loadingProgress.cumulativeBytesLoaded /
                                          loadingProgress.expectedTotalBytes!
                                      : null,
                                ),
                              ),
                            );
                          },
                        ),
                  Flexible(
                      child:
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            customer.text,
                            maxLines: 2,
                            style: TextStyle(
                                color: primaryColor, fontSize: 14, fontWeight: FontWeight.normal),
                            textAlign: TextAlign.start,
                          ),
                          SizedBox(
                            height: 6,
                          ),
                          Text(
                            customer.contactId,
                            maxLines: 1,
                            style: TextStyle(
                              color: primaryColor,
                              fontSize: 10,
                            ),
                            textAlign: TextAlign.left,
                          ),
                          SizedBox(
                            height: 6,
                          ),
                          SizedBox(
                            height: 16,
                            child: FlatButton.icon(
                                padding: const EdgeInsets.only(left: 0),
                                label: Text(
                                  customer.mobile.isEmpty ? 'Chưa cập nhật' : customer.mobile,
                                  maxLines: 1,
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 12,
                                  ),
                                ),
                                icon: const Icon(
                                  Icons.phone,
                                  size: 12,
                                ),
                                onPressed: () {}),
                          ),
                        ],
                      ),
                    ),
                  ]))
                ],
              ),
              onPressed: () {
                profileCubit.updateCustomer(customer);
                this._onSelected(customer);
                Navigator.pop(context);
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                shape: MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                )),
              ),
            ),
            margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
          );
        }
      },
      controller: _sc,
    );
  }

  void _filter(String text) {
    text = text.trim().toLowerCase();
    if(stringIsEmptyOrNull(text)) {
      setState(() {
        customers = rawArray;
      });
      return;
    }
    List<Customer> _searchedList = [];
    print('LENGTH RAW: ${rawArray.length}');
    if (text.length > 0) {
      rawArray.forEach((element) {
        if (element.text.toLowerCase().contains(text) ||
            (element.contactId).toLowerCase().contains(text)
        || (element.mobile).toLowerCase().contains(text)) {
          print('ELEMENT SEARCH :${element.toJson()}');
          _searchedList.add(element);
        }
      });
    }
    print('LENGTH FILTER: ${_searchedList.length}');

    setState(() {
      if (_searchedList.length > 0) customers = _searchedList;
    });
  }
}
