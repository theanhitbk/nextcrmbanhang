import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/handle_logout.dart';

import '../login.dart';
import 'components/customer_group.dart';
import 'new_customer.dart';

class ListCustomerGroup extends StatefulWidget {
  final void Function(CustomerGroup) onSelectedGroup;
  ListCustomerGroup(this.onSelectedGroup);
  @override
  _ListCustomerGroup createState() => _ListCustomerGroup(this.onSelectedGroup);
}

class _ListCustomerGroup extends State<ListCustomerGroup> {
  List<CustomerGroup> customerGroups = [];
  var _onSelectedGroup;
  _ListCustomerGroup(this._onSelectedGroup);
  @override
  void initState() {
    this._getListCustomer();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chọn khách hàng',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => NewCustomer(),
                        fullscreenDialog: true));
              },
              icon: Icon(
                Icons.add,
                color: Colors.white,
              ))
        ],
      ),
      backgroundColor: greyColor2,
      body: Padding(
        padding: EdgeInsets.all(4),
        child: Container(
          child: _buildListCustomer(),
        ),
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  void _getListCustomer() async {
    final response = await APIService().fetchCustomerGroup().catchError((e) {
      // this.showAlertDialog(context);
    });
    setState(() {
      customerGroups.addAll(response.data);
    });
  }

  Widget _buildListCustomer() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: customerGroups.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        return CustomerGroupCard(customerGroup: customerGroups[index], onSelected: (customerGroup ) { 
          _onSelectedGroup(customerGroup);
          Navigator.pop(context);
         },);
      },
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
