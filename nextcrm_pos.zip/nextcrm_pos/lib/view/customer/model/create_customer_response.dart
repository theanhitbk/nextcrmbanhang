// To parse this JSON data, do
//
//     final createCustomerResponse = createCustomerResponseFromJson(jsonString);

import 'dart:convert';

import 'package:vidifi/model/Meta.dart';

CreateCustomerResponse createCustomerResponseFromJson(dynamic str) => CreateCustomerResponse.fromJson(str);

String createCustomerResponseToJson(CreateCustomerResponse data) => json.encode(data.toJson());

class CreateCustomerResponse {
  CreateCustomerResponse({
    this.data,
    this.meta,
  });

  Data? data;
  Meta? meta;

  CreateCustomerResponse copyWith({
    Data? data,
    Meta? meta,
  }) =>
      CreateCustomerResponse(
        data: data ?? this.data,
        meta: meta ?? this.meta,
      );

  factory CreateCustomerResponse.fromJson(Map<String, dynamic> json) => CreateCustomerResponse(
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    meta: json["meta"] == null ? null : Meta.fromJson(json["meta"]),
  );

  Map<String, dynamic> toJson() => {
    "data": data == null ? null : data?.toJson(),
    "meta": meta == null ? null : meta?.toJson(),
  };
}

class Data {
  Data({
    this.id,
    this.name,
    this.type,
    this.supplierBusinessName,
    this.email,
    this.contactId,
    this.taxNumber,
    this.city,
    this.state,
    this.country,
    this.landmark,
    this.mobile,
    this.landline,
    this.alternateNumber,
    this.payTermNumber,
    this.payTermType,
    this.createdBy,
    this.isDefault,
    this.creditLimit,
    this.customerGroupId,
    this.customField1,
    this.customField2,
    this.customField3,
    this.customField4,
    this.totalRp,
    this.totalRpUsed,
    this.totalRpExpired,
    this.documentsAndnote,
    this.modelName,
    this.address,
    this.description,
    this.avatar,
    this.customerGroup,
    this.employeeId,
    this.employee,
    this.subject,
    this.provinceId,
    this.districtId,
    this.wardId,
    this.province,
    this.district,
    this.ward,
  });

  int? id;
  String? name;
  String? type;
  String? supplierBusinessName;
  String? email;
  String? contactId;
  String? taxNumber;
  dynamic city;
  dynamic state;
  dynamic country;
  dynamic landmark;
  String? mobile;
  dynamic landline;
  dynamic alternateNumber;
  dynamic payTermNumber;
  dynamic payTermType;
  dynamic createdBy;
  dynamic isDefault;
  dynamic creditLimit;
  String? customerGroupId;
  dynamic customField1;
  dynamic customField2;
  dynamic customField3;
  dynamic customField4;
  dynamic totalRp;
  dynamic totalRpUsed;
  dynamic totalRpExpired;
  List<String>? documentsAndnote;
  String? modelName;
  String? address;
  String? description;
  dynamic avatar;
  CustomerGroup? customerGroup;
  dynamic employeeId;
  dynamic employee;
  dynamic subject;
  dynamic provinceId;
  dynamic districtId;
  dynamic wardId;
  dynamic province;
  dynamic district;
  dynamic ward;

  Data copyWith({
    int? id,
    String? name,
    String? type,
    String? supplierBusinessName,
    String? email,
    String? contactId,
    String? taxNumber,
    dynamic city,
    dynamic state,
    dynamic country,
    dynamic landmark,
    String? mobile,
    dynamic landline,
    dynamic alternateNumber,
    dynamic payTermNumber,
    dynamic payTermType,
    dynamic createdBy,
    dynamic isDefault,
    dynamic creditLimit,
    String? customerGroupId,
    dynamic customField1,
    dynamic customField2,
    dynamic customField3,
    dynamic customField4,
    dynamic totalRp,
    dynamic totalRpUsed,
    dynamic totalRpExpired,
    List<String>? documentsAndnote,
    String? modelName,
    String? address,
    String? description,
    dynamic avatar,
    CustomerGroup? customerGroup,
    dynamic employeeId,
    dynamic employee,
    dynamic subject,
    dynamic provinceId,
    dynamic districtId,
    dynamic wardId,
    dynamic province,
    dynamic district,
    dynamic ward,
  }) =>
      Data(
        id: id ?? this.id,
        name: name ?? this.name,
        type: type ?? this.type,
        supplierBusinessName: supplierBusinessName ?? this.supplierBusinessName,
        email: email ?? this.email,
        contactId: contactId ?? this.contactId,
        taxNumber: taxNumber ?? this.taxNumber,
        city: city ?? this.city,
        state: state ?? this.state,
        country: country ?? this.country,
        landmark: landmark ?? this.landmark,
        mobile: mobile ?? this.mobile,
        landline: landline ?? this.landline,
        alternateNumber: alternateNumber ?? this.alternateNumber,
        payTermNumber: payTermNumber ?? this.payTermNumber,
        payTermType: payTermType ?? this.payTermType,
        createdBy: createdBy ?? this.createdBy,
        isDefault: isDefault ?? this.isDefault,
        creditLimit: creditLimit ?? this.creditLimit,
        customerGroupId: customerGroupId ?? this.customerGroupId,
        customField1: customField1 ?? this.customField1,
        customField2: customField2 ?? this.customField2,
        customField3: customField3 ?? this.customField3,
        customField4: customField4 ?? this.customField4,
        totalRp: totalRp ?? this.totalRp,
        totalRpUsed: totalRpUsed ?? this.totalRpUsed,
        totalRpExpired: totalRpExpired ?? this.totalRpExpired,
        documentsAndnote: documentsAndnote ?? this.documentsAndnote,
        modelName: modelName ?? this.modelName,
        address: address ?? this.address,
        description: description ?? this.description,
        avatar: avatar ?? this.avatar,
        customerGroup: customerGroup ?? this.customerGroup,
        employeeId: employeeId ?? this.employeeId,
        employee: employee ?? this.employee,
        subject: subject ?? this.subject,
        provinceId: provinceId ?? this.provinceId,
        districtId: districtId ?? this.districtId,
        wardId: wardId ?? this.wardId,
        province: province ?? this.province,
        district: district ?? this.district,
        ward: ward ?? this.ward,
      );

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"] == null ? null : json["id"],
    name: json["name"] == null ? null : json["name"],
    type: json["type"] == null ? null : json["type"],
    supplierBusinessName: json["supplier_business_name"] == null ? null : json["supplier_business_name"],
    email: json["email"] == null ? null : json["email"],
    contactId: json["contact_id"] == null ? null : json["contact_id"],
    taxNumber: json["tax_number"] == null ? null : json["tax_number"],
    city: json["city"],
    state: json["state"],
    country: json["country"],
    landmark: json["landmark"],
    mobile: json["mobile"] == null ? null : json["mobile"],
    landline: json["landline"],
    alternateNumber: json["alternate_number"],
    payTermNumber: json["pay_term_number"],
    payTermType: json["pay_term_type"],
    createdBy: json["created_by"],
    isDefault: json["is_default"],
    creditLimit: json["credit_limit"],
    customerGroupId: json["customer_group_id"] == null ? null : json["customer_group_id"],
    customField1: json["custom_field1"],
    customField2: json["custom_field2"],
    customField3: json["custom_field3"],
    customField4: json["custom_field4"],
    totalRp: json["total_rp"],
    totalRpUsed: json["total_rp_used"],
    totalRpExpired: json["total_rp_expired"],
    documentsAndnote: json["documentsAndnote"] == null ? null : List<String>.from(json["documentsAndnote"].map((x) => x)),
    modelName: json["model_name"] == null ? null : json["model_name"],
    address: json["address"] == null ? null : json["address"],
    description: json["description"] == null ? null : json["description"],
    avatar: json["avatar"],
    customerGroup: json["customer_group"] == null ? null : CustomerGroup.fromJson(json["customer_group"]),
    employeeId: json["employee_id"],
    employee: json["employee"],
    subject: json["subject"],
    provinceId: json["province_id"],
    districtId: json["district_id"],
    wardId: json["ward_id"],
    province: json["province"],
    district: json["district"],
    ward: json["ward"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
    "type": type == null ? null : type,
    "supplier_business_name": supplierBusinessName == null ? null : supplierBusinessName,
    "email": email == null ? null : email,
    "contact_id": contactId == null ? null : contactId,
    "tax_number": taxNumber == null ? null : taxNumber,
    "city": city,
    "state": state,
    "country": country,
    "landmark": landmark,
    "mobile": mobile == null ? null : mobile,
    "landline": landline,
    "alternate_number": alternateNumber,
    "pay_term_number": payTermNumber,
    "pay_term_type": payTermType,
    "created_by": createdBy,
    "is_default": isDefault,
    "credit_limit": creditLimit,
    "customer_group_id": customerGroupId == null ? null : customerGroupId,
    "custom_field1": customField1,
    "custom_field2": customField2,
    "custom_field3": customField3,
    "custom_field4": customField4,
    "total_rp": totalRp,
    "total_rp_used": totalRpUsed,
    "total_rp_expired": totalRpExpired,
    "documentsAndnote": documentsAndnote == null ? null : (List<dynamic>.from(documentsAndnote!.map((x) => x))),
    "model_name": modelName == null ? null : modelName,
    "address": address == null ? null : address,
    "description": description == null ? null : description,
    "avatar": avatar,
    "customer_group": customerGroup == null ? null : customerGroup?.toJson(),
    "employee_id": employeeId,
    "employee": employee,
    "subject": subject,
    "province_id": provinceId,
    "district_id": districtId,
    "ward_id": wardId,
    "province": province,
    "district": district,
    "ward": ward,
  };
}

class CustomerGroup {
  CustomerGroup({
    this.id,
    this.name,
    this.amount,
    this.description,
  });

  int? id;
  String? name;
  int? amount;
  String? description;

  CustomerGroup copyWith({
    int? id,
    String? name,
    int? amount,
    String? description,
  }) =>
      CustomerGroup(
        id: id ?? this.id,
        name: name ?? this.name,
        amount: amount ?? this.amount,
        description: description ?? this.description,
      );

  factory CustomerGroup.fromJson(Map<String, dynamic> json) => CustomerGroup(
    id: json["id"] == null ? null : json["id"],
    name: json["name"] == null ? null : json["name"],
    amount: json["amount"] == null ? null : json["amount"],
    description: json["description"] == null ? null : json["description"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
    "amount": amount == null ? null : amount,
    "description": description == null ? null : description,
  };
}

