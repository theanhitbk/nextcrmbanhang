import 'package:after_layout/after_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Province.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/dialog_utils.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/area_address/area_response.dart';
import 'package:vidifi/view/common/area_address/get_area_cubit.dart';
import 'package:vidifi/view/customer/components/province_cell.dart';

import 'new_customer.dart';

class ListProvince extends StatefulWidget {
  final void Function(String) onSelectedArea;

  ListProvince(this.onSelectedArea);

  @override
  _ListProvince createState() => _ListProvince(this.onSelectedArea);
}

class _ListProvince extends State<ListProvince> with AfterLayoutMixin{
  List<Province> provinces = [];
  List<Area> areas = [];
  int level = 0;
  int idArea = 0;
  String areaString = '';
  var _onSelectedProvince;

  _ListProvince(this._onSelectedProvince);

  late LoadingDialog loadingDialog;
  GetAreaCubit cubit = GetAreaCubit();

  @override
  void initState() {
    // this._getListProvince();
    loadingDialog = LoadingDialog(context);
    super.initState();
  }

  @override
  void afterFirstLayout(BuildContext context) {
    getListArea();
  }

  void getListArea() {
    loadingDialog.show();
    cubit.getAreaWithLevel(idArea);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => cubit,
      child: BlocConsumer<GetAreaCubit, GetAreaState>(
        listener: (context, state) {
          if (state is GetListAreaSuccess) {
            areas = state.listArea;
            level = state.level;
            loadingDialog.dismiss();
            print('GET AREA SUCCESS $level');
          }
          if (state is GetListAreaFailed) {
            loadingDialog.dismiss();
            showToastFailed(state.reasonFailed);
          }
        },
        builder: (context, state) {
          return Scaffold(
            appBar: AppBar(
              title: Text('Chọn khu vực',
                  style: TextStyle(color: Colors.white, fontSize: 16)),
              backgroundColor: Colors.green,
              leading: IconButton(onPressed: () {
                if (level > 1) {
                  cubit.updateAreaList(level);
                } else {
                  Navigator.of(context).pop();
                }

              }, icon: Icon(Icons.arrow_back_ios, color: Colors.white,),),
              actions: [
                IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      // Navigator.push(
                      //     context,
                      //     MaterialPageRoute(
                      //         builder: (context) => NewCustomer(),
                      //         fullscreenDialog: true));
                    },
                    icon: Icon(
                      Icons.close,
                      color: Colors.white,
                    ))
              ],
            ),
            backgroundColor: greyColor2,
            body: Padding(
              padding: EdgeInsets.all(4),
              child: Container(
                child: _buildListCustomer(),
              ),
            ),
            resizeToAvoidBottomInset: false,
          );
        },
      ),
    );
  }

  void _getListProvince() async {
    final response = await APIService().fetchProvince().catchError((e) {});
    setState(() {
      provinces.addAll(response.data);
    });
  }

  Widget _buildListCustomer() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: areas.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        return ProvinceCell(area: areas[index], onSelected: (area) {
          // _onSelectedProvince(province);
          // Navigator.pop(context);
          print('AREA ${area.name}');
          handleSelectArea(area);
        },);
      },
    );
  }

  void handleSelectArea(Area area) {
    idArea = area.id!;

    if (level == 1) {
      // areaString =
      cubit.province = area;
      getListArea();
    } else if (level == 2) {
      cubit.district = area;
      getListArea();
    } else {
      cubit.ward = area;
      areaString = (cubit.ward?.name ?? '') + ' - ' +
          (cubit.district?.name ?? '') + ' - ' +
          (cubit.province?.name ?? '');
      widget.onSelectedArea(areaString);
      Navigator.pop(context);
    }

  }

}
