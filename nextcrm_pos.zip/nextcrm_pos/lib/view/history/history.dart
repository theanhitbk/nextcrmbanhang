import 'package:after_layout/after_layout.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/search_bar.dart';
import 'package:vidifi/view/history/history_cubit.dart';
import 'package:vidifi/view/history/history_response_obj.dart';

import '../login.dart';

class HistoryPage extends StatefulWidget {
  @override
  _HistoryPage createState() => _HistoryPage();
}

class _HistoryPage extends State<HistoryPage> with AfterLayoutMixin {
  static int page = 1;
  ScrollController _sc = new ScrollController();
  TextEditingController _cSearch = TextEditingController();
  bool isLoading = false;
  RefreshController _refreshController = RefreshController();

  List<HistoryObj> histories = [];
  List<HistoryObj> rawArray = [];
  bool enableLoadMore = true;

  HistoryCubit cubit = HistoryCubit();

  @override
  void afterFirstLayout(BuildContext context) {
    print('GET HISTORY');
    cubit.getHistoryData(page);
  }

  @override
  void initState() {
    // page = 1;
    super.initState();
    // _sc.addListener(() {
    //   if (_sc.position.pixels == _sc.position.maxScrollExtent) {
    //     _getMoreData(page);
    //   }
    // });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => cubit,
      child: BlocConsumer<HistoryCubit, HistoryState>(
        listener: (context, state) {
          if(state is GetHistoryDataSuccess) {
            histories = state.histories;
            rawArray = histories;
            enableLoadMore = (state.pagination.currentPage! < state.pagination.totalPages!);
            print('PAGE: $page');
            if (mounted) {
              _refreshController.refreshCompleted();
              _refreshController.loadComplete();
            }
            if (enableLoadMore) page++;
          }
        },
        builder: (context, state) {
          return Scaffold(
            appBar: AppBar(
              title: Text(
                'Lịch sử đơn hàng',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
              backgroundColor: Colors.green,
            ),
            backgroundColor: greyColor2,
            body: Column(
              children: [
                Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                          child: SearchBarCommon(
                        controller: _cSearch,
                        hintText: 'Mã, tên KH, công ty',
                        textChanged: (text) {
                          print('CHANGED TEXT: $text');
                          setState(() {});
                          _filter(text);
                        },
                        isDelayed: false,
                      )),
                      InkWell(
                        onTap: () {
                          showBottomSheetFilter();
                        },
                        child: Container(
                          // color: Colors.white,
                          padding: EdgeInsets.all(8),
                          child: Row(
                            children: [Text(filterArr[selected]), Icon(Icons.arrow_drop_down)],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(
                  height: 1,
                ),
                Expanded(
                    child: SmartRefresher(
                        controller: _refreshController,
                        onRefresh: () async {
                          // _getListCustomer(1);
                          page = 1;
                          cubit.getHistoryData(page);
                          if (mounted) {
                            _refreshController.refreshCompleted();
                          }
                        },
                        onLoading: () {
                          cubit.getHistoryData(page);
                        },
                        footer: CustomFooter(
                          loadStyle: LoadStyle.ShowWhenLoading,
                          builder: (ctx, loadStatus) {
                            return loadStatus == LoadStatus.loading
                                ? Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: CupertinoActivityIndicator(),
                            )
                                : Container();
                          },
                        ),
                        enablePullUp: enableLoadMore,
                        child: _buildList())),
              ],
            ),
            resizeToAvoidBottomInset: false,
          );
        },
      ),
    );
  }

  Widget _buildList() {
    return ListView.separated(
      shrinkWrap: true,
      physics: BouncingScrollPhysics(),
      itemCount: histories.length,
      // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        return buildHistoryItem(histories[index], index);
        // return _buildProgressIndicator();
        // if (index == news.length) {
        //   return _buildProgressIndicator();
        // } else {
        //   return NewsCard(news: news[index]);
        // }
      },
      controller: _sc,
      separatorBuilder: (BuildContext context, int index) {
        return Divider(
          height: 4,
        );
      },
    );
  }

  List<String> filterArr = ['Đặt hàng', 'Hóa đơn', 'Phiếu thu', 'Trả hàng'];
  int selected = 0;

  void showBottomSheetFilter() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        // shape: RoundedRectangleBorder(
        //     borderRadius: BorderRadius.only(topRight: Radius.circular(10), topLeft: Radius.circular(10))),
        builder: (BuildContext context) {
          return Wrap(
            alignment: WrapAlignment.center,
            children: [
              Container(
                width: 34,
                height: 4,
                margin: EdgeInsets.only(bottom: 4),
                decoration: BoxDecoration(
                  color: Color(0xffD2D1D1),
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              Container(
                padding: EdgeInsets.only(
                    left: 16, right: 16, bottom: MediaQuery.of(context).padding.bottom),
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Color(0xffF4F6FA),
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(16), topLeft: Radius.circular(16)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListView.separated(
                      padding: EdgeInsets.only(top: 8),
                      itemBuilder: (BuildContext context, index) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                            if (selected == index) return;
                            selected = index;
                            _cSearch.text = '';
                            _filterFromType();
                          },
                          child: Container(
                            color: Colors.transparent,
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Center(
                                  child: Text(filterArr[index],
                                      style: TextStyle(
                                          color: index == selected ? Colors.red : Colors.blue,
                                          fontSize: 14))),
                            ),
                          ),
                        );
                      },
                      itemCount: filterArr.length,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      separatorBuilder: (BuildContext context, int index) {
                        return Divider(
                          height: 1,
                        );
                      },
                    ),
                    Divider(
                      height: 4,
                    ),
                    GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                            padding: EdgeInsets.all(8),
                            color: Colors.transparent,
                            child: Center(
                              child: Text(
                                'Đóng',
                                style: TextStyle(
                                    color: Colors.red, fontWeight: FontWeight.bold, fontSize: 14),
                              ),
                            ))),
                  ],
                ),
              )
            ],
          );
        });
  }

  Widget buildHistoryItem(HistoryObj history, int ind) {
    return Column(
      children: [
        Visibility(
          child: Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(top: 10, bottom: 4, left: 16),
                child: Text(
                    _getHeaderLabel(history.transactionDate ?? '')),
              )),
          visible: _getVisibleDateLabel(history, index: ind),
        ),
        Container(
          color: Colors.white,
          child: TextButton(
            onPressed: () {},
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.monetization_on_outlined,
                  color: Colors.blue,
                ),
                SizedBox(
                  width: 8,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        convertToCurrency(history.finalTotal ?? 0),
                        style:
                            TextStyle(color: Colors.green, fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 4,
                      ),
                      Text(
                        history.customerName ?? "N/A",
                        style: TextStyle(color: primaryColor),
                      ),
                      Text((history.invoiceNo ?? '') + '. ' + formatDateTime(history.transactionDate ?? ''), style: TextStyle(color: primaryColor)),
                    ],
                  ),
                ),
                Text(
                  getTimeFromString(history.transactionDate ?? ''),
                  style: TextStyle(color: primaryColor, fontSize: 14),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  String _getHeaderLabel(String time) {
    return getTodayLabel(time) + getDateFromString(time);
  }

  _getVisibleDateLabel(HistoryObj? history, {required int index}) {
    if (index == 0) return true;
    bool isVisible = (getDateFromString(history?.transactionDate ?? '') !=
        getDateFromString(histories[index -1].transactionDate ?? ''));
    return isVisible;
  }

  void _getMoreData(int index) async {
    if (!isLoading) {
      setState(() {
        isLoading = true;
      });

      setState(() {
        isLoading = false;

        page++;
      });
    }
  }

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  void _filterFromType() {
    String filterKey = '';
    switch (selected) {
      case 0:
        filterKey = 'sell_quotation';
        break;
      case 1:
        filterKey = 'sell_order';
        break;
      case 2:
        filterKey = '';
        break;
      case 3:
        filterKey = 'sell_return';
        break;
    }
    List<HistoryObj> _filterArr = [];
    rawArray.forEach((element) {
      if (element.subType == filterKey) {
        _filterArr.add(element);
      }
    });
    print('LENGTH FILTER: ${_filterArr.length}');
    setState(() {
      if (_filterArr.length > 0) histories = _filterArr;
    });
  }

  void _filter(String text) {
    text = text.trim().toLowerCase();
    if (stringIsEmptyOrNull(text)) {
      setState(() {
        histories = rawArray;
      });
      return;
    }
    List<HistoryObj> _filterArr = [];
    if (text.length > 0) {
      rawArray.forEach((element) {
        if ((element.invoiceNo ?? '').contains(text)
        || (element.customerName ?? '').contains(text)
            ||(element.invoiceNo ?? '').contains(text)) {
          _filterArr.add(element);
        }
      });
    }
    print('LENGTH FILTER: ${_filterArr.length}');
    setState(() {
      if (_filterArr.length > 0) histories = _filterArr;
    });
  }
}
