part of 'history_cubit.dart';

@immutable
abstract class HistoryState {}

class HistoryInitial extends HistoryState {}

class GetHistoryDataSuccess extends HistoryState {
  final List<HistoryObj> histories;
  final Pagination pagination;
  GetHistoryDataSuccess(this.histories, this.pagination);
}

class GetHistoryDataFailed extends HistoryState {
  GetHistoryDataFailed();
}