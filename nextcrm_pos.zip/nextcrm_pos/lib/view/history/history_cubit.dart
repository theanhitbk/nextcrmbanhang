import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/history/history_response_obj.dart';

import 'history_repo.dart';

part 'history_state.dart';

class HistoryCubit extends Cubit<HistoryState> {
  HistoryCubit() : super(HistoryInitial());

  HistoryRepo repo = HistoryRepo();
  HistoryResponse? historyResponse;
  List<HistoryObj> array = [];
  Future<void> getHistoryData(int page) async {
    try{
      print('CUBIT GET HISTORY');
      historyResponse = await repo.getHistory(page);
      if (historyResponse?.statusCode == null) {
        if (historyResponse?.meta?.statusCode == 0) {
          if (page == 1) {
            array = historyResponse?.data ?? [];
          } else {
            array.addAll(historyResponse?.data ?? []);
          }
          emit(GetHistoryDataSuccess(array, historyResponse?.meta?.pagination ?? Pagination()));
        } else {
          emit(GetHistoryDataFailed());
        }
      } else {
        print('EXPIRED');
        if (historyResponse?.statusCode == 401) {
          showAlertTokenExpired();
        }
      }
    }catch (e) {
      print('ERROR: $e');
    }

  }

}
