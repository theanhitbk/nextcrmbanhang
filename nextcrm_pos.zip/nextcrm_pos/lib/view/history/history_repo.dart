import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:vidifi/services/api_const.dart';
import 'package:vidifi/services/api_request.dart';
import 'package:vidifi/view/history/history_response_obj.dart';

class HistoryRepo {

  Future<HistoryResponse> getHistory(int page) async {
    String url = '/api/mobile/transaction-history';
    final response = await BaseRequestAPI().sendRequest(url, RequestMethod.GET, queryParams: {
      "page":page,
      "pageLimit":15,
    });
    return await compute(historyResponseFromJson, response);
  }

}