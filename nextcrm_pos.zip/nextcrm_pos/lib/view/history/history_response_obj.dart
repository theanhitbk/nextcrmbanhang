import 'dart:convert';

HistoryResponse historyResponseFromJson(dynamic str) => HistoryResponse.fromJson(str);

String historyResponseToJson(HistoryResponse data) => json.encode(data.toJson());


class HistoryResponse {
  int? statusCode;
  List<HistoryObj>? data;
  Meta? meta;
  int? recordsTotal;
  int? recordsFiltered;
  Request? request;

  HistoryResponse(
      {this.data,
        this.statusCode,
        this.meta,
        this.recordsTotal,
        this.recordsFiltered,
        this.request});

  HistoryResponse.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <HistoryObj>[];
      json['data'].forEach((v) {
        data!.add(new HistoryObj.fromJson(v));
      });
    }
    statusCode = json['status_code'] != null ? json['status_code'] : null;
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    recordsTotal = json['recordsTotal'];
    recordsFiltered = json['recordsFiltered'];
    request =
    json['request'] != null ? new Request.fromJson(json['request']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    if (this.meta != null) {
      data['meta'] = this.meta!.toJson();
    }
    data['recordsTotal'] = this.recordsTotal;
    data['recordsFiltered'] = this.recordsFiltered;
    if (this.request != null) {
      data['request'] = this.request!.toJson();
    }
    return data;
  }
}

class HistoryObj {
  int? id;
  String? transactionDate;
  String? createdAt;
  String? updatedAt;
  int? isDirectSale;
  String? invoiceNo;
  int? customerId;
  String? customerName;
  String? customerMobile;
  String? customerAddress;
  String? customerDescription;
  String? paymentStatus;
  int? finalTotal;
  int? taxAmount;
  int? discountAmount;
  String? discountType;
  String? totalBeforeTax;
  String? typesOfServiceId;
  String? shippingStatus;
  // Null? payTermNumber;
  // Null? payTermType;
  String? additionalNotes;
  // Null? staffNote;
  String? shippingDetails;
  // Null? estimatedDeliveryDate;
  String? shippingCharges;
  String? addedBy;
  int? totalPaid;
  String? branchName;
  // Null? returnExists;
  int? returnPaid;
  int? amountReturn;
  String? returnTransactionId;
  int? totalItems;
  String? paymentMethods;
  String? status;
  Source? source;
  SalesPerson? salesPerson;
  List<Tag>? tags;
  String? modelName;
  String? type;
  String? subType;

  HistoryObj(
      {this.id,
        this.transactionDate,
        this.createdAt,
        this.updatedAt,
        this.isDirectSale,
        this.invoiceNo,
        this.customerId,
        this.customerName,
        this.customerMobile,
        this.customerAddress,
        this.customerDescription,
        this.paymentStatus,
        this.finalTotal,
        this.taxAmount,
        this.discountAmount,
        this.discountType,
        this.totalBeforeTax,
        this.typesOfServiceId,
        this.shippingStatus,
        // this.payTermNumber,
        // this.payTermType,
        this.additionalNotes,
        // this.staffNote,
        this.shippingDetails,
        // this.estimatedDeliveryDate,
        this.shippingCharges,
        this.addedBy,
        this.totalPaid,
        this.branchName,
        // this.returnExists,
        this.returnPaid,
        this.amountReturn,
        this.returnTransactionId,
        this.totalItems,
        this.paymentMethods,
        this.status,
        this.source,
        this.salesPerson,
        this.tags,
        this.modelName,
        this.type,
        this.subType});

  HistoryObj.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    transactionDate = json['transaction_date'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    isDirectSale = json['is_direct_sale'];
    invoiceNo = json['invoice_no'];
    customerId = json['customer_id'];
    customerName = json['customer_name'];
    customerMobile = json['customer_mobile'];
    customerAddress = json['customer_address'];
    customerDescription = json['customer_description'];
    paymentStatus = json['payment_status'];
    finalTotal = json['final_total'];
    taxAmount = json['tax_amount'];
    discountAmount = json['discount_amount'];
    discountType = json['discount_type'];
    totalBeforeTax = json['total_before_tax'];
    typesOfServiceId = json['types_of_service_id'];
    shippingStatus = json['shipping_status'];
    // payTermNumber = json['pay_term_number'];
    // payTermType = json['pay_term_type'];
    additionalNotes = json['additional_notes'];
    // staffNote = json['staff_note'];
    shippingDetails = json['shipping_details'];
    // estimatedDeliveryDate = json['estimated_delivery_date'];
    shippingCharges = json['shipping_charges'];
    addedBy = json['added_by'];
    totalPaid = json['total_paid'];
    branchName = json['branch_name'];
    // returnExists = json['return_exists'];
    returnPaid = json['return_paid'];
    amountReturn = json['amount_return'];
    returnTransactionId = json['return_transaction_id'];
    totalItems = json['total_items'];
    paymentMethods = json['payment_methods'];
    status = json['status'];
    source =
    json['source'] != null ? new Source.fromJson(json['source']) : null;
    salesPerson = json['sales_person'] != null
        ? new SalesPerson.fromJson(json['sales_person'])
        : null;
    if (json['tags'] != null) {
      tags = <Tag>[];
      json['tags'].forEach((v) {
        tags!.add(new Tag.fromJson(v));
      });
    }
    modelName = json['model_name'];
    type = json['type'];
    subType = json['sub_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['transaction_date'] = this.transactionDate;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['is_direct_sale'] = this.isDirectSale;
    data['invoice_no'] = this.invoiceNo;
    data['customer_id'] = this.customerId;
    data['customer_name'] = this.customerName;
    data['customer_mobile'] = this.customerMobile;
    data['customer_address'] = this.customerAddress;
    data['customer_description'] = this.customerDescription;
    data['payment_status'] = this.paymentStatus;
    data['final_total'] = this.finalTotal;
    data['tax_amount'] = this.taxAmount;
    data['discount_amount'] = this.discountAmount;
    data['discount_type'] = this.discountType;
    data['total_before_tax'] = this.totalBeforeTax;
    data['types_of_service_id'] = this.typesOfServiceId;
    data['shipping_status'] = this.shippingStatus;
    // data['pay_term_number'] = this.payTermNumber;
    // data['pay_term_type'] = this.payTermType;
    data['additional_notes'] = this.additionalNotes;
    // data['staff_note'] = this.staffNote;
    data['shipping_details'] = this.shippingDetails;
    // data['estimated_delivery_date'] = this.estimatedDeliveryDate;
    data['shipping_charges'] = this.shippingCharges;
    data['added_by'] = this.addedBy;
    data['total_paid'] = this.totalPaid;
    data['branch_name'] = this.branchName;
    // data['return_exists'] = this.returnExists;
    data['return_paid'] = this.returnPaid;
    data['amount_return'] = this.amountReturn;
    data['return_transaction_id'] = this.returnTransactionId;
    data['total_items'] = this.totalItems;
    data['payment_methods'] = this.paymentMethods;
    data['status'] = this.status;
    if (this.source != null) {
      data['source'] = this.source!.toJson();
    }
    if (this.salesPerson != null) {
      data['sales_person'] = this.salesPerson!.toJson();
    }
    // if (this.tags != null || this.tags != []) {
    //   data['tags'] = this.tags!.map((v) => v?.toJson()).toList();
    // }
    data['model_name'] = this.modelName;
    data['type'] = this.type;
    data['sub_type'] = this.subType;
    return data;
  }
}

class Source {
  int? id;
  String? name;
  String? picture;

  Source({this.id, this.name, this.picture});

  Source.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    picture = json['picture'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['picture'] = this.picture;
    return data;
  }
}

class SalesPerson {
  int? id;
  String? name;
  String? firstname;
  String? lastname;

  SalesPerson({this.id, this.name, this.firstname, this.lastname});

  SalesPerson.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    firstname = json['firstname'];
    lastname = json['lastname'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    return data;
  }
}

class Meta {
  Pagination? pagination;
  Summation? summation;
  int? statusCode;
  String? message;

  Meta({this.pagination, this.summation, this.statusCode, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    pagination = json['pagination'] != null
        ? new Pagination.fromJson(json['pagination'])
        : null;
    summation = json['summation'] != null
        ? new Summation.fromJson(json['summation'])
        : null;
    statusCode = json['status_code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.pagination != null) {
      data['pagination'] = this.pagination!.toJson();
    }
    if (this.summation != null) {
      data['summation'] = this.summation!.toJson();
    }
    data['status_code'] = this.statusCode;
    data['message'] = this.message;
    return data;
  }
}

class Pagination {
  int? total;
  int? count;
  int? perPage;
  int? currentPage;
  int? totalPages;
  Links? links;

  Pagination(
      {this.total,
        this.count,
        this.perPage,
        this.currentPage,
        this.totalPages,
        this.links});

  Pagination.fromJson(Map<String, dynamic> json) {
    total = json['total'];
    count = json['count'];
    perPage = json['per_page'];
    currentPage = json['current_page'];
    totalPages = json['total_pages'];
    links = json['links'] != null ? new Links.fromJson(json['links']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['total'] = this.total;
    data['count'] = this.count;
    data['per_page'] = this.perPage;
    data['current_page'] = this.currentPage;
    data['total_pages'] = this.totalPages;
    if (this.links != null) {
      data['links'] = this.links!.toJson();
    }
    return data;
  }
}

class Links {
  String? next;

  Links({this.next});

  Links.fromJson(Map<String, dynamic> json) {
    next = json['next'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['next'] = this.next;
    return data;
  }
}

class Summation {
  double? finalTotal;
  double? totalPaid;

  Summation({this.finalTotal, this.totalPaid});

  Summation.fromJson(Map<String, dynamic> json) {
    finalTotal = json['final_total'];
    totalPaid = json['total_paid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['final_total'] = this.finalTotal;
    data['total_paid'] = this.totalPaid;
    return data;
  }
}

class Request {
  String? tenantcode;
  String? username;
  String? password;
  String? appType;
  String? pageLimit;
  String? page;

  Request(
      {this.tenantcode,
        this.username,
        this.password,
        this.appType,
        this.pageLimit,
        this.page});

  Request.fromJson(Map<String, dynamic> json) {
    tenantcode = json['tenantcode'];
    username = json['username'];
    password = json['password'];
    appType = json['app_type'];
    pageLimit = json['pageLimit'];
    page = json['page'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['tenantcode'] = this.tenantcode;
    data['username'] = this.username;
    data['password'] = this.password;
    data['app_type'] = this.appType;
    data['pageLimit'] = this.pageLimit;
    data['page'] = this.page;
    return data;
  }
}

class Tag {
  String? name;
  String? color;
  int? order;
  int? id;
  int? tagItemsId;

  Tag({this.name, this.color, this.order, this.id, this.tagItemsId});

  Tag.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    color = json['color'];
    order = json['order'];
    id = json['id'];
    tagItemsId = json['tag_items_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['color'] = this.color;
    data['order'] = this.order;
    data['id'] = this.id;
    data['tag_items_id'] = this.tagItemsId;
    return data;
  }
}