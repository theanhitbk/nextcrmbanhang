import 'package:flutter/material.dart';
class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(4),
      child: ListView.builder(
        itemCount: 0,
        itemBuilder: (context, index) => 
        Padding(
        padding: EdgeInsets.symmetric(vertical: 0),
        )
      ),
    );
  }
}
