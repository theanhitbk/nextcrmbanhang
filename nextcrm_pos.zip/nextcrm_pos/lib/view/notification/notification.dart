import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';

class NotificationPage extends StatefulWidget {
  @override
  _NotificationPage createState() => _NotificationPage();
}

class _NotificationPage extends State<NotificationPage> {
  static int page = 1;
  ScrollController _sc = new ScrollController();
  bool isLoading = false;
  @override
  void initState() {
    page = 1;
    // this._getMoreData(page);
    super.initState();
    _sc.addListener(() {
      if (_sc.position.pixels == _sc.position.maxScrollExtent) {
        _getMoreData(page);
      }
    });
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Vidifi'),
      ),
      backgroundColor: greyColor2,
      body: Padding(
        padding: EdgeInsets.all(4),
        child: Container(
          child: _buildList(),
        ),
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  Widget _buildList() {
    return ListView.builder(
      itemCount: 1, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        return _buildProgressIndicator();
        // if (index == news.length) {
        //   return _buildProgressIndicator();
        // } else {
        //   return NewsCard(news: news[index]);
        // }
      },
      controller: _sc,
    );
  }

  void _getMoreData(int index) async {
    if (!isLoading) {
      setState(() {
        isLoading = true;
      });
      // final response = await APIService().fetchNews(page).catchError((e) {
      //   this.showAlertDialog(context);
      // });
      setState(() {
        isLoading = false;
        page++;
      });
    }
  }

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  void _removeToken() async {
      final prefs = await SharedPreferences.getInstance();
      prefs.remove('token');
    }
}
