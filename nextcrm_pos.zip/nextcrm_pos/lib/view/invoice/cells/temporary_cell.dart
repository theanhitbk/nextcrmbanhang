import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/home/invoice.dart';

class TemporaryCell extends StatelessWidget {
  const TemporaryCell({
    Key? key,
    required this.product,
  }) : super(key: key);
  final ProductDetailData? product;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextButton(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Row(
            children: <Widget>[
              CircleAvatar(
                child: Icon(Icons.edit_rounded),
              ),
              SizedBox(width: 6,),
              Flexible(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          product?.name ?? '123',
                          maxLines: 2,
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: 14,
                              fontWeight: FontWeight.normal),
                          textAlign: TextAlign.start,
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        Text(
                          getTimeFromString(product?.date ?? ''),
                          maxLines: 1,
                          style: TextStyle(
                            color: Colors.green,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.left,
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          // convertToCurrency(double.parse(product.sellingPrice ?? '0.0').toInt()),
                          convertToCurrency(double.parse(product?.product?.defaultSellPrice ?? '0').toInt()),
                          maxLines: 1,
                          style: TextStyle(
                              color: Colors.green,
                              fontSize: 14,
                              fontWeight: FontWeight.normal),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        ///TODO Cần lưu thêm KH vào đơn tạm
                        Text(
                          'Khách lẻ',
                          maxLines: 5,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ]))
            ],
          ),
        ),
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => InvoiceScreen(product!, isTemporary: true,)));
        },
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          // shape: MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
          //   borderRadius: BorderRadius.all(Radius.circular(6)),
          // )),
        ),
      ),
      // margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }
}
