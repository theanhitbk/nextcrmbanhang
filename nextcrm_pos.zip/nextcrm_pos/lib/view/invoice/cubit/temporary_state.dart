part of 'temporary_cubit.dart';

@immutable
abstract class TemporaryState {}

class TemporaryInitial extends TemporaryState {}

class TemporaryFetchSuccess extends TemporaryState {
  final TemporaryInvoice temporaryInvoice;
  TemporaryFetchSuccess(this.temporaryInvoice);
}
