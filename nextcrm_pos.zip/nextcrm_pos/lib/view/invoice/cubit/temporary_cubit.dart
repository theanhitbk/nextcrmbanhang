import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/model/TemporaryInvoice.dart';
import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/view/common/temporary_invoice_manager.dart';

part 'temporary_state.dart';

class TemporaryCubit extends Cubit<TemporaryState> {
  TemporaryCubit() : super(TemporaryInitial());

  TemporaryInvoiceManager? _manager;
  TemporaryInvoice temporaryInvoice = TemporaryInvoice();

  Future<void> getTemporaryInvoiceData() async {
    Map<String, dynamic> json = await jsonDecode(HiveManager.getInstance()?.get('temporary_invoice') ?? '{}') ;
    if (json.isNotEmpty) {
      temporaryInvoice = TemporaryInvoice.fromJson(json);
    } else {
      temporaryInvoice.data = [];
    }
    emit(TemporaryFetchSuccess(temporaryInvoice));
  }

  Future<void> addTemporaryInvoice(ProductDetailData detail) async {
    temporaryInvoice.data?.insert(0,detail);
    saveTemporaryToLocal();
  }

  void saveTemporaryToLocal() async {
    await HiveManager.getInstance()?.put('temporary_invoice', jsonEncode(temporaryInvoice));
    emit(TemporaryFetchSuccess(temporaryInvoice));
  }

  TemporaryInvoice getTemporaryInvoice() {
    return temporaryInvoice;
  }

  void removeData() async {
    temporaryInvoice = new TemporaryInvoice();
    emit(TemporaryFetchSuccess(temporaryInvoice));
  }

}
