import 'package:after_layout/after_layout.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/model/TemporaryInvoice.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/temporary_invoice_manager.dart';
import 'package:vidifi/view/invoice/cells/temporary_cell.dart';
import 'package:vidifi/view/invoice/cubit/temporary_cubit.dart';

class TemporaryPage extends StatefulWidget {
  @override
  _TemporaryPage createState() => _TemporaryPage();
}

class _TemporaryPage extends State<TemporaryPage> with AfterLayoutMixin {
  late TemporaryCubit temporaryCubit;

  @override
  void initState() {
    temporaryCubit = context.read<TemporaryCubit>();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void afterFirstLayout(BuildContext context) {
    temporaryCubit.getTemporaryInvoiceData();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TemporaryCubit, TemporaryState>(
      listener: (context, state) {

      },
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Text(
              'Đơn tạm',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            backgroundColor: Colors.green,
          ),
          backgroundColor: greyColor2,
          body: Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Container(
              child: temporaryCubit.temporaryInvoice.data != null ? _buildList() : null,
            ),
          ),
          resizeToAvoidBottomInset: false,
        );
      },
    );
  }

  Widget _buildList() {
    // TemporaryInvoice? temporaryInvoice =
    // TemporaryInvoiceManager.getInstance()?.getTemporaryInvoice();
    return ListView.separated(
      shrinkWrap: true,
      physics: BouncingScrollPhysics(),
      itemCount: temporaryCubit.temporaryInvoice.data?.length ?? 0,
      // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        return Column(
          children: [
            Visibility(
              child: Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: EdgeInsets.only(top: 10, bottom: 4, left: 16),
                    child: Text(
                        _getHeaderLabel(temporaryCubit.temporaryInvoice.data?[index]?.date ?? '')),
                  )),
              visible: _getVisibleDateLabel(temporaryCubit.temporaryInvoice, index: index),
            ),
            Dismissible(
                onDismissed: (direction) {
                  temporaryCubit.temporaryInvoice.data?.removeAt(index);
                  temporaryCubit.saveTemporaryToLocal();
                  // TemporaryInvoiceManager
                  //     .getInstance()
                  //     ?.getTemporaryInvoice()
                  //     .data
                  //     ?.removeAt(index);
                  // TemporaryInvoiceManager.getInstance()?.saveTemporaryToLocal();
                  // setState(() {});
                },
                background: Container(
                  padding: EdgeInsets.only(right: 14.0),
                  alignment: AlignmentDirectional.centerEnd,
                  color: Colors.red,
                  child: Icon(
                    Icons.delete_forever,
                    color: Colors.white,
                  ),
                ),
                key: ObjectKey(temporaryCubit.temporaryInvoice.data?[index]),
                direction: DismissDirection.endToStart,
                resizeDuration: Duration(milliseconds: 200),
                child: TemporaryCell(product: temporaryCubit.temporaryInvoice.data?[index])),
          ],
        );
      }, separatorBuilder: (BuildContext context, int index) {
        return Divider(height: 1,);
    },
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  _getVisibleDateLabel(TemporaryInvoice? temporaryInvoice, {required int index}) {
    if (index == 0) return true;
    bool isVisible = (getDateFromString(temporaryInvoice?.data?[index - 1]?.date ?? '') !=
        getDateFromString(temporaryInvoice?.data?[index].date ?? ''));
    return isVisible;
  }

  String _getHeaderLabel(String time) {
    return getTodayLabel(time) + getDateFromString(time);
  }
}
