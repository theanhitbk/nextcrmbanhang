import 'package:flutter/material.dart';

class RegisterView extends StatefulWidget {
  _RegisterViewState createState() => _RegisterViewState();
}

class _RegisterViewState extends State<RegisterView> {
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Đăng ký'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding:
            const EdgeInsets.only(bottom: 0, left: 16, right: 16, top: 0),
            child: TextField(
              obscureText: false,
              decoration: InputDecoration(
                  border: OutlineInputBorder(), labelText: 'Tên đăng nhập'),
            ),
          ),
          SizedBox(
            height: 16,
          ),
          Padding(
            padding:
            const EdgeInsets.only(bottom: 0, left: 16, right: 16, top: 0),
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                  border: OutlineInputBorder(), labelText: 'Mật khẩu'),
            ),
          ),
          SizedBox(
            height: 16,
          ),
          Padding(
            padding:
            const EdgeInsets.only(bottom: 0, left: 16, right: 16, top: 0),
            child: TextField(
              obscureText: true,
              decoration: InputDecoration(
                  border: OutlineInputBorder(), labelText: 'Nhập lại mật khẩu'),
            ),
          ),
          TextButton.icon(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => RegisterView()));
              },
              icon: Icon(Icons.how_to_reg),
              label: Text('Đăng ký'))
        ],
      ),
    );
  }
}