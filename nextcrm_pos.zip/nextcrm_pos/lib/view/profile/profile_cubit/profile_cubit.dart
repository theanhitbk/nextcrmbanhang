import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/User.dart';
import 'package:vidifi/model/branch.dart';
import 'dart:convert';

import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/view/profile/default_config_response.dart';

import '../../../services/api_service.dart';

part 'profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit() : super(ProfileInitial());

  User currentUser = User();
  Branch? currentBranch;
  List<Price>? priceBooks;
  Price? selectedPrice;
  Customer? selectedCustomer;
  DefaultConfig? defaultConfig;

  Future<void> getDefaultConfig() async {
    final DefaultConfigResponse response = await APIService().fetchDefaultConfig().catchError((e) {});
    if (response.meta?.statusCode == 0) {
      defaultConfig = response.data;
      if (selectedCustomer == null) {
        selectedCustomer = defaultConfig?.customerDefault;
      }
      emit(FetchDefaultConfigSuccess());
    }
  }

  Future<void> getCurrentUser() async {
    Map<String, dynamic> json = await jsonDecode(HiveManager.getInstance()?.get('current_user') ?? '{}') ;
   print('START GET CURRENT USER $json');
    if (json.isNotEmpty) {
      currentUser = User.fromJson(json);
      print('NOT EMPTY');
    } else {
      print('EMPTY');
      final prefs = await SharedPreferences.getInstance();
      String userJson = prefs.getString('UserProfile') ?? '';
      currentUser = User.fromJson(jsonDecode(userJson));
      emit(FetchProfileSuccess(currentUser));
    }
    // getCurrentBranch();
    emit(FetchProfileSuccess(currentUser));
  }

  Future<void> saveProfileInfo(User user) async {
    currentUser = user;
    print('SAVE INFO CURRENT USER');
    await HiveManager.getInstance()?.put('current_user', jsonEncode(currentUser));
    emit(FetchProfileSuccess(currentUser));
  }

  Future<void> getCurrentBranch() async {
    Map<String, dynamic> json = await jsonDecode(HiveManager.getInstance()?.get('current_branch') ?? '{}') ;
    print('START GET CURRENT BRANCH $json');
    if (json.isNotEmpty) {
      currentBranch = Branch.fromJson(json);
    } else {
      currentBranch = currentUser.branches?.first ?? new Branch();
    }
    emit(UpdateCurrentBranchSuccess(currentBranch!));
  }

  Future<void> updateSelectedBranch(Branch branch) async {
    currentBranch = branch;
    await HiveManager.getInstance()?.put('current_branch', jsonEncode(currentBranch));
    emit(UpdateCurrentBranchSuccess(branch));
  }

  Future<void> getPriceBook() async {

    if (priceBooks == null) {
      final response = await APIService().fetchPrice().catchError((e) {});
      priceBooks = response.data;
      updatePriceBook(priceBooks!.first);
    }
    emit(GetPriceBook());
  }

  Future<void> updatePriceBook(Price price) async {
    selectedPrice = price;
    emit(UpdatePriceBook(price));
  }

  Future<void> updateCustomer(Customer customer) async {
    selectedCustomer = customer;
    emit(UpdateCustomerDefault(selectedCustomer!));
  }

}
