part of 'profile_cubit.dart';

@immutable
abstract class ProfileState {}

class ProfileInitial extends ProfileState {}

class FetchProfileSuccess extends ProfileState{
  final User user;
  FetchProfileSuccess(this.user);
}

class FetchDefaultConfigSuccess extends ProfileState {

}

class UpdateCurrentBranchSuccess extends ProfileState{
  final Branch branch;
  UpdateCurrentBranchSuccess(this.branch);
}

class GetPriceBook extends ProfileState {}
class GetCustomerDefault extends ProfileState {}

class UpdatePriceBook extends ProfileState {
  final Price price;

  UpdatePriceBook(this.price);
}

class UpdateCustomerDefault extends ProfileState {
  final Customer customer;

  UpdateCustomerDefault(this.customer);
}