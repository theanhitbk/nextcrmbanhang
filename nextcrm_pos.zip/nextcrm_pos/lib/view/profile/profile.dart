import 'package:flutter/material.dart';
import 'package:vidifi/model/User.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/util/handle_logout.dart';
import 'package:vidifi/view/login.dart';

class ProfilePage extends StatefulWidget {
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late User profile;
  @override
  void initState() {
    super.initState();
    this._getProfile();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Thông tin cá nhân'),
          actions: [
            IconButton(
              onPressed: () => {showAlertDialog(context)},
              icon: Icon(Icons.logout),
            )
          ],
        ),
        body: Container(
          padding: EdgeInsets.only(left: 16, top: 20, right: 16),
          child: ListView(
            children: [
              ProfileImage(),
              SizedBox(
                height: 30,
              ),
            ],
          ),
        ));
  }

  Widget buildTextField(
    String labelText,
    String placeHolder,
  ) {
    return Padding(
      padding: EdgeInsets.only(bottom: 30),
      child: TextField(
        readOnly: true,
        decoration: InputDecoration(
            contentPadding: EdgeInsets.only(bottom: 5),
            labelText: labelText,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            hintText: placeHolder,
            hintStyle: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
                color: Colors.grey)),
      ),
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("Hủy"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: Text("Đăng xuất"),
      onPressed: () {
        // _removeToken();
        RemoveTokenAndCached(context).remove();
        // Navigator.pushAndRemoveUntil(
        //     context,
        //     MaterialPageRoute(builder: (context) => LoginView()),
        //     (route) => false);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Đăng xuất"),
      content: Text("Bạn có muốn đăng xuất không?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void _removeToken() async {
    HiveManager.getInstance()?.clear();
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  void _getProfile() async {
    final response = await APIService().getProfile().catchError((e) {
      this.showAlertDialog(context);
    });
    setState(() {
      profile = response;
    });
  }
}

class ProfileImage extends StatelessWidget {
  const ProfileImage({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              border: Border.all(width: 2, color: Colors.white),
              boxShadow: [
                BoxShadow(
                    spreadRadius: 2,
                    blurRadius: 10,
                    color: Colors.black.withOpacity(0.1))
              ],
              shape: BoxShape.circle,
            ),
          ),
          Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(width: 2, color: Colors.white),
                    color: Colors.blue),
                child: Icon(
                  Icons.edit,
                  color: Colors.white,
                ),
              ))
        ],
      ),
    );
  }
}
