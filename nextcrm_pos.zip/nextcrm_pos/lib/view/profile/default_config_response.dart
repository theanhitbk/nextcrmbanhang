import 'package:vidifi/model/Customer.dart';

import '../../model/Meta.dart';

class DefaultConfigResponse {
  DefaultConfigResponse({
    required this.meta,
    required this.data,
  });

  final Meta? meta;
  final DefaultConfig? data;

  DefaultConfigResponse copyWith({
    Meta? meta,
    DefaultConfig? data,
  }) {
    return DefaultConfigResponse(
      meta: meta ?? this.meta,
      data: data ?? this.data,
    );
  }

  factory DefaultConfigResponse.fromJson(Map<String, dynamic> json){
    return DefaultConfigResponse(
      meta: json["meta"] == null ? null : Meta.fromJson(json["meta"]),
      data: json["data"] == null ? null : DefaultConfig.fromJson(json["data"]),
    );
  }

  @override
  String toString(){
    return '$meta, $data';
  }

}

class DefaultConfig {
  DefaultConfig({
    required this.id,
    required this.allowSellWhenOutStock,
    required this.allowEditPrice,
    required this.allowEditDiscount,
    required this.requireApprovedStatusPurchase,
    required this.useVoucher,
    required this.allowReturnInvoiceHasVoucher,
    required this.allowApplyVoucherWithPointPromotion,
    required this.tenantId,
    required this.useBatchExpire,
    required this.onProductExpiry,
    required this.stopSellingBefore,
    required this.accountingMethod,
    required this.discountBeforeTax,
    required this.customerDefault,
  });

  final int? id;
  final int? allowSellWhenOutStock;
  final int? allowEditPrice;
  final int? allowEditDiscount;
  final int? requireApprovedStatusPurchase;
  final int? useVoucher;
  final int? allowReturnInvoiceHasVoucher;
  final int? allowApplyVoucherWithPointPromotion;
  final int? tenantId;
  final int? useBatchExpire;
  final String? onProductExpiry;
  final int? stopSellingBefore;
  final String? accountingMethod;
  final int? discountBeforeTax;
  final Customer? customerDefault;

  DefaultConfig copyWith({
    int? id,
    int? allowSellWhenOutStock,
    int? allowEditPrice,
    int? allowEditDiscount,
    int? requireApprovedStatusPurchase,
    int? useVoucher,
    int? allowReturnInvoiceHasVoucher,
    int? allowApplyVoucherWithPointPromotion,
    int? tenantId,
    int? useBatchExpire,
    String? onProductExpiry,
    int? stopSellingBefore,
    String? accountingMethod,
    int? discountBeforeTax,
    Customer? customerDefault,
  }) {
    return DefaultConfig(
      id: id ?? this.id,
      allowSellWhenOutStock: allowSellWhenOutStock ?? this.allowSellWhenOutStock,
      allowEditPrice: allowEditPrice ?? this.allowEditPrice,
      allowEditDiscount: allowEditDiscount ?? this.allowEditDiscount,
      requireApprovedStatusPurchase: requireApprovedStatusPurchase ?? this.requireApprovedStatusPurchase,
      useVoucher: useVoucher ?? this.useVoucher,
      allowReturnInvoiceHasVoucher: allowReturnInvoiceHasVoucher ?? this.allowReturnInvoiceHasVoucher,
      allowApplyVoucherWithPointPromotion: allowApplyVoucherWithPointPromotion ?? this.allowApplyVoucherWithPointPromotion,
      tenantId: tenantId ?? this.tenantId,
      useBatchExpire: useBatchExpire ?? this.useBatchExpire,
      onProductExpiry: onProductExpiry ?? this.onProductExpiry,
      stopSellingBefore: stopSellingBefore ?? this.stopSellingBefore,
      accountingMethod: accountingMethod ?? this.accountingMethod,
      discountBeforeTax: discountBeforeTax ?? this.discountBeforeTax,
      customerDefault: customerDefault ?? this.customerDefault,
    );
  }

  factory DefaultConfig.fromJson(Map<String, dynamic> json){
    return DefaultConfig(
      id: json["id"],
      allowSellWhenOutStock: json["allow_sell_when_out_stock"],
      allowEditPrice: json["allow_edit_price"],
      allowEditDiscount: json["allow_edit_discount"],
      requireApprovedStatusPurchase: json["require_approved_status_purchase"],
      useVoucher: json["use_voucher"],
      allowReturnInvoiceHasVoucher: json["allow_return_invoice_has_voucher"],
      allowApplyVoucherWithPointPromotion: json["allow_apply_voucher_with_point_promotion"],
      tenantId: json["tenant_id"],
      useBatchExpire: json["use_batch_expire"],
      onProductExpiry: json["on_product_expiry"],
      stopSellingBefore: json["stop_selling_before"],
      accountingMethod: json["accounting_method"],
      discountBeforeTax: json["discount_before_tax"],
      customerDefault: json["customer_default"] == null ? null : Customer.fromJson(json["customer_default"]),
    );
  }

  @override
  String toString(){
    return '$id, $allowSellWhenOutStock, $allowEditPrice, $allowEditDiscount, $requireApprovedStatusPurchase, $useVoucher, $allowReturnInvoiceHasVoucher, $allowApplyVoucherWithPointPromotion, $tenantId, $useBatchExpire, $onProductExpiry, $stopSellingBefore, $accountingMethod, $discountBeforeTax, $customerDefault';
  }

}

// class CustomerDefault {
//   CustomerDefault({
//     required this.id,
//     required this.name,
//     required this.email,
//     required this.contactId,
//     required this.due,
//     required this.totalRp,
//   });
//
//   final int? id;
//   final String? name;
//   final String? email;
//   final String? contactId;
//   final int? due;
//   final int? totalRp;
//
//   CustomerDefault copyWith({
//     int? id,
//     String? name,
//     String? email,
//     String? contactId,
//     int? due,
//     int? totalRp,
//   }) {
//     return CustomerDefault(
//       id: id ?? this.id,
//       name: name ?? this.name,
//       email: email ?? this.email,
//       contactId: contactId ?? this.contactId,
//       due: due ?? this.due,
//       totalRp: totalRp ?? this.totalRp,
//     );
//   }
//
//   factory CustomerDefault.fromJson(Map<String, dynamic> json){
//     return CustomerDefault(
//       id: json["id"],
//       name: json["name"],
//       email: json["email"],
//       contactId: json["contact_id"],
//       due: json["due"],
//       totalRp: json["total_rp"],
//     );
//   }
//
//   @override
//   String toString(){
//     return '$id, $name, $email, $contactId, $due, $totalRp';
//   }
//
// }

