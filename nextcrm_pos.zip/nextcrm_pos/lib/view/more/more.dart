import 'package:after_layout/after_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Order.dart';
import 'package:vidifi/model/branch.dart';
import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/view/common/AlerDialog.dart';
import 'package:vidifi/util/handle_logout.dart';
import 'package:vidifi/view/customer/list_customer.dart';
import 'package:vidifi/view/more/refund_list.dart';
import 'package:vidifi/view/more/report.dart';
import 'package:vidifi/view/more/setting_appp.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

import 'order_list.dart';

class MorePage extends StatefulWidget {
  _MorePageState createState() => _MorePageState();
}

class _MorePageState extends State<MorePage> with AfterLayoutMixin {
  Branch dropdownValue = Branch();
  List<Branch> listBranch = [];

  late ProfileCubit profileCubit;
  Branch? _branchSelect;
  int indexOfBranch = 0;
  @override
  void afterFirstLayout(BuildContext context) {

    // var branches = profileCubit.currentUser.branches;
    // if (branches != null) {
    //   listBranch = branches;
    //   dropdownValue = (branchSelect == null ? branches.first : branchSelect)!;
    // }
  }

  @override
  void initState() {
    profileCubit = context.read<ProfileCubit>();
    // profileCubit.getCurrentUser();

    print('CURRENT BRANCH ${_branchSelect?.id}');
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ProfileCubit, ProfileState>(
        listener: (context, state) async {
          if (state is FetchProfileSuccess) {
            var branches = state.user.branches;
            if (branches != null) {
              _branchSelect = profileCubit.currentBranch;
              listBranch = branches;
              indexOfBranch = listBranch.indexWhere((element) => element.id == _branchSelect?.id);
              // profileCubit.updateSelectedBranch(listBranch.first);
              // dropdownValue = (_branchSelect == null ? branches.first : _branchSelect)!;
              // _branchSelect = profileCubit.currentBranch;
              // dropdownValue = (_branchSelect == null ? branches.first : _branchSelect)!;
            }
          }
        },
        builder: (context, state) {
          return Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.green,
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(profileCubit.currentUser.username ?? ''),
                  listBranch.length > 0 ? DropdownButton<Branch>(
                    value:
                    listBranch[indexOfBranch],
                    // (_branchSelect == null ? listBranch.first : _branchSelect),
                    isDense: true,
                    dropdownColor: Colors.blue,
                    borderRadius: BorderRadius.all(Radius.circular(8)),
                    icon: const Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.white,
                    ),
                    elevation: 8,
                    style: const TextStyle(color: Colors.white),
                    onChanged: (Branch? newValue) {
                      setState(() {
                        // dropdownValue = newValue!;
                        _branchSelect = newValue;
                        indexOfBranch = listBranch.indexOf(newValue!);
                        profileCubit.updateSelectedBranch(_branchSelect!);
                        // branchSelect = dropdownValue;
                      });
                    },
                    items: listBranch.map<DropdownMenuItem<Branch>>((Branch value) {
                      return DropdownMenuItem<Branch>(
                        value: value,
                        child: Text(value.name ?? ''),
                      );
                    }).toList(),
                  ) : Container()
                ],
              ),
              centerTitle: false,
              leading: new Padding(
                padding: const EdgeInsets.only(left: 12),
                child: CircleAvatar(
                  child: Image.network(
                    profileCubit.currentUser.picture ?? '',
                    width: 50.0,
                    height: 50.0,
                  ),
                  backgroundColor: Colors.blue,
                ),
              ),
            ),
            body: Container(
              child: ListView(
                children: <Widget>[
                  Card(
                    margin: EdgeInsets.all(1),
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Xử lý đặt hàng'),
                      leading: Icon(Icons.inbox, color: Colors.indigo),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.black87, size: 16),
                      onTap: () => {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => OrderList(orderSelected)),
                        )
                      },
                    ),
                  ),
                  Card(
                    margin: EdgeInsets.all(1),
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Trả hàng'),
                      leading: Icon(Icons.reply, color: Colors.indigo),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.black87, size: 16),
                      onTap: () => {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => RefundList()),
                        )
                      },
                    ),
                  ),
                  Card(
                    margin: EdgeInsets.all(1),
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Lập phiếu thu'),
                      leading: Icon(Icons.airplane_ticket, color: Colors.indigo),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.black87, size: 16),
                      onTap: () => {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ListCustomer(onSelectedCustomer)),
                        )
                      },
                    ),
                  ),
                  Card(
                    margin: EdgeInsets.all(1),
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Xem báo cáo cuối ngày'),
                      leading: Icon(Icons.bar_chart, color: Colors.indigo),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.black87, size: 16),
                      onTap: () => {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ReportScreen()),
                        )
                      },
                    ),
                  ),
                  SizedBox(
                    height: 24,
                  ),
                  Card(
                    margin: EdgeInsets.all(1),
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Cài đặt ứng dụng'),
                      leading: Icon(Icons.settings, color: Colors.indigo),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.black87, size: 16),
                      onTap: () => {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SettingApp()),
                        )
                      },
                    ),
                  ),
                  Card(
                    margin: EdgeInsets.all(1),
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Đăng xuất'),
                      leading: Icon(Icons.logout, color: Colors.indigo),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.black87,
                        size: 16,
                      ),
                      onTap: () => {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) => BaseAlertDialog(
                                title: 'Xác nhận',
                                content: 'Bạn có muốn đăng xuất không?',
                                yesOnPressed: () {
                                  // _removeToken();
                                  RemoveTokenAndCached(context).remove();
                                  // Navigator.pushAndRemoveUntil(
                                  //     context,
                                  //     MaterialPageRoute(
                                  //         builder: (context) => LoginView()),
                                  //     (route) => false);
                                },
                                noOnPressed: () {
                                  Navigator.pop(context);
                                }))
                      },
                    ),
                  ),
                  SizedBox(
                    height: 24,
                  ),
                  Card(
                    child: ListTile(
                      visualDensity: VisualDensity.compact,
                      title: Text('Phiên bản'),
                      leading: Icon(Icons.new_releases, color: Colors.indigo),
                      trailing: Text('1.0.2'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
  }

  void _removeToken() async {
    HiveManager.getInstance()?.clear();
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  void orderSelected(Order p1) {}

  void onSelectedCustomer(Customer p1) {}
}
