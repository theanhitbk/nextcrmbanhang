import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vidifi/model/Order.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/ProgressIndicator.dart';
import 'package:vidifi/view/common/search_bar.dart';

import 'cells/order_card.dart';

class OrderList extends StatefulWidget {
  final void Function(Order) onSelected;

  OrderList(this.onSelected);

  @override
  _OrderList createState() => _OrderList(this.onSelected);
}

class _OrderList extends State<OrderList> {
  var _onSelected;

  _OrderList(this._onSelected);

  static int page = 0;
  ScrollController _scProduct = new ScrollController();
  bool isLoadingProduct = false;
  bool enableLoadMore = false;
  final _cSearch = TextEditingController();
  RefreshController _refreshController = RefreshController();
  List<Order> orders = [];
  List<Order> rawArray = [];

  @override
  void initState() {
    page = 0;
    this._getMoreOrder(page);
    super.initState();
    _scProduct.addListener(() {
      if (_scProduct.position.pixels == _scProduct.position.maxScrollExtent) {
        _getMoreOrder(page);
      }
    });
  }

  @override
  void dispose() {
    _scProduct.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Chọn đơn đặt hàng',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        backgroundColor: Colors.green,
      ),
      backgroundColor: greyColor2,
      body: Column(
        children: [
          Container(
            color: Colors.white,
            child: SearchBarCommon(
              controller: _cSearch,
              maxLength: 20,
              hintText: 'Tìm đơn đặt hàng',
              textChanged: (text) {
                print('CHANGED TEXT: $text');
                _filter(text);
              },
              isDelayed: false,
            ),
          ),
          SizedBox(
            height: 16,
          ),
          Expanded(
              child: SmartRefresher(
                  controller: _refreshController,
                  onRefresh: () async {
                    _getMoreOrder(1);
                  },
                  onLoading: () {
                    _getMoreOrder(page);
                  },
                  footer: CustomFooter(
                    loadStyle: LoadStyle.ShowWhenLoading,
                    builder: (ctx, loadStatus) {
                      return loadStatus == LoadStatus.loading
                          ? Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: CupertinoActivityIndicator(),
                            )
                          : Container();
                    },
                  ),
                  enablePullUp: enableLoadMore,
                  child: _buildListOrder())),
        ],
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  Widget _buildListOrder() {
    return Container(
      color: Colors.white,
      child: ListView.separated(
        separatorBuilder: (BuildContext context, int index) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Divider(
              height: 1,
            ),
          );
        },
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        itemCount: orders.length, // Add one more item for progress indicator
        itemBuilder: (BuildContext context, int index) {
          // if (index == orders.length) {
          //   return buildProgressIndicator(isLoadingProduct);
          // } else {
          return OrderCard(order: orders[index]);
          // }
        },
        // controller: _scProduct,
      ),
    );
  }

  void _getMoreOrder(int index) async {
    if (!isLoadingProduct) {
      setState(() {
        isLoadingProduct = true;
      });
      final response = await APIService().fetchOrders(index).catchError((e) {});
      setState(() {
        isLoadingProduct = false;
        enableLoadMore = response.meta?.pagination?.currentPage !=
            response.meta?.pagination?.totalPages;
        if (index == 1) {
          orders.clear();
        }
        if (mounted) {
          _refreshController.refreshCompleted();
          _refreshController.loadComplete();
        }
        orders.addAll(response.data!);
        rawArray = orders;
        page++;
      });
    }
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  void _filter(String text) {
    text = text.trim().toLowerCase();
    if (stringIsEmptyOrNull(text)) {
      setState(() {
        orders = rawArray;
      });
      return;
    }
    List<Order> _searchedList = [];
    print('LENGTH RAW: ${rawArray.length}');
    if (text.length > 0) {
      rawArray.forEach((element) {
        if ((element.customerName ?? '').toLowerCase().contains(text) ||
            (element.invoiceNo ?? '').toLowerCase().contains(text)) {
          print('ELEMENT SEARCH :${element.toJson()}');
          _searchedList.add(element);
        }
      });
    }
    print('LENGTH FILTER: ${_searchedList.length}');

    setState(() {
      if (_searchedList.length > 0) orders = _searchedList;
    });
  }
}
