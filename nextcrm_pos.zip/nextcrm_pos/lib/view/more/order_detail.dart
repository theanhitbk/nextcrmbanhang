import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Order.dart';
import 'package:vidifi/services/api_service.dart';

import '../login.dart';

class OrderDetail extends StatefulWidget {
  final Order order;

  OrderDetail(this.order);

  @override
  _OrderDetail createState() => _OrderDetail(this.order);
}

class _OrderDetail extends State<OrderDetail> {
  var _order;

  _OrderDetail(this._order);

  bool isLoading = false;
  int quantityGoods = 1;

  TextEditingController discountController = new TextEditingController();
  TextEditingController otherIncomeController = new TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.green,
        appBar: AppBar(
          title: Text(
            _order.invoiceNo,
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
          centerTitle: true,
          actions: [
            IconButton(
                onPressed: () => {},
                icon: Icon(
                  Icons.save,
                  color: Colors.white,
                )),
            // IconButton(onPressed: () => {

            // }, icon: Icon(Icons.add, color: Colors.white,))
          ],
          backgroundColor: Colors.green,
        ),
        body: ListView(
          padding: EdgeInsets.only(top: 10),
          children: [
            buildHeader(),
            buildGoods(),
            buildPaymentInfo(),
            Container(
              color: greyColor2,
              padding: const EdgeInsets.all(10),
              child: Text(''),
            ),
            Divider(
              height: 1,
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  SizedBox(width: 6,),
                  Text('Phuong thuc thanh toán'),
                  Spacer(),
                  Text(_order.paymentMethods),
                  IconButton(
                      onPressed: () => {},
                      icon: Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                      ))
                ],
              ),
            ),
            Container(
              color: greyColor2,
              padding: const EdgeInsets.all(10),
              child: Text(''),
            ),
            Divider(
              height: 1,
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  SizedBox(width: 6,),
                  Text('Tính vào công nợ'),
                  Spacer(),
                  Text(_order.totalBeforeTax),
                ],
              ),
            ),
            Container(
              color: greyColor2,
              padding: const EdgeInsets.all(10),
              child: Text(''),
            ),
            Divider(
              height: 1,
            ),
            Padding(padding: const EdgeInsets.all(10), child: TextField()),
          ],
        ),
        persistentFooterButtons: [
          ButtonTheme(
              height: 50,
              minWidth: MediaQuery.of(context).size.width,
              // ignore: deprecated_member_use
              child: RaisedButton(
                onPressed: () =>
                    {Navigator.of(context).pushNamedAndRemoveUntil('/', ModalRoute.withName('/'))},
                child: Text('Tạo hoá đơn'),
                color: Colors.green,
                textColor: Colors.white,
              ))
        ]);
  }

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  buildHeader() {
    return Container(
      padding: EdgeInsets.only(left: 16),
      child: new Column(
        children: [
          Row(
            children: [
              Icon(Icons.person),
              SizedBox(
                width: 6,
              ),
              Text(_order.addedBy),
              Spacer(),
              Text('${_order.totalPaid}'),
              SizedBox(
                width: 8,
              )
            ],
          ),
          Divider(
            height: 1,
          ),
          Row(
            children: [
              Icon(Icons.sticky_note_2),
              SizedBox(
                width: 6,
              ),
              Text('Bảng giá chung'),
              Spacer(),
              IconButton(
                  onPressed: () => {},
                  icon: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                  ))
            ],
          ),
          Divider(
            height: 1,
          ),
          Row(
            children: [
              Icon(Icons.motorcycle),
              SizedBox(
                width: 6,
              ),
              Text('Giao hang'),
              Spacer(),
              IconButton(
                  onPressed: () => {},
                  icon: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                  ))
            ],
          ),
          Divider(
            height: 1,
          ),
          Row(
            children: [
              Icon(Icons.sell),
              SizedBox(
                width: 6,
              ),
              Text('Bán trực tiếp'),
              Spacer(),
              IconButton(
                  onPressed: () => {},
                  icon: Icon(
                    Icons.arrow_forward_ios,
                    size: 16,
                  ))
            ],
          ),
          Divider(
            height: 1,
          ),
        ],
      ),
    );
  }

  buildGoods() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          color: greyColor2,
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text('Hàng hoá'),
        ),
        Divider(
          height: 1,
        ),
        ListView.separated(
          separatorBuilder: (BuildContext context, int index) {
            return Divider(
              height: 1,
            );
          },
          shrinkWrap: true,
          physics: BouncingScrollPhysics(),
          itemCount: quantityGoods,
          itemBuilder: (BuildContext context, int index) {
            return Padding(
              padding: const EdgeInsets.only(left: 16, right: 8, top: 10, bottom: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    child: Text(_order.branchName),
                    width: double.infinity,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    children: [
                      Text(
                        '20,000',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      Spacer(),
                      Container(
                        height: 30,
                        child: IconButton(
                            splashColor: Colors.transparent,
                            onPressed: () {
                              setState(() {
                                // if (quantity == 1) return;
                                // quantity -= 1;
                              });
                            },
                            icon: Icon(Icons.remove_outlined, size: 20, color: Colors.green
                                // quantity == 1
                                //     ? Colors.grey
                                //     : Colors.green,
                                )),
                      ),
                      Container(
                          // color: Colors.green,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(4)),
                              color: Colors.grey[50],
                              border: Border.all(color: Color(0xffD2D1D1), width: 1)),
                          // color: Colors.grey[50],
                          width: 44,
                          height: 25,
                          child: Center(
                              child: Text(
                            '1',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ))),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          '/ 1',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                      Container(
                        height: 30,
                        child: IconButton(
                            splashColor: Colors.transparent,
                            onPressed: () {
                              setState(() {
                                // quantity += 1;
                              });
                            },
                            icon: Icon(
                              Icons.add,
                              size: 20,
                              color: Colors.green,
                            )),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
        Divider(
          height: 1,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16, right: 8, top: 8, bottom: 8),
          child: GestureDetector(
            onTap: () {
              print('Add Goods');
              setState(() {
                quantityGoods += 1;
              });
            },
            child: Row(
              children: [
                Icon(
                  Icons.add,
                  color: Colors.green,
                ),
                Text(
                  'Thêm hàng hoá',
                  style: TextStyle(color: Colors.green),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  buildPaymentInfo() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Divider(
          height: 1,
        ),
        Container(
          color: greyColor2,
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          child: Text('Thanh toán'),
        ),
        Divider(
          height: 1,
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Text('Tổng tiền hàng'),
              SizedBox(width: 4,),
              Container(
                child: Text('1'),
                padding: EdgeInsets.all(4),
                decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(2)),
                    border: Border.all(width: 1, color: Colors.grey)),
              ),
              Spacer(),
              Text('20,000', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),),
            ],
          ),
        ),
        Divider(
          height: 1,
        ),
        Row(
          children: [
            SizedBox(
              width: 16,
            ),
            Text('Giảm giá'),
            Spacer(),
            SizedBox(
              width: 8,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Container(
                width: 100,
                height: 28,
                decoration: BoxDecoration(color: Color(0xffE6E8E9),
                    border: Border.all(color: Colors.grey, width: 1,),
                    borderRadius: BorderRadius.all(Radius.circular(2))),
                child: TextField(
                  obscureText: false,
                  autofocus: false,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(hintText: '0', border: InputBorder.none),
                  style: TextStyle(fontSize: 14, height: 1),
                  textAlign: TextAlign.right,
                  controller: discountController,
                  onChanged: (value) {
                    // _unitController.text = value;
                    // isEnableCreate = value.length > 0;
                    // widget.unitBase.name = value;
                  },
                ),
              ),
            ),
            SizedBox(
              width: 8,
            ),
          ],
        ),
        Divider(
          height: 1,
        ),
        Row(
          children: [
            SizedBox(
              width: 16,
            ),
            Text('Thu khác'),
            Spacer(),
            SizedBox(
              width: 8,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Container(
                width: 100,
                height: 28,
                decoration: BoxDecoration(color: Color(0xffE6E8E9),
                    border: Border.all(color: Colors.grey, width: 1,),
                    borderRadius: BorderRadius.all(Radius.circular(2))),
                child: TextField(
                  obscureText: false,
                  autofocus: false,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(hintText: '0', border: InputBorder.none),
                  style: TextStyle(fontSize: 14, height: 1),
                  textAlign: TextAlign.right,
                  controller: otherIncomeController,
                  onChanged: (value) {
                    // _unitController.text = value;
                    // isEnableCreate = value.length > 0;
                    // widget.unitBase.name = value;
                  },
                ),
              ),
            ),
            SizedBox(
              width: 8,
            ),
          ],
        ),
        Divider(
          height: 1,
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              SizedBox(width: 6,),
              Text('Khách cần trả'),
              Spacer(),
              Text('20,000', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),),
            ],
          ),
        ),
        Divider(
          height: 1,
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              SizedBox(width: 6,),
              Text('Khách thanh toán'),
              Spacer(),
              Text('20,000', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),),
            ],
          ),
        ),
      ],
    );
  }
}
