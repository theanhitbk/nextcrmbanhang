import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Order.dart';
import 'package:vidifi/model/Product.dart';

import '../order_detail.dart';

class OrderCard extends StatelessWidget {
  const OrderCard({
    Key? key,
    required this.order,
  }) : super(key: key);
  final Order order;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.yellow,
      child: TextButton(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  order.invoiceNo ?? '',
                  maxLines: 2,
                  style: TextStyle(
                      color: primaryColor,
                      fontSize: 14,
                      fontWeight: FontWeight.normal),
                  textAlign: TextAlign.start,
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  order.addedBy ?? '',
                  maxLines: 1,
                  style: TextStyle(
                    color: Colors.green,
                    fontSize: 12,
                  ),
                  textAlign: TextAlign.left,
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  order.transactionDate ?? '',
                  maxLines: 1,
                  style: TextStyle(
                      color: primaryColor,
                      fontSize: 14,
                      fontWeight: FontWeight.normal),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  '${order.finalTotal}',
                  maxLines: 5,
                  style: TextStyle(
                    color: Colors.green,
                    fontSize: 14,
                  ),
                ),
                SizedBox(
                  height: 6,
                ),
                Text(
                  order.status ?? '',
                  maxLines: 1,
                  style: TextStyle(
                      color: primaryColor,
                      fontSize: 12,
                      fontWeight: FontWeight.normal),
                ),

              ],
            ),
          ]),
        ),
        onPressed: () {
          Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => OrderDetail(this.order)));
        },
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          // shape:
          //     MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
          //   borderRadius: BorderRadius.all(Radius.circular(6)),
          // )),
        ),
      ),
      // margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }
}
