import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Refund.dart';
import 'package:vidifi/view/customer/list_customer.dart';

import '../refund.dart';

class RefundCard extends StatelessWidget {
  const RefundCard({
    Key? key,
    required this.refund,
  }) : super(key: key);
  final Refund refund;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextButton(
        child: Row(
          children: <Widget>[
            Flexible(
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        refund.invoiceNo ?? '',
                        maxLines: 2,
                        style: TextStyle(
                            color: primaryColor,
                            fontSize: 14,
                            fontWeight: FontWeight.normal),
                        textAlign: TextAlign.start,
                      ),
                      SizedBox(
                        height: 6,
                      ),
                      Text(
                        refund.addedBy ?? '',
                        maxLines: 1,
                        style: TextStyle(
                          color: Colors.green,
                          fontSize: 12,
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        refund.transactionDate ?? '',
                        maxLines: 1,
                        style: TextStyle(
                            color: primaryColor,
                            fontSize: 14,
                            fontWeight: FontWeight.normal),
                      ),
                      SizedBox(
                        height: 6,
                      ),
                      Text(
                        '${refund.finalTotal}',
                        maxLines: 5,
                        style: TextStyle(
                          color: Colors.green,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ]))
          ],
        ),
        onPressed: () {
          Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => RefundPage(refund)));
        },
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          shape:
              MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(6)),
          )),
        ),
      ),
      margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
  }

  void onSelectedCustomer(Customer p1) {
  }
}
