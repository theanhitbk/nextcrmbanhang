import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Refund.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/view/common/ProgressIndicator.dart';

import '../login.dart';
import 'cells/refund_card.dart';

class RefundList extends StatefulWidget {
  @override
  _RefundList createState() => _RefundList();
}

class _RefundList extends State<RefundList> {
  static int page = 0;
  ScrollController _scProduct = new ScrollController();
  bool isLoadingProduct = false;
  final _cSearch = TextEditingController();
  List<Refund> refunds = [];
  @override
  void initState() {
    page = 0;
    this._getMoreRefund(page);
    super.initState();
    _scProduct.addListener(() {
      if (_scProduct.position.pixels == _scProduct.position.maxScrollExtent) {
        _getMoreRefund(page);
      }
    });
  }

  @override
  void dispose() {
    _scProduct.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Chọn đơn trả hàng',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
              onPressed: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //       builder: (context) => ScanBarCode(),
                //       fullscreenDialog: true),
                // );
              },
              icon: Icon(
                Icons.add,
                color: Colors.white,
                size: 24,
              ))
        ],
      ),
      backgroundColor: greyColor2,
      body: _buildListOrder(),
      resizeToAvoidBottomInset: false,
    );
  }

  Widget _buildListOrder() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: refunds.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        if (index == refunds.length) {
          return buildProgressIndicator(isLoadingProduct);
        } else {
          return RefundCard(refund: refunds[index]);
        }
      },
      controller: _scProduct,
    );
  }

  void _getMoreRefund(int index) async {
    if (!isLoadingProduct) {
      setState(() {
        isLoadingProduct = true;
      });
      final response = await APIService().fetchRefunds(index).catchError((e) {
        
      });
      setState(() {
        isLoadingProduct = false;
        refunds.addAll(response.data);
        page++;
      });
    }
  }
}
