import 'package:flutter/material.dart';

import '../../constant.dart';

class SettingApp extends StatefulWidget {
  @override
  _SettingApp createState() => _SettingApp();
}

class _SettingApp extends State<SettingApp> {
  
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cài đặt ứng dụng',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
        actions: [
          TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                'Xong',
                style: TextStyle(color: Colors.white),
              ))
        ],
      ),
      backgroundColor: greyColor2,
      body: Center(),
      resizeToAvoidBottomInset: false,
    );
  }
}
