import 'package:flutter/material.dart';
import 'package:group_list_view/group_list_view.dart';
import 'package:vidifi/constant.dart';

Map<String, List> _elements = {
  'Tổng kết thu chi': ['Tổng thu', 'Tổng chi', 'Thu-chi'],
  'Phương thức thanh toán': [
    'Tiền mặt',
    'Chuyển khoản',
    'Thẻ',
    'Điểm',
    'Voucher'
  ],
  'Tổng kết bán hàng': [
    'Hoá đơn',
    'Số lượng sản phẩm',
    'Doanh thu',
    'Thu khác',
    'Thực thu'
  ],
};

class ReportScreen extends StatefulWidget {
  @override
  _ReportScreen createState() => _ReportScreen();
}

class _ReportScreen extends State<ReportScreen> {
  Widget _itemBuilder(BuildContext context, IndexPath index) {
    String user = _elements.values.toList()[index.section][index.index];
    return ListTile(
        visualDensity: VisualDensity.compact,
        title: Text(
          user,
          style: TextStyle(fontSize: 16),
        ),
        onTap: () {
          print(user);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Báo cáo cuối ngày',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        backgroundColor: Colors.green,
      ),
      body: GroupListView(
        sectionsCount: _elements.keys.toList().length,
        countOfItemInSection: (int section) {
          return _elements.values.toList()[section].length;
        },
        itemBuilder: _itemBuilder,
        groupHeaderBuilder: (BuildContext context, int section) {
          return Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
              child: Container(
                  color: greyColor2,
                  height: 40,
                  padding: const EdgeInsets.fromLTRB(5, 0, 0, 0),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _elements.keys.toList()[section],
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.normal,
                          color: primaryColor),
                      textAlign: TextAlign.left,
                    ),
                  )));
        },
        separatorBuilder: (context, index) => Divider(
          color: Colors.black,
          height: 1,
        ),
        sectionSeparatorBuilder: (context, section) => SizedBox(),
      ),
    );
  }
}
