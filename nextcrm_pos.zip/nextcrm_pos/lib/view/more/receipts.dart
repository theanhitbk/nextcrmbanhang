import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Order.dart';
import 'package:vidifi/services/api_service.dart';

import '../login.dart';

class CreateReceipt extends StatefulWidget {
  final Customer customer;
  CreateReceipt(this.customer);
  @override
  _CreateReceipt createState() => _CreateReceipt(this.customer);
}

class _CreateReceipt extends State<CreateReceipt> {
  var _customer;
  _CreateReceipt(this._customer);
  bool isLoading = false;
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Tạo phiếu thu',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: EdgeInsets.all(4),
        child: Container(),
      ),
      resizeToAvoidBottomInset: false,
    );
  }

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }
}
