import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Channel.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/Product.dart';
import 'package:vidifi/model/Refund.dart';
import 'package:vidifi/view/customer/list_customer.dart';
import 'package:vidifi/view/product/list_price.dart';

enum PaymentType { cash, transfer, card }

class PaymentRefund extends StatefulWidget {
  final Refund refund;
  PaymentRefund(this.refund);
  @override
  _PaymentRefund createState() => _PaymentRefund(this.refund);
}

class _PaymentRefund extends State<PaymentRefund> {
  var _refund;
  _PaymentRefund(this._refund);
  String strCustumer = "";
  String priceStr = "";
  String saleChannel = "Chọn kênh bán";
  bool _switchShipped = true;
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  PaymentType? _character = PaymentType.cash;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Thanh toán trả hàng',
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
          backgroundColor: Colors.green,
        ),
        body: new SingleChildScrollView(
          child: Column(
            children: [
              Divider(
                color: greyColor2,
              ),
              Container(
                height: 32,
                padding: EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  children: <Widget>[
                    Text('Tổng tiền hàng trả'),
                    Spacer(),
                    Text('0'),
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 32,
                padding: EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  children: <Widget>[
                    Text('Phí trả hàng'),
                    Spacer(),
                    Text('0'),
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 32,
                padding: EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  children: <Widget>[
                    Text('Tổng tiền trả'),
                    Spacer(),
                    Text('0'),
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 32,
                padding: EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  children: <Widget>[
                    Text('Tiền trả khách'),
                    Spacer(),
                    Text('0'),
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 32,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                        child: Row(
                      children: [
                        Radio<PaymentType>(
                          value: PaymentType.cash,
                          groupValue: _character,
                          onChanged: (PaymentType? value) {
                            setState(() {
                              _character = value;
                            });
                          },
                        ),
                        Expanded(child: Text('Tiền mặt')),
                      ],
                    )),
                    Expanded(
                        child: Row(
                      children: [
                        Radio<PaymentType>(
                          value: PaymentType.transfer,
                          groupValue: _character,
                          onChanged: (PaymentType? value) {
                            setState(() {
                              _character = value;
                            });
                          },
                        ),
                        Expanded(child: Text('Chuyển khoản')),
                      ],
                    )),
                    Expanded(
                        child: Row(
                      children: [
                        Radio<PaymentType>(
                          value: PaymentType.card,
                          groupValue: _character,
                          onChanged: (PaymentType? value) {
                            setState(() {
                              _character = value;
                            });
                          },
                        ),
                        Expanded(child: Text('Thẻ')),
                      ],
                    ))
                  ],
                ),
              ),
            ],
          ),
        ),
        persistentFooterButtons: [
          ButtonTheme(
              height: 50,
              minWidth: MediaQuery.of(context).size.width,
              // ignore: deprecated_member_use
              child: RaisedButton(
                onPressed: () => {
                  Navigator.of(context).pushNamedAndRemoveUntil('/', ModalRoute.withName('/'))
                },
                child: Text('Thanh toán'),
                color: Colors.green,
                textColor: Colors.white,
              ))
        ]);
  }

  void onSelectCustomer(Customer p1) {
    setState(() {
      this.strCustumer = p1.text;
    });
  }

  void onSelectedPrice(Price p1) {
    setState(() {
      this.priceStr = p1.name;
    });
  }

  void onSelectChannel(Channel p1) {
    setState(() {
      this.saleChannel = p1.name;
    });
  }
}
