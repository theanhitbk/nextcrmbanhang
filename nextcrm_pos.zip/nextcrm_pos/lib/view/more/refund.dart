import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Order.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/Refund.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/view/customer/list_customer.dart';
import 'package:vidifi/view/more/payment_refund.dart';
import 'package:vidifi/view/product/list_price.dart';

import '../login.dart';

class RefundPage extends StatefulWidget {
  final Refund refund;
  RefundPage(this.refund);
  @override
  _RefundPage createState() => _RefundPage(this.refund);
}

class _RefundPage extends State<RefundPage> {
  var _refund;
  _RefundPage(this._refund);
  bool isLoading = false;
  String strCustumer = "Khach Vip";
  String priceStr = "Test";
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Trả hàng',
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
          backgroundColor: Colors.green,
        ),
        body: new SingleChildScrollView(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.only(left: 10),
                child: Row(
                  children: <Widget>[
                    Icon(Icons.person),
                    Text(_refund.customerName ?? strCustumer),
                    Spacer(),
                    IconButton(
                        onPressed: () => {},
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                        ))
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 36,
                padding: EdgeInsets.only(left: 10),
                child: Row(
                  children: <Widget>[
                    Icon(Icons.sell),
                    Text(priceStr),
                    Spacer(),
                    IconButton(
                        onPressed: () => {},
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                        ))
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 44,
                padding: EdgeInsets.only(left: 10),
                child: Row(
                  children: <Widget>[
                    Icon(Icons.card_travel),
                    Text('Bán trực tiếp'),
                    Spacer(),
                    IconButton(
                        onPressed: () => {},
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                        ))
                  ],
                ),
              ),
              Container(
                height: 24,
                color: greyColor2,
              ),
              Container(
                height: 36,
                padding: EdgeInsets.only(left: 16),
                child: Row(
                  children: <Widget>[
                    Text('Máy phát điện'),
                    Spacer(),
                    IconButton(
                        onPressed: () => {},
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          size: 20,
                        ))
                  ],
                ),
              ),
              Divider(),
              Container(
                height: 36,
                padding: EdgeInsets.only(left: 16, right: 16),
                child: Row(
                  children: <Widget>[
                    Text('Tổng trả'),
                    Spacer(),
                    Expanded(child: TextFormField(initialValue: '${_refund.finalTotal ?? 0}'),),
                    Spacer(),
                    Text('0'),
                  ],
                ),
              ),
              Divider(),
            ],
          ),
        ),
        resizeToAvoidBottomInset: false,
        persistentFooterButtons: [
          ButtonTheme(
              height: 50,
              minWidth: MediaQuery.of(context).size.width,
              // ignore: deprecated_member_use
              child: RaisedButton(
                onPressed: () => {
                  Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          PaymentRefund(_refund)))
                },
                child: Text('Thanh toán'),
                color: Colors.green,
                textColor: Colors.white,
              ))
        ]);
  }

  Widget _buildProgressIndicator() {
    return new Padding(
      padding: const EdgeInsets.all(8.0),
      child: new Center(
        child: new Opacity(
          opacity: isLoading ? 1.0 : 00,
          child: new CircularProgressIndicator(),
        ),
      ),
    );
  }

  void onSelectedPrice(Price p1) {}

  void onSelectCustomer(Customer p1) {}
}
