import 'package:flutter/material.dart';
import 'package:vidifi/constant.dart';

class DefaultButton extends StatelessWidget {
  DefaultButton({
    this.text = '',
    this.press,
    this.color = Colors.white,
    this.textColor = Colors.green,
  });
  String text = '';
  Function? press;
  Color? color;
  Color? textColor;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: FlatButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        color: color,
        onPressed: () {
          press!();
        },
        child: Text(
          text,
          style: TextStyle(
            fontSize: 18,
            color: textColor,
          ),
        ),
      ),
    );
  }
}
