part of 'get_area_cubit.dart';

@immutable
abstract class GetAreaState {}

class GetAreaInitial extends GetAreaState {}

class GetListAreaSuccess extends GetAreaState {
  final List<Area> listArea;
  final int level;
  GetListAreaSuccess(this.listArea, this.level);
}

class GetListAreaFailed extends GetAreaState {
  final String reasonFailed;

  GetListAreaFailed(this.reasonFailed);
}
