import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:vidifi/view/common/area_address/area_response.dart';
import 'package:vidifi/view/common/area_address/get_area_repo.dart';

part 'get_area_state.dart';

class GetAreaCubit extends Cubit<GetAreaState> {
  GetAreaCubit() : super(GetAreaInitial());

  GetAreaRepo repo = GetAreaRepo();
  AreaResponse? areaResponse;
  Area? province;
  Area? district;
  Area? ward;
  List<Area>? listProvince;
  List<Area>? listDistrict;
  List<Area>? listWard;

  Future<void> getAreaWithLevel(int idParent) async {
    try {
      areaResponse = await repo.getArea(idParent);
      if (areaResponse != null) {
        if (areaResponse?.meta?.statusCode == 0) {
          if (areaResponse?.data?.length != null) {
            switch (areaResponse?.data?.first.level) {
              case 1:
                listProvince = areaResponse?.data;
                emit(GetListAreaSuccess(listProvince!, 1));
                break;
              case 2:
                listDistrict = areaResponse?.data;
                emit(GetListAreaSuccess(listDistrict!, 2));
                break;
              case 3:
                listWard = areaResponse?.data;
                emit(GetListAreaSuccess(listWard!, 3));
                break;
            }
          }
        } else {
          emit(GetListAreaFailed(areaResponse?.meta?.message ?? 'Đã có lỗi xảy ra'));
        }
      }
    } on Exception catch (e) {
      print(e);
      emit(GetListAreaFailed('Đã có lỗi xảy ra'));
    }

  }

  Future<void> updateAreaList(int level) async {
    level -= 1;
    print('LEVEL CURRENT: $level');
    switch (level) {
      // case 0:
      //   emit(GetListAreaSuccess(listProvince!, 0));
      //   break;
      case 1:
        emit(GetListAreaSuccess(listProvince!, 1));
        break;
      case 2:
        emit(GetListAreaSuccess(listDistrict!, 2));
        break;
      case 3:
        break;
    }
  }

}
