import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:vidifi/services/api_const.dart';
import 'package:vidifi/services/api_request.dart';
import 'package:vidifi/view/common/area_address/area_response.dart';

class GetAreaRepo {

  Future<AreaResponse> getArea(int idArea) async {

    String url = '/api/common/provinces?search[parent_id]=$idArea';
    final response = await BaseRequestAPI().sendRequest(baseUrl+url, RequestMethod.GET);
    return await compute(areaResponseFromJson, response);

  }
}