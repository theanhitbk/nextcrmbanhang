// To parse this JSON data, do
//
//     final areaResponse = areaResponseFromJson(jsonString);

import 'dart:convert';

import 'package:vidifi/model/Meta.dart';

AreaResponse areaResponseFromJson(dynamic str) => AreaResponse.fromJson(str);

String areaResponseToJson(AreaResponse data) => json.encode(data.toJson());

class AreaResponse {
  AreaResponse({
    this.meta,
    this.data,
  });

  Meta? meta;
  List<Area>? data;

  AreaResponse copyWith({
    Meta? meta,
    List<Area>? data,
  }) =>
      AreaResponse(
        meta: meta ?? this.meta,
        data: data ?? this.data,
      );

  factory AreaResponse.fromJson(Map<String, dynamic> json) => AreaResponse(
    meta: json["meta"] == null ? null : Meta.fromJson(json["meta"]),
    data: json["data"] == null ? null : List<Area>.from(json["data"].map((x) => Area.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "meta": meta == null ? null : meta?.toJson(),
    "data": data == null ? null : List<Area>.from(data!.map((x) => x.toJson())),
  };
}

class Area {
  Area({
    this.id,
    this.name,
    this.code,
    this.divisionType,
    this.level,
    this.parentId,
    this.phoneCode,
  });

  int? id;
  String? name;
  String? code;
  String? divisionType;
  int? level;
  int? parentId;
  String? phoneCode;

  Area copyWith({
    int? id,
    String? name,
    String? code,
    String? divisionType,
    int? level,
    int? parentId,
    String? phoneCode,
  }) =>
      Area(
        id: id ?? this.id,
        name: name ?? this.name,
        code: code ?? this.code,
        divisionType: divisionType ?? this.divisionType,
        level: level ?? this.level,
        parentId: parentId ?? this.parentId,
        phoneCode: phoneCode ?? this.phoneCode,
      );

  factory Area.fromJson(Map<String, dynamic> json) => Area(
    id: json["id"] == null ? null : json["id"],
    name: json["name"] == null ? null : json["name"],
    code: json["code"] == null ? null : json["code"],
    divisionType: json["division_type"] == null ? null : json["division_type"],
    level: json["level"] == null ? null : json["level"],
    parentId: json["parent_id"] == null ? null : json["parent_id"],
    phoneCode: json["phone_code"] == null ? null : json["phone_code"],
  );

  Map<String, dynamic> toJson() => {
    "id": id == null ? null : id,
    "name": name == null ? null : name,
    "code": code == null ? null : code,
    "division_type": divisionType == null ? null : divisionType,
    "level": level == null ? null : level,
    "parent_id": parentId == null ? null : parentId,
    "phone_code": phoneCode == null ? null : phoneCode,
  };
}