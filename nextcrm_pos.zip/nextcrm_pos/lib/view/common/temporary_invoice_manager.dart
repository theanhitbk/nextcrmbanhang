import 'dart:convert';

import 'package:hive/hive.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/model/TemporaryInvoice.dart';
import 'package:vidifi/util/hive_manager.dart';

class TemporaryInvoiceManager {

  static TemporaryInvoiceManager? _instance;
  static TemporaryInvoice temporaryInvoice = TemporaryInvoice();
  TemporaryInvoiceManager._();

  static TemporaryInvoiceManager? getInstance() {
    if (_instance == null) {
      _instance = new TemporaryInvoiceManager._();
    }
    return _instance;
  }

  Future<TemporaryInvoice?> getTemporaryInvoiceData() async {
    Map<String, dynamic> json = await jsonDecode(HiveManager.getInstance()?.get('temporary_invoice') ?? '{}') ;
    if (json.isNotEmpty) {
      temporaryInvoice = TemporaryInvoice.fromJson(json);
    } else {
      temporaryInvoice.data = [];
    }
    return temporaryInvoice;
  }

  void addTemporaryInvoice(ProductDetailData detail) {
    print('===123 ${detail.toJson()}');
    temporaryInvoice.data?.insert(0,detail);
    print('===== ${temporaryInvoice.data?.length}');
    saveTemporaryToLocal();
  }

  void saveTemporaryToLocal() {
    HiveManager.getInstance()?.put('temporary_invoice', jsonEncode(temporaryInvoice));
  }

  TemporaryInvoice getTemporaryInvoice() {
    return temporaryInvoice;
  }

}