import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:vidifi/model/Product.dart';

import '../../constant.dart';

class CarouselWithIndicatorDemo extends StatefulWidget {
  final List<Widget> imageSliders;
  final Product product;

  @override
  State<StatefulWidget> createState() {
    return _CarouselWithIndicatorState();
  }

  CarouselWithIndicatorDemo(this.imageSliders, this.product);
}

class _CarouselWithIndicatorState extends State<CarouselWithIndicatorDemo> {
  int _current = 0;
  final CarouselController _controller = CarouselController();

  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
      appBar: AppBar(title: Text(widget.product.productCode ?? ''), backgroundColor: Colors.green,),
      body: Container(
        color: Colors.grey[50],
        height: 900,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Container(
            //   // padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            //   height: 50,
            //   color: Colors.green,
            //   child: Row(
            //     children: [
            //       IconButton(icon: Icon(Icons.clear,size: 24, color: Colors.white,), onPressed: () {
            //         Navigator.of(context).pop();
            //       },),
            //       Container(color: Colors.green,
            //         // width: double.infinity,
            //         padding: EdgeInsets.all(6),
            //         child: Text(widget.product.productCode ?? ' '),),
            //     ],
            //   ),
            // ),
            AspectRatio(
              aspectRatio: 1,
              child: Stack(
                // mainAxisSize: MainAxisSize.min,
                  children: [
                    AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        width: double.infinity,
                        child: CarouselSlider(
                          items: widget.imageSliders,
                          carouselController: _controller,
                          options: CarouselOptions(
                              autoPlay: false,
                              enlargeCenterPage: true,
                              aspectRatio: 1,
                              enableInfiniteScroll: false,
                              onPageChanged: (index, reason) {
                                setState(() {
                                  _current = index;
                                });
                              }),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: widget.imageSliders.asMap().entries.map((entry) {
                            return GestureDetector(
                              onTap: () => _controller.animateToPage(entry.key),
                              child: Container(
                                width: 12.0,
                                height: 12.0,
                                margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: (Theme.of(context).brightness == Brightness.dark
                                        ? Colors.white
                                        : Colors.black)
                                        .withOpacity(_current == entry.key ? 0.9 : 0.4)),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ]),
            ),
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(vertical: 6, horizontal: 16),
              child: Text(widget.product.name),
              color: greyColor2,),
          ],
        ),
      ),
    );
  }
}

class VerticalSliderDemo extends StatelessWidget {
  final List<Widget> imageSliders;

  VerticalSliderDemo(this.imageSliders);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Vertical sliding carousel demo')),
      body: Container(
          child: CarouselSlider(
            options: CarouselOptions(
              aspectRatio: 2.0,
              enlargeCenterPage: false,
              scrollDirection: Axis.horizontal,
              autoPlay: false,
            ),
            items: imageSliders,
          )),
    );
  }
}