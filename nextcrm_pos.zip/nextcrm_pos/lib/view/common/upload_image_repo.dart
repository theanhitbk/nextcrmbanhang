import 'package:flutter/foundation.dart';
import 'package:vidifi/services/api_const.dart';
import 'package:vidifi/services/api_request.dart';
import 'package:vidifi/view/product/model/upload_img_model.dart';

class UploadImageRepo {
  Future<UploadImgResponse>uploadImage(Map data) async {
    String url = '/api/upload/image-upload-base64';
    final response = await BaseRequestAPI().sendRequest(baseUrl+url, RequestMethod.POST,
        jsonMap: data);
    return await compute(uploadImgResponseFromJson,response);
  }
}