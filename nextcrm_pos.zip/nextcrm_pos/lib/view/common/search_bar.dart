import 'dart:async';

import 'package:flutter/material.dart';

class SearchBarCommon extends StatefulWidget {
  final Color? color;
  final TextEditingController controller;
  final String? hintText;
  final IconButton? rightBtn;
  final bool? isDelayed;
  final int? maxLength;
  final Function(String textChange)? textChanged;
  const SearchBarCommon({Key? key, this.color, required this.controller, this.hintText, this.rightBtn, this.textChanged, this.isDelayed, this.maxLength}) : super(key: key);

  @override
  _SearchBarCommonState createState() => _SearchBarCommonState();
}

class _SearchBarCommonState extends State<SearchBarCommon> {
  late Timer searchOnStoppedTyping;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: widget.color ?? Colors.transparent,
      height: 38,
      // width: double.infinity,
      child: Row(
        children: [
          Expanded(
              child: TextField(
                maxLines: 1,
                maxLength: widget.maxLength ?? 15,
                onChanged: (text) {
                  if (widget.textChanged != null ) {
                    if (widget.isDelayed == true) {
                      // const duration = Duration(
                      //     milliseconds:
                      //     900); // set the duration that you want call search() after that.
                      // if (searchOnStoppedTyping != null) {
                      //   searchOnStoppedTyping.cancel();
                      //   // setState(() => searchOnStoppedTyping.cancel()); // clear timer
                      // }
                      // searchOnStoppedTyping = new Timer(duration, () => widget.textChanged!(text));
                      // setState(() =>
                      // searchOnStoppedTyping = new Timer(duration, () => widget.textChanged!(text)));
                    } else {
                      widget.textChanged!(text);
                    }
                  }
                },
                controller: widget.controller,
                autofocus: false,
                style: new TextStyle(
                  color: Colors.black,
                ),
                decoration: new InputDecoration(
                  counterText: '',
                  filled: false,
                  prefixIcon: new Icon(Icons.search, color: Colors.grey),
                  border: OutlineInputBorder(borderSide: BorderSide.none),
                  hintText: widget.hintText ?? 'Tìm kiếm',
                  hintStyle: new TextStyle(color: Colors.grey, fontSize: 12),
                    suffixIcon: widget.controller.text != '' ? IconButton(
                        icon: Icon(Icons.cancel, color: Colors.grey),
                        onPressed: () {
                          setState(() {
                            widget.controller.clear();
                            if (widget.textChanged != null ) {
                              widget.textChanged!('');
                            }
                          });
                        }) : null,
                ),
              )),
          SizedBox(width: 10,),
          // IconButton(
          //     onPressed: () {
          //       // Navigator.of(context).push(
          //       //   MaterialPageRoute(
          //       //       builder: (context) =>
          //       //           ListProperty(propertySelected),
          //       //       fullscreenDialog: true),
          //       // );
          //     },
          //     icon: Icon(
          //       Icons.filter_alt,
          //     )),
        ],
      ),
    );
  }
}
