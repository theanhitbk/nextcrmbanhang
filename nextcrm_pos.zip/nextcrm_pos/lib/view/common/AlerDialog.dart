import 'package:flutter/material.dart';

class BaseAlertDialog extends StatelessWidget {
  String _title = '';
  String _content = '';
  Function? _yesOnPressed;
  Function? _noOnPressed;
  
  BaseAlertDialog({required String title, required String content, Function? yesOnPressed, Function? noOnPressed}){
    this._title = title;
    this._content = content;
    this._yesOnPressed = yesOnPressed;
    this._noOnPressed = noOnPressed;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: new Text(this._title),
      content: new Text(this._content),
      shape:
          RoundedRectangleBorder(borderRadius: new BorderRadius.circular(15)),
      actions: <Widget>[
        new FlatButton(
          child: Text('Hủy'),
          textColor: Colors.redAccent,
          onPressed: () {
            this._noOnPressed!();
          },
        ),
        new FlatButton(
          child: new Text('Đồng ý'),
          textColor: Colors.blue,
          onPressed: () {
            this._yesOnPressed!();
          },
        ),
      ],
    );
  }
}
showAlertDialog(BuildContext context, String text) {
  // set up the buttons
  Widget cancelButton = TextButton(
    child: Text("Hủy"),
    onPressed:  () {
      Navigator.of(context).pop();
    },
  );
  Widget continueButton = TextButton(
    child: Text("Continue"),
    onPressed:  () {
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Thông báo"),
    content: Text(text),
    actions: [
      cancelButton,
      continueButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}