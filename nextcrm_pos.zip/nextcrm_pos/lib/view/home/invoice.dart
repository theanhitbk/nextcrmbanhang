import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/src/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Channel.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/model/TemporaryInvoice.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/temporary_invoice_manager.dart';
import 'package:vidifi/view/customer/list_customer.dart';
import 'package:vidifi/view/home/payment.dart';
import 'package:vidifi/view/invoice/cubit/temporary_cubit.dart';
import 'package:vidifi/view/product/list_price.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

import 'list_channel.dart';

class InvoiceScreen extends StatefulWidget {
  final ProductDetailData product;
  final bool? isTemporary;

  InvoiceScreen(this.product, {this.isTemporary = false});

  @override
  _InvoiceScreen createState() => _InvoiceScreen(this.product);
}

class _InvoiceScreen extends State<InvoiceScreen> {
  var _product;
  late TemporaryCubit temporaryCubit;
  late ProfileCubit profileCubit;

  _InvoiceScreen(this._product);

  String strCustumer = "Khach Vip";
  String priceStr = "Test";
  String channelName = "Chọn kênh bán";
  int quantity = 1;
  bool isPurchase = false;

  // double? totalPrice = double.parse(_product.data?.product?.defaultSellPrice ?? '0');
  @override
  void initState() {
    temporaryCubit = context.read<TemporaryCubit>();
    profileCubit = context.read<ProfileCubit>();
    priceStr = profileCubit.selectedPrice?.name ?? 'Bảng giá';
    strCustumer = profileCubit.selectedCustomer?.text ?? 'Khách lẻ';
    _product.product.customerId = profileCubit.selectedCustomer?.id ?? 0;
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<bool> _onWillPop() async {
    return (await showDialog(
          context: context,
          builder: (context) => new AlertDialog(
            content: new Text('Bạn có muốn lưu đơn hàng này không?'),
            actions: <Widget>[
              TextButton(
                onPressed: () async {
                  if (widget.isTemporary == true) {
                    int? indexOfProduct = temporaryCubit.temporaryInvoice.data
                        ?.indexWhere((element) => element.name == _product.name);
                    print('INDEX OF $indexOfProduct');
                    if (indexOfProduct != null) {
                    temporaryCubit.temporaryInvoice.data?.removeAt(indexOfProduct);
                      // temporaryCubit.temporaryInvoice.data?[indexOfProduct] = _product;
                      temporaryCubit.saveTemporaryToLocal();
                    }
                  }
                  Navigator.of(context).pop(true);
                },
                child: new Text(
                  'Hủy đơn',
                  style: TextStyle(color: Colors.red),
                ),
              ),
              TextButton(
                onPressed: () => {
                  _product.name = _product.name != null
                      ? _product.name
                      :
                      // "Hóa đơn ${(TemporaryInvoiceManager.getInstance()?.getTemporaryInvoice().data?.length ?? 0) + 1}",
                      "Hóa đơn ${(temporaryCubit.temporaryInvoice.data?.length ?? 0) + 1}",
                  if (stringIsEmptyOrNull(_product.date))
                    _product.date = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now()),
                  //     temporaryInvoice = TemporaryInvoice(),
                  // temporaryInvoice?.data = [_product],
                  this._saveInvoice(_product),
                },
                child: new Text('Lưu tạm'),
              ),
            ],
          ),
        )) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: _onWillPop,
        child: Scaffold(
          backgroundColor: greyColor2,
          appBar: AppBar(
            title: Text(
              'Hóa đơn',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            backgroundColor: Colors.green,
          ),
          body: new SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  color: Colors.white,
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: 16,
                      ),
                      Icon(Icons.person),
                      SizedBox(
                        width: 6,
                      ),
                      Text(strCustumer),
                      Spacer(),
                      IconButton(
                          onPressed: () => {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => ListCustomer(onSelectCustomer)))
                              },
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            size: 20,
                          ))
                    ],
                  ),
                ),
                Divider(
                  height: 1,
                ),
                Container(
                  color: Colors.white,
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: 16,
                      ),
                      Icon(Icons.sell),
                      SizedBox(
                        width: 6,
                      ),
                      Text(profileCubit.selectedPrice?.name ?? ''),
                      Spacer(),
                      IconButton(
                          onPressed: () => {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => ListPrice(onSelectedPrice)))
                              },
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            size: 20,
                          ))
                    ],
                  ),
                ),
                SizedBox(
                  height: 32,
                ),
                Container(
                  color: Colors.white,
                  // height: 34,
                  padding: EdgeInsets.only(left: 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 5,
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: 6),
                        child:
                            Text('${_product.product.productName} (${_product.units.first.name})'),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(vertical: 6),
                        child: Row(
                          children: [
                            RichText(
                              overflow: TextOverflow.clip,
                              // maxLines: 3,
                              text: TextSpan(
                                children: <TextSpan>[
                                  TextSpan(
                                      text: convertToCurrency(
                                          double.parse(_product?.product?.defaultSellPrice ?? '0.0')
                                              .toInt()),
                                      style: TextStyle(
                                          color: Colors.black, fontWeight: FontWeight.w600)),
                                  TextSpan(text: ' x', style: TextStyle(color: Colors.blue)),
                                ],
                              ),
                            ),
                            Spacer(),
                            Visibility(
                              visible: true,
                              child: Container(
                                  child: Icon(
                                Icons.warning_amber_rounded,
                                color: Colors.red,
                              )),
                            ),
                            Container(
                              height: 30,
                              child: IconButton(
                                  splashColor: Colors.transparent,
                                  onPressed: () {
                                    setState(() {
                                      if (quantity == 1) return;
                                      quantity -= 1;
                                    });
                                  },
                                  icon: Icon(
                                    Icons.remove_outlined,
                                    size: 20,
                                    color: quantity == 1 ? Colors.grey : Colors.green,
                                  )),
                            ),
                            Container(
                                // color: Colors.green,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(Radius.circular(4)),
                                    color: Colors.grey[50],
                                    border: Border.all(color: Color(0xffD2D1D1), width: 1)),
                                // color: Colors.grey[50],
                                width: 44,
                                height: 25,
                                child: Center(
                                    child: Text(
                                  quantity.toString(),
                                  style: TextStyle(fontWeight: FontWeight.w600),
                                ))),
                            Container(
                              height: 30,
                              child: IconButton(
                                  splashColor: Colors.transparent,
                                  onPressed: () {
                                    setState(() {
                                      quantity += 1;
                                    });
                                  },
                                  icon: Icon(
                                    Icons.add,
                                    size: 20,
                                    color: Colors.green,
                                  )),
                            ),
                          ],
                        ),
                      ),
                      // SizedBox(
                      //   height: 1,
                      // ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          persistentFooterButtons: [
            Column(
              children: [
                Container(
                    height: 44,
                    child: TextButton(
                      child: Row(
                        children: [
                          SizedBox(
                            width: 12,
                          ),
                          Icon(
                            Icons.shopping_basket_outlined,
                            color: Colors.black,
                          ),
                          SizedBox(
                            width: 6,
                          ),
                          Text(
                            channelName,
                            style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black),
                          ),
                          Spacer(),
                          Container(
                              // color: Colors.green,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(4)),
                                  color: Colors.grey[50],
                                  border: Border.all(color: Color(0xffD2D1D1), width: 1)),
                              // color: Colors.grey[50],
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                child: Text(
                                  quantity.toString(),
                                  style: TextStyle(fontWeight: FontWeight.w600),
                                ),
                              )),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8),
                            child: Text(
                              convertToCurrency(
                                  double.parse(_product?.product?.defaultSellPrice ?? '0').toInt() *
                                      quantity),
                              style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => ListChannel(onSelectChannel)));
                      },
                    )),
                SizedBox(
                  height: 4,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ButtonTheme(
                        height: 50,
                        minWidth: MediaQuery.of(context).size.width / 2 - 10,
                        // ignore: deprecated_member_use
                        child: RaisedButton(
                          onPressed: () => {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => PaymentScreen(this._product, true, quantity)))
                          },
                          child: Text('Đặt hàng'),
                          color: Colors.blue,
                          textColor: Colors.white,
                        )),
                    ButtonTheme(
                        height: 50,
                        minWidth: MediaQuery.of(context).size.width / 2 - 10,
                        // ignore: deprecated_member_use
                        child: RaisedButton(
                          onPressed: () => {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => PaymentScreen(this._product, false, quantity)))
                          },
                          child: Text('Thanh toán'),
                          color: Colors.green,
                          textColor: Colors.white,
                        ))
                  ],
                ),
              ],
            )
          ],
        ));
  }

  void onSelectCustomer(Customer p1) {
    setState(() {
      this.strCustumer = p1.text;
      _product.product.customerId = p1.id;
    });
  }

  void onSelectedPrice(Price p1) {
    setState(() {
      this.priceStr = p1.name;
    });
  }

  void onSelectChannel(Channel p1) {
    setState(() {
      this.channelName = p1.name;
    });
  }

  void _saveInvoice(ProductDetailData data) async {
    if (widget.isTemporary == true) {
      int? indexOfProduct = temporaryCubit.temporaryInvoice.data
          ?.indexWhere((element) => element.name == _product.name);
      if (indexOfProduct != null) {
        // temporaryCubit.temporaryInvoice.data?.removeAt(indexOfProduct);
        temporaryCubit.temporaryInvoice.data?[indexOfProduct] = _product;
        temporaryCubit.saveTemporaryToLocal();
        // temporaryCubit.saveTemporaryToLocal();
        // TemporaryInvoiceManager.getInstance()?.getTemporaryInvoice().data?[indexOfProduct] = _product;
        // TemporaryInvoiceManager.getInstance()?.saveTemporaryToLocal();
      }
    } else {
      temporaryCubit.addTemporaryInvoice(data);
    }
    // if (temp != null) {
    //   final prefs = await SharedPreferences.getInstance();
    //   setState(() {
    //     prefs.setString('TemporaryInvoice', jsonEncode(temp));
    //   });
    // }
    Navigator.of(context).pop(true);
  }
}
