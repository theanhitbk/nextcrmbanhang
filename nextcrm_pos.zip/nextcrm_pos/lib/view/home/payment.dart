import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/src/provider.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Channel.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/ProductDetail.dart';
import 'package:vidifi/model/PurchaseRequest.dart';
import 'package:vidifi/model/SellRequest.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/AlerDialog.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

import '../../main.dart';
import '../../model/Payment.dart';
import '../../util/hide_keyboard.dart';
import 'list_channel.dart';

enum PaymentType { cash, transfer, card }

class PaymentScreen extends StatefulWidget {
  final ProductDetailData productDetailRes;
  bool isPurchase;
  int quantity;

  PaymentScreen(this.productDetailRes, this.isPurchase, this.quantity);

  @override
  _PaymentScreen createState() => _PaymentScreen(this.productDetailRes, this.isPurchase);
}

class _PaymentScreen extends State<PaymentScreen> {
  var productDetailRes;
  bool isPurchase;

  _PaymentScreen(this.productDetailRes, this.isPurchase);

  String strCustumer = "";
  String priceStr = "";
  String saleChannel = "Chọn kênh bán";
  bool _switchShipped = true;
  PurchaseRequest purchaseRequest = PurchaseRequest();
  SellRequest sellRequest = SellRequest();
  final txtFinalTotal = TextEditingController();
  final txtDiscount = TextEditingController(text: '');
  final txtOther = TextEditingController(text: '');
  TextEditingController _customerPay = TextEditingController(text: '');
  var customerPaid = 0;
  var excessCash = 0;
  int discountType = 0;
  int _preTotal = 0;
  int _needToPay = 0;
  int _percent = 0;
  int _other = 0;
  int _return = 0;
  late ProfileCubit profileCubit;

  void initState() {
    profileCubit = context.read<ProfileCubit>();
    _preTotal =
        widget.quantity * double.parse(productDetailRes?.product?.defaultSellPrice ?? '0').toInt();
    _calculateMoney();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  PaymentType? _character = PaymentType.cash;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        hideKeyboard(context);
      },
      child: Scaffold(
          appBar: AppBar(
            title: Text(
              'Hoá đơn',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            backgroundColor: Colors.green,
          ),
          body: new SingleChildScrollView(
            child: Column(
              children: [
                Divider(
                  color: greyColor2,
                ),
                Container(
                  height: 32,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Tổng tiền hàng'),
                      Spacer(),
                      Text(convertToCurrency(_preTotal, unit: false),
                          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600))
                    ],
                  ),
                ),
                Divider(),
                Container(
                  height: 32,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Giảm giá'),
                      CupertinoSegmentedControl<int>(
                        selectedColor: Colors.green,
                        borderColor: Colors.grey,
                        children: {
                          0: Text('VNĐ'),
                          1: Text('%'),
                        },
                        onValueChanged: (int val) {
                          setState(() {
                            discountType = val;
                          });
                        },
                        groupValue: discountType,
                      ),
                      Spacer(),
                      Expanded(
                        child: TextField(
                          onChanged: (text) {
                            if (stringIsEmptyOrNull(text)) {
                              _percent = 0;
                            } else
                              _percent = int.parse(text);
                            _calculateMoney();
                          },
                          textAlignVertical: TextAlignVertical.center,
                          textAlign: TextAlign.right,
                          controller: txtDiscount,
                          keyboardType: TextInputType.number,
                          obscureText: false,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              contentPadding: EdgeInsets.only(right: 5),
                              hintText: "0"),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(),
                Container(
                  height: 32,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Thu khác'),
                      Spacer(),
                      Expanded(
                        child: TextField(
                          onChanged: (text) {
                            if (stringIsEmptyOrNull(text)) {
                              _other = 0;
                            } else {
                              String _string = text.replaceAll(",", "");
                              _other = int.parse(_string);
                            }
                            _calculateMoney();
                            txtOther.value = TextEditingValue(
                              text: convertToCurrency(_other, unit: false),
                              selection: TextSelection.collapsed(
                                  offset: convertToCurrency(_other, unit: false).length),
                            );
                          },
                          controller: txtOther,
                          textAlignVertical: TextAlignVertical.center,
                          textAlign: TextAlign.right,
                          obscureText: false,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              contentPadding: EdgeInsets.only(right: 5),
                              hintText: '0'),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(),
                Container(
                  height: 32,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Khách cần trả'),
                      Spacer(),
                      Text(
                        convertToCurrency(_needToPay, unit: false),
                        style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
                Divider(),
                Container(
                  height: 32,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Khách thanh toán'),
                      SizedBox(
                        width: 4,
                      ),
                      _character == PaymentType.cash ? Icon(Icons.money) : Icon(Icons.credit_card),
                      Spacer(),
                      Expanded(
                        child: TextField(
                          onChanged: (value) {
                            if (stringIsEmptyOrNull(value)) {
                              customerPaid = 0;
                            } else {
                              String _string = value.replaceAll(",", "");
                              customerPaid = int.parse(_string);
                            }
                            // String _string = NumberFormat("#,###", "en_US").format(value.replaceAll(",", ""));
                            _calculatePrice();
                            _customerPay.value = TextEditingValue(
                              text: convertToCurrency(customerPaid, unit: false),
                              selection: TextSelection.collapsed(
                                  offset: convertToCurrency(customerPaid, unit: false).length),
                            );
                          },
                          obscureText: false,
                          controller: _customerPay,
                          textAlign: TextAlign.right,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: '0',
                              contentPadding: EdgeInsets.only(right: 5)),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(),
                Container(
                  height: 40,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                          child: Row(
                        children: [
                          Radio<PaymentType>(
                            value: PaymentType.cash,
                            groupValue: _character,
                            onChanged: (PaymentType? value) {
                              setState(() {
                                _character = value;
                              });
                            },
                          ),
                          Expanded(child: Text('Tiền mặt')),
                        ],
                      )),
                      Expanded(
                          child: Row(
                        children: [
                          Radio<PaymentType>(
                            value: PaymentType.transfer,
                            groupValue: _character,
                            onChanged: (PaymentType? value) {
                              setState(() {
                                _character = value;
                              });
                            },
                          ),
                          Expanded(child: Text('Chuyển khoản')),
                        ],
                      )),
                      Expanded(
                          child: Row(
                        children: [
                          Radio<PaymentType>(
                            value: PaymentType.card,
                            groupValue: _character,
                            onChanged: (PaymentType? value) {
                              setState(() {
                                _character = value;
                              });
                            },
                          ),
                          Expanded(child: Text('Thẻ')),
                        ],
                      ))
                    ],
                  ),
                ),
                Container(
                  height: 32,
                  color: greyColor2,
                ),
                Container(
                  height: 32,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Tiền thừa trả khách'),
                      Spacer(),
                      Text(convertToCurrency(excessCash, unit: false)),
                    ],
                  ),
                ),
                Container(
                  height: 32,
                  color: greyColor2,
                ),
                Container(
                  height: 44,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text('Giao hàng'),
                      Spacer(),
                      CupertinoSwitch(
                        value: _switchShipped,
                        onChanged: (value) {
                          setState(() {
                            _switchShipped = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 32,
                  color: greyColor2,
                ),
                Container(
                  height: 44,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    children: <Widget>[
                      Text(saleChannel),
                      Spacer(),
                      IconButton(
                          onPressed: () => {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => ListChannel(onSelectChannel)))
                              },
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            size: 20,
                          ))
                    ],
                  ),
                ),
              ],
            ),
          ),
          persistentFooterButtons: [
            ButtonTheme(
                height: 50,
                minWidth: MediaQuery.of(context).size.width,
                // ignore: deprecated_member_use
                child: RaisedButton(
                  onPressed: () => {
                    // Navigator.of(context).pushNamedAndRemoveUntil('/', ModalRoute.withName('/'))
                    if (this.isPurchase) {this._sendPurchase()} else {this._sendSelling()}
                  },
                  child: Text('Hoàn thành'),
                  color: Colors.blue,
                  textColor: Colors.white,
                ))
          ]),
    );
  }

  void _sendPurchase() async {
    Products productPurchase = Products();
    productPurchase.enableStock = productDetailRes?.product?.enableStock;
    productPurchase.productId = productDetailRes?.product?.productId;
    productPurchase.productType = productDetailRes?.product?.productType;
    productPurchase.quantity = widget.quantity;
    // productDetailRes?.product?.qtyAvailable;
    productPurchase.unitId = productDetailRes?.product?.unitId;
    productPurchase.variationId = productDetailRes?.product?.variationId;
    productPurchase.unitId = productDetailRes?.product?.unitId;
    productPurchase.fConvert = productDetailRes?.units?.first.multiplier;
    productPurchase.unitPrice = double.parse(productDetailRes?.units?.first.price ?? '0').toInt();
    purchaseRequest.transactionDate = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
    purchaseRequest.isDeliver = _switchShipped ? 1 : 0;
    purchaseRequest.products = [productPurchase];
    purchaseRequest.status = 'quotation';
    purchaseRequest.totalBeforeTax =
        _preTotal;
    purchaseRequest.finalTotal =
        _needToPay;
    purchaseRequest.userId = profileCubit.currentUser.id;
    purchaseRequest.discountType = discountType == 0 ? 'fixed' : 'percentage';
    purchaseRequest.discountAmount = 0;
    purchaseRequest.branchId = profileCubit.currentBranch?.id;
    purchaseRequest.customerId = productDetailRes?.product?.customerId;
    Payment _payment = new Payment(
        amount: _needToPay,
        method: _character == PaymentType.cash ? 'cash' : 'bank',
        paymentType: 'in_come');
    purchaseRequest.payment = [_payment];
    purchaseRequest.priceBookId = profileCubit.selectedPrice?.id ?? 31;

    final response = await APIService().createPurchase(purchaseRequest).catchError((e) {
      print('END CALL API111 ${e.toString()}');
    });
    if ( response?.meta?.statusCode == 0) {
      showDialog(
          context: context,
          builder: (BuildContext context) => BaseAlertDialog(
              title: 'Thành công',
              content: 'Tạo đơn đặt hàng thành công',
              yesOnPressed: () {
                Navigator.pushAndRemoveUntil(
                    context, MaterialPageRoute(builder: (context) => Home()), (route) => false);
              },
              noOnPressed: () {
                Navigator.pop(context);
              }));
    } else {
      showToastFailed(response?.meta?.message ?? "Đã có lỗi xảy ra");
    }
  }

  void _sendSelling() async {
    Products productPurchase = Products();
    productPurchase.enableStock = productDetailRes?.product?.enableStock;
    productPurchase.productId = productDetailRes?.product?.productId;
    productPurchase.productType = productDetailRes?.product?.productType;
    productPurchase.quantity = widget.quantity;
    productPurchase.unitId = productDetailRes?.product?.unitId;
    productPurchase.variationId = productDetailRes?.product?.variationId;
    productPurchase.unitId = productDetailRes?.product?.unitId;
    productPurchase.fConvert = productDetailRes?.units?.first.multiplier;
    productPurchase.unitPrice = double.parse(productDetailRes?.units?.first.price ?? '0').toInt();
    sellRequest.transactionDate = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());
    sellRequest.isDeliver = _switchShipped ? 1 : 0;
    sellRequest.products = [productPurchase];
    sellRequest.status = 'final';
    sellRequest.totalBeforeTax = _preTotal;
    sellRequest.finalTotal = _needToPay;
    sellRequest.userId = profileCubit.currentUser.id;
    sellRequest.discountType = discountType == 0 ? 'fixed' : 'percentage';
    sellRequest.discountAmount = 0;
    sellRequest.branchId = profileCubit.currentBranch?.id;
    sellRequest.customerId = productDetailRes?.product?.customerId;
    sellRequest.priceBookId = profileCubit.selectedPrice?.id ?? 31;
    Payment _payment = new Payment(
        amount: _needToPay,
        method: _character == PaymentType.cash ? 'cash' : 'bank',
        paymentType: 'in_come');
    sellRequest.payment = [_payment];
    sellRequest.taxAmount = 0;
    final response = await APIService().createSell(sellRequest).catchError((e) {});
    if (response?.meta?.statusCode == 0) {
      showDialog(
          context: context,
          builder: (BuildContext context) => BaseAlertDialog(
              title: 'Thành công',
              content: 'Tạo đơn bán hàng thành công',
              yesOnPressed: () {
                Navigator.pushAndRemoveUntil(
                    context, MaterialPageRoute(builder: (context) => Home()), (route) => false);
              },
              noOnPressed: () {
                Navigator.pop(context);
              }));
    } else {
      showToastFailed(response?.meta?.message ?? "Đã có lỗi xảy ra");
    }
  }

  void onSelectCustomer(Customer p1) {
    setState(() {
      this.strCustumer = p1.text;
    });
  }

  void onSelectedPrice(Price p1) {
    setState(() {
      this.priceStr = p1.name;
    });
  }

  void onSelectChannel(Channel p1) {
    setState(() {
      this.saleChannel = p1.name;
      purchaseRequest.sourceId = p1.id;
    });
  }

  void _calculateMoney() {
    setState(() {
      if (discountType == 0) {
        _needToPay = (_preTotal - _percent + _other).toInt();
      } else {
        _needToPay = (_preTotal * (100 - _percent) / 100 + _other).toInt();
      }
    });
  }

  void _calculatePrice() {
    setState(() {
      this.excessCash = customerPaid - _needToPay;
    });
  }
}
