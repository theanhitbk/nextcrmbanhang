import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Channel.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/services/api_service.dart';

class ListChannel extends StatefulWidget {
  final void Function(Channel) onSelected;
  ListChannel(this.onSelected);
  @override
  _ListChannel createState() => _ListChannel(this.onSelected);
}

class _ListChannel extends State<ListChannel> {
  var _onSelected;
  _ListChannel(this._onSelected);
  ScrollController _sc = new ScrollController();
  List<Channel> channels = [];
  @override
  void initState() {
    this._getListChannel();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chọn kênh bán',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        backgroundColor: Colors.green,
      ),
      backgroundColor: greyColor2,
      body: Padding(padding: EdgeInsets.all(4), child: _buildListChannel()),
      resizeToAvoidBottomInset: false,
    );
  }

  void _getListChannel() async {
    final response = await APIService().fetchSaleChannel().catchError((e) {
    });
    setState(() {
      if (response.channel != null) {
        channels.addAll(response.channel!);
      }
    });
  }

  Widget _buildListChannel() {
    return ListView.builder(
      padding: EdgeInsets.only(top: 16),
      itemCount: channels.length, // Add one more item for progress indicator
      itemBuilder: (BuildContext context, int index) {
        var channel = channels[index];
        return Container(
      child: TextButton(
        child: Row(
          children: <Widget>[
            Flexible(
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          channel.name,
                          maxLines: 2,
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: 14,
                              fontWeight: FontWeight.normal),
                          textAlign: TextAlign.start,
                        ),
                      ],
                    ),
                  ),
                ]))
          ],
        ),
        onPressed: () {
          _onSelected(channel);
          Navigator.pop(context);
        },
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          shape:
              MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(6)),
          )),
        ),
      ),
      margin: EdgeInsets.only(bottom: 5.0, left: 5.0, right: 5.0),
    );
      },
      controller: _sc,
    );
  }
}
