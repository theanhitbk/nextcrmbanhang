import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:vidifi/model/ProductDetail.dart';

import 'invoice.dart';

class ParcelManagementScreen extends StatefulWidget {
  final ProductDetailData product;
  ParcelManagementScreen(this.product);
  @override
  _ParcelManagementScreenState createState() =>
      _ParcelManagementScreenState(this.product);
}

class _ParcelManagementScreenState extends State<ParcelManagementScreen> {
  ProductDetailData _product;
  _ParcelManagementScreenState(this._product);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Lô, hạn sử dụng',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        backgroundColor: Colors.green,
        actions: [
          TextButton(
              onPressed: () {
                // this._saveProduct();
                Navigator.of(context).pop(true);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => InvoiceScreen(_product)));
              },
              child: Text(
                'Xong',
                style: TextStyle(color: Colors.white),
              ))
        ],
      ),
      body: Column(
        children: [
          Expanded(
              child: ListView.separated(
            itemBuilder: (ctx, index) {
              return buildItemParcel(_product.product?.lotNumbers![index]);
            },
            separatorBuilder: (bCtx, index) {
              return Divider(
                height: 1,
              );
            },
            itemCount: _product.product?.lotNumbers?.length ?? 0,
            padding: EdgeInsets.symmetric(horizontal: 0, vertical: 18),
          )),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).padding.bottom),
              child: GestureDetector(
                onTap: () {},
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(true),
                      child: Text(
                        'Bỏ qua nếu bạn đang tạo đơn đặt hàng',
                        style: TextStyle(color: Colors.blue),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        Navigator.of(context).pop(true);
                      },
                      splashColor: Colors.transparent,
                      icon: Icon(Icons.arrow_forward_ios),
                      iconSize: 16,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  ///FAKE DATA
  int quantity = 1;
  Widget buildItemParcel(LotNumbers? lot) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(top: 8, left: 16, right: 16),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.all(Radius.circular(2))),
                padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                child: Text(
                  'Lô',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Text(
                  lot?.lotNumber ?? '',
                  style: TextStyle(color: Colors.black),
                ),
              )
            ],
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: RichText(
                overflow: TextOverflow.clip,
                // maxLines: 3,
                text: TextSpan(
                  children: <TextSpan>[
                    TextSpan(
                        text: 'HSD: ', style: TextStyle(color: Colors.black87)),
                    TextSpan(
                        text: lot?.expDate,
                        style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              Text('Tồn ${lot?.qtyAvailable}'),
              Spacer(),
              Visibility(
                visible: true,
                child: Row(
                  children: [
                    Container(
                      height: 30,
                      child: IconButton(
                          splashColor: Colors.transparent,
                          onPressed: () {
                            setState(() {
                              if (quantity == 1) return;
                              quantity -= 1;
                            });
                          },
                          icon: Icon(
                            Icons.remove_outlined,
                            size: 20,
                            color: quantity == 1 ? Colors.grey : Colors.green,
                          )),
                    ),
                    Container(
                        // color: Colors.green,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                            color: Colors.grey[50],
                            border:
                                Border.all(color: Color(0xffD2D1D1), width: 1)),
                        // color: Colors.grey[50],
                        width: 44,
                        height: 25,
                        child: Center(
                            child: Text(
                          quantity.toString(),
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ))),
                    Container(
                      height: 30,
                      child: IconButton(
                          splashColor: Colors.transparent,
                          onPressed: () {
                            setState(() {
                              quantity += 1;
                            });
                          },
                          icon: Icon(
                            Icons.add,
                            size: 20,
                            color: Colors.green,
                          )),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 5,
          )
        ],
      ),
    );
  }

  bool _compareDate(String dateStr) {
    DateTime tempDate = new DateFormat("yyyy-MM-dd").parse(dateStr);
    var givenDate = DateTime.now();
    return givenDate.isBefore(tempDate);
  }
}
