import 'dart:convert';
import 'dart:ffi';

import 'package:after_layout/after_layout.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/src/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:vidifi/model/Category.dart';
import 'package:vidifi/model/Customer.dart';
import 'package:vidifi/model/Price.dart';
import 'package:vidifi/model/Product.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vidifi/constant.dart';
import 'package:vidifi/model/Property.dart';
import 'package:vidifi/model/TemporaryInvoice.dart';
import 'package:vidifi/model/User.dart';
import 'package:vidifi/model/branch.dart';
import 'package:vidifi/services/api_service.dart';
import 'package:vidifi/util/dialog_utils.dart';
import 'package:vidifi/util/hide_keyboard.dart';
import 'package:vidifi/util/hive_manager.dart';
import 'package:vidifi/util/util.dart';
import 'package:vidifi/view/common/ProgressIndicator.dart';
import 'package:vidifi/util/handle_logout.dart';
import 'package:vidifi/view/common/search_bar.dart';
import 'package:vidifi/view/product/components/product_card.dart';
import 'package:vidifi/view/product/list_category.dart';
import 'package:vidifi/view/product/list_price.dart';
import 'package:vidifi/view/customer/list_customer.dart';
import 'package:vidifi/view/product/list_property.dart';
import 'package:vidifi/view/product/new_product.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:vidifi/view/profile/profile_cubit/profile_cubit.dart';

import '../login.dart';

class MyHome extends StatefulWidget {
  @override
  _MyHome createState() => _MyHome();
}

class _MyHome extends State<MyHome> with AfterLayoutMixin {
  String _scanBarcode = 'Unknown';
  static int page = 1;
  ScrollController _scProduct = new ScrollController();
  bool isLoadingProduct = false;
  TextEditingController _cSearch = TextEditingController();
  List<Product> products = [];
  List<Product> rawArray = [];
  String filterString = '';
  String categoryString = 'Tất cả';
  String filterCategoryString = '';
  String branchID = '';
  bool enableLoadMore = false;
  Customer? currentCustomer;
  RefreshController _refreshController = RefreshController();
  late ProfileCubit profileCubit;
  Price? _defaultPrice;

  @override
  void initState() {
    // this._getUserProfile();
    // this._getTemporaryInvoice();
    // filterString = 'search[branch_id]=${context.read<ProfileCubit>().getCurrentBranch().}';
    super.initState();
  }

  @override
  void afterFirstLayout(BuildContext context) {
    profileCubit = context.read<ProfileCubit>();
    profileCubit.getPriceBook();
    profileCubit.getDefaultConfig();
    page = 1;
    this._getMoreProduct();
  }

  @override
  void dispose() {
    _scProduct.dispose();
    super.dispose();
  }

  Future<void> startBarcodeScanStream() async {
    FlutterBarcodeScanner.getBarcodeStreamReceiver('#ff6666', 'Cancel', true, ScanMode.BARCODE)!
        .listen((barcode) => print(barcode));
  }

  Future<void> scanQR() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes =
          await FlutterBarcodeScanner.scanBarcode('#ff6666', 'Cancel', true, ScanMode.QR);
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      _scanBarcode = barcodeScanRes;
    });
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> scanBarcodeNormal() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes =
          await FlutterBarcodeScanner.scanBarcode('#ff6666', 'Cancel', true, ScanMode.BARCODE);
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) return;

    setState(() {
      _scanBarcode = barcodeScanRes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        hideKeyboard(context);
      },
      child: BlocConsumer<ProfileCubit, ProfileState>(
        listener: (context, state) {
          if (state is UpdateCurrentBranchSuccess) {
            page = 1;
            this._getMoreProduct();
          }
          if (state is UpdatePriceBook) {
            _defaultPrice = state.price;
          }
          if (state is UpdateCustomerDefault) {
            currentCustomer = state.customer;
          }
          if (state is FetchDefaultConfigSuccess) {
            currentCustomer = profileCubit.selectedCustomer;
          }
        },
        builder: (context, state) {
          return Scaffold(
            appBar: AppBar(
              centerTitle: true,
              title: Column(
                children: [
                  Text(
                    'Lựa chọn hàng bán',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                  profileCubit.currentBranch != null ? Padding(
                    padding: EdgeInsets.all(2.0),
                    child: Text(
                      profileCubit.currentBranch?.name ?? '',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                      textAlign: TextAlign.center,
                    ),
                  ) : Container(),
                ],
              ),
              backgroundColor: Colors.green,
            ),
            backgroundColor: Colors.white,
            body: Column(
              children: [
                Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                          child: SearchBarCommon(
                        controller: _cSearch,
                        hintText: 'Nhập tên, mã, serial/IMEI, lô, hsd',
                        textChanged: (text) {
                          print('CHANGED TEXT: $text');
                          _filter(text);
                        },
                        isDelayed: false,
                      )),
                      IconButton(
                        icon: Icon(
                          Icons.add,
                          size: 24,
                          color: Colors.black,
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => NewProduct(), fullscreenDialog: true),
                          );
                        },
                      ),
                      IconButton(
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (context) => ListProperty(propertySelected),
                                  fullscreenDialog: true),
                            );
                          },
                          icon: Icon(
                            Icons.filter_alt,
                          )),
                      IconButton(
                          onPressed: () {
                            scanBarcodeNormal();
                          },
                          icon: Image.asset('assets/icons/barcode.png', width: 24, height: 24, fit: BoxFit.cover,))
                    ],
                  ),
                ),
                Container(
                  height: 36,
                  color: greyColor2,
                  child: new Row(
                    children: <Widget>[
                      FlatButton.icon(
                          label: Text(
                            currentCustomer?.text ?? 'Chọn khách hàng',
                            style: TextStyle(color: Colors.green, fontSize: 12),
                          ),
                          icon: const Icon(
                            Icons.person,
                          ),
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (context) => ListCustomer(onSelectedCustomer),
                                  fullscreenDialog: true),
                            );
                          }),
                      Spacer(),
                      SizedBox(
                        width: 12,
                      ),
                      Visibility(
                        visible: _defaultPrice != null,
                        child: FlatButton.icon(
                            label: Text(
                              _defaultPrice?.name ?? 'Bảng giá chung',
                              style: TextStyle(color: primaryColor, fontSize: 12),
                            ),
                            icon: const Icon(
                              Icons.list_alt,
                            ),
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (context) => ListPrice(onSelectedPrice),
                                    fullscreenDialog: true),
                              );
                            }),
                      ),
                    ],
                  ),
                ),
                Container(
                  color: Colors.white,
                  padding: EdgeInsets.all(5),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                          context, MaterialPageRoute(fullscreenDialog: true,builder: (context) => ListCategory(onSelectedCate)));
                    },
                    child: Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 6),
                          child: Icon(Icons.list_sharp),
                        ),
                        Text(categoryString, maxLines: 2, textAlign: TextAlign.left,),
                        SizedBox(width: 20,),
                      ],
                    ),
                  ),
                ),
                new Expanded(
                  child: SmartRefresher(
                      controller: _refreshController,
                      footer: CustomFooter(
                        loadStyle: LoadStyle.ShowWhenLoading,
                        builder: (ctx, loadStatus) {
                          return loadStatus == LoadStatus.loading
                              ? Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: CupertinoActivityIndicator(),
                                )
                              : Container();
                        },
                      ),
                      onRefresh: () {
                        page = 1;
                        _cSearch.clear();
                        categoryString = 'Tất cả';
                        filterString = '';
                        filterCategoryString = '';
                        this._getMoreProduct();
                      },
                      onLoading: () {
                        print('LOADING MORE');
                        this._getMoreProduct();
                      },
                      enablePullUp: enableLoadMore,
                      child: _buildListProduct()),
                )
              ],
            ),
            resizeToAvoidBottomInset: false,
          );
        },
      ),
    );
  }

  Widget _buildListProduct() {
    return products.length == 0 ? Container(
      height: 450,
      // color: Colors.teal,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.search, size: 70,),
            ),
            Text('Không tìm thấy hàng hóa nào phù hơp', style: TextStyle(color: primaryColor),)
          ],
        ),
      ),
    ) : Padding(
      padding: EdgeInsets.only(top: 16),
      child: Container(
        color: Colors.white,
        child: ListView.separated(
          shrinkWrap: true,
          physics: BouncingScrollPhysics(),
          itemCount: products.length,
          // Add one more item for progress indicator
          itemBuilder: (BuildContext context, int index) {
            // if (index == products.length) {
            //   return buildProgressIndicator(isLoadingProduct);
            // } else {
            return ProductCard(product: products[index]);
            // }
          },
          controller: _scProduct,
          separatorBuilder: (BuildContext context, int index) {
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Divider(
                height: 1,
              ),
            );
          },
        ),
      ),
    );
  }

  void _getMoreProduct() async {
    if (!isLoadingProduct) {
      setState(() {
        isLoadingProduct = true;
      });
      if (profileCubit.currentBranch != null) {
        print('CURREND ID ${profileCubit.currentBranch?.id}');
        branchID = profileCubit.currentBranch?.id.toString() ?? '1';
      }
      print('BRANCH ID $branchID');
      final response = await APIService()
          .fetchProducts(page, filterString: filterString+filterCategoryString, branchID: branchID)
          .catchError((e) {
        // if (e.message == 401) {
        print('ERROR ${e.toString()}');
        // this.showAlertDialog(context);
        // }
      });
      setState(() {
        isLoadingProduct = false;
        enableLoadMore =
            response.meta?.pagination?.currentPage != response.meta?.pagination?.totalPages;
        if (response.data != null) {
          if (page == 1) products.clear();
          if (mounted) {
            _refreshController.refreshCompleted();
            _refreshController.loadComplete();
          }
          products.addAll(response.data!);
          rawArray = products;
          page++;
        }
      });
    }
  }

  void _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('token');
  }

  // void _getUserProfile() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   String userJson = prefs.getString('UserProfile') ?? '';
  //   userProfile = User.fromJson(jsonDecode(userJson));
  //   print('Get user profile ${userProfile.toJson()}');
  // }

  // void _getTemporaryInvoice() async {
  //   if (temporaryInvoice == null) {
  //     final prefs = await SharedPreferences.getInstance();
  //     String temporaryJson = prefs.getString('TemporaryInvoice') ?? '';
  //     temporaryInvoice = TemporaryInvoice.fromJson(jsonDecode(temporaryJson));
  //   }
  // }

  void onSelectedPrice(Price p1) {}

  void propertySelected(List<Property> filterList) {
    print('FILTER TYPE');
    filterString = '';
    filterList.forEach((element) {
      element.values.forEach((value) {
        if (value.isSelected) {
          filterString = filterString + '&variations[]=${value.id}';
        }
      });
    });

    print('========== $filterString');
    setState(() {
      // products = [];
      page = 1;
      // isLoadingProduct = false;
    });
    _getMoreProduct();
  }

  void onSelectedCustomer(Customer p1) {
    setState(() {
      currentCustomer = p1;
    });
  }

  void onSelectedCate(Category p1) {

    setState(() {
      categoryString = p1.name!;
    });
    filterCategoryString = '';
    filterCategoryString = "&search[category_id]=${p1.id}";
    // filterString += filterCategoryString;
    page = 1;
    // isLoadingProduct = false;
    _getMoreProduct();
  }

  void _filter(String text) {
    text = text.trim().toLowerCase();
    if (stringIsEmptyOrNull(text)) {
      setState(() {
        products = rawArray;
      });
      return;
    }
    List<Product> _searchedList = [];
    if (text.trim().length > 0) {
      rawArray.forEach((element) {
        if (element.name.toLowerCase().contains(text) ||
            (element.productCode ?? '').toLowerCase().contains(text)) {
          print('ELEMENT SEARCH :${element.toJson()}');
          _searchedList.add(element);
        }
      });
    }
    print('LENGTH FILTER: ${_searchedList.length}');
    setState(() {
      if (_searchedList.length > 0) products = _searchedList;
    });
  }
}
